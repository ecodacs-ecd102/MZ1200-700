/* 
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Ha Thach (tinyusb.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

// This example runs both host and device concurrently. The USB host receive
// reports from HID device and print it out over USB Device CDC interface.

// DEBUG options / DEFAULT values

// Array switch debug
#define MZ_KEYCODE_DEBUG	1

// HID LED logging
//#define HID_LED_DEBUG		1

// MZ clock setting
#define MZ_CLK_DEBUG		1

// debounce timing adjust
//#define MZ_DEBOUNCE_ADJUST	1

// SYSTEM MODE
#define SYSTEM_MODE_DEFAULT	0		// SP-1002 SDパッチ無し, FONT-JP, KEY=MZ-80K

// Z80 CLOCK
#define Z80_CLOCK_MODE_DEFAULT	Z80_CLOCK_MODE_AUTO

/*===================================================================
  GPIO仕様
    GPIO0: カセットのモーター信号入力 (IN: Pull-Up) : ON=L, OFF=H (ダイオードで5Vがかからないようにしているので要Pull-Up)
    GPIO1: システムクロック切替え信号出力 (Out)     : 2MHz=H, 4MHz=L (オープンコレクタTrで反転させているため)

    GPIO2-5(Out): BIOS ROMの切替え
      GPIO2: A15: 1=日本語,	0=英語 この信号はCG Selectにも使う
      GPIO3: A14: 1=MZ-1200,	0=MZ-700
      GPIO4: A13: 1=オリジナル,	0=MZ-80 SD対応パッチ入り
      GPIO5: A12: 1=SHARP ROM,	0=MZ-New Monitor

    GPIO6-15(Out): キースイッチマトリクスへ
      GPIO6:  RESET
      GPIO7:  DATA
      GPIO8:  STROBE
      GPIO9:  AX0
      GPIO10: AX1
      GPIO11: AX2
      GPIO12: AX3
      GPIO13: AY0
      GPIO14: AY1
      GPIO15: AY2

    GPIO16(In-PullUp): キースキャン(DEC0)検出線。0でスキャンを検出 (ダイオードで5Vがかからないようにしているので要Pull-Up)

    GPIO19(Out): 本体リセット用。1でリセットスイッチを押した状態

    GPIO20-22(In/Out): USB HOST制御 (Pico SDK内TinyUSBのデフォルト)
      GPIO20: D+
      GPIO21: D-
      GPIO22: VBUSEN


  -------------------------------------------------------------------
  キー入力仕様
  ■[ALT] + [CTRL] + テンキー[0]-[7]: システムモードの切り替え
      ROMを切り替えてリセットスイッチを押す(Cold Reset)
             A15 A14 A13 A12 ROM                      SD          FONT     KEY
      ALT+0:   0   0   0   0 MZ-1200, SP-1002         パッチ無し, FONT-JP, KEY=MZ-80K
      ALT+1:   0   0   0   1 MZ-1200, MZ-New Monitor  パッチ無し, FONT-JP, KEY=MZ-80K
      ALT+2:   0   0   1   0 MZ-1200, SP-1002         SDパッチ,   FONT-JP, KEY=MZ-80K
      ALT+3:   0   0   1   1 MZ-1200, MZ-New Monitor  SDパッチ,   FONT-JP, KEY=MZ-80K
      ALT+4:   0   1   0   0 MZ-700,  1Z-009A         パッチ無し, FONT-JP, KEY=MZ-700J
      ALT+5:   0   1   0   1 MZ-700,  MZ-New Monitor  パッチ無し, FONT-JP, KEY=MZ-700J
      ALT+6:   0   1   1   0 MZ-700,  1Z-009A         SDパッチ,   FONT-JP, KEY=MZ-700J
      ALT+7:   0   1   1   1 MZ-700,  MZ-New Monitor  SDパッチ,   FONT-JP, KEY=MZ-700J
 CTRL+ALT+0:   1   0   0   0 MZ-1200, SA-1510         パッチ無し, FONT-EN, KEY=MZ-80A
 CTRL+ALT+1:   1   0   0   1 MZ-1200, SP-1002         パッチ無し, FONT-EN, KEY=MZ-80K
 CTRL+ALT+2:   1   0   1   0 MZ-1200, SA-1510         SDパッチ,   FONT-EN, KEY=MZ-80A
 CTRL+ALT+3:   1   0   1   1 MZ-1200, SP-1002         SDパッチ,   FONT-EN, KEY=MZ-80K
 CTRL+ALT+4:   1   1   0   0 MZ-700,  1Z-013A         パッチ無し, FONT-EN, KEY=MZ-700E
 CTRL+ALT+5:   1   1   0   1 MZ-700,  MZ-New Monitor7 パッチ無し, FONT-EN, KEY=MZ-700J
 CTRL+ALT+6:   1   1   1   0 MZ-700,  1Z-013A         SDパッチ,   FONT-EN, KEY=MZ-700E
 CTRL+ALT+7:   1   1   1   1 MZ-700,  MZ-New Monitor7 SDパッチ,   FONT-EN, KEY=MZ-700J

  ■[ALT] + テンキー[+][-][*]: システムクロック切替え
      ALT+[+]: 4MHz固定
      ALT+[-]: 2MHz固定
      ALT+[*]: Auto (カセットのモーターOn時は2MHz, 他は4MHz)

  ■[ALT] + テンキー[8]: フラッシュへ保存したシステムモード、システムクロック、ファンクションキーを消去
  ■[ALT] + テンキー[9]: 現在のシステムモード、システムクロック、ファンクションキーをフラッシュへ保存
  　次回電源投入時は、保存されたモード、システムクロック、ファンクションキー設定になる

  ■[CTRL]+[ALT]+[DEL]: 現在のシステムモードでROMを切り替えずリセットスイッチを押す (Cold Reset)
  ■[CTRL]+[ALT]+[END]: 現在のシステムモードでROMを切り替えず[CTRL]+リセットスイッチを押す (MZ-700系のWarm Resetのエミュレーション)
  ■[ALT]+英字キー: MZ-1200モードでグラフィックキャラクタの直接入力 (Pasocom mini MZ-80C互換)

  ■[Fn]キー       n=6-12: ファンクションキー(キーマクロ)の実行 ([F1]-[F5]はMZ700で使われているので[F6]-[F12]とする) (COOKED mode only)
  ■[ALT]+[Fn]キー n=6-12: ファンクションキー(キーマクロ)の登録/登録終了([F1]-[F5]はMZ700で使われるため[F6]-[F12]とする) (COOKED mode only)
  　キーマクロは MZ_FKEY_MAXLEN	キーストロークまで。((FLASH_PAGE_SIZE - 8) / 2) = 124 キーまで。
  　[ALT]+[テンキー9]で不揮発に保存される。

  ■[CAPS]キー: [ALPHA(英数)]キーとして処理される。MZ-1200モードでは[カナ/英数]キーとなる
  ■[TAB]キー: [HOME/CLR]キーとして処理される。
  ■[PgUp]キー: [GRPH]キーとして処理される。
  ■[PgDn]キー,[かな]: [KANA]キーとして処理される。

  ■[ALT]+[CAPS]キー: RAW mode / COOKED mode 切替え。
  　COOKED mode (Default):
  　  USBキーに書かれているキー刻印にできるだけ忠実になるように、シフトキーが自動で付加される
  　RAW mode (aka GAME mode):
  　  シフトキーも透過的に実機に送られるため、キーの読み替えは最小限となる。
  　  このモードの時は、カナキー、NUMキー、CAPSキーランプが点滅する。
  　  また、ゲームのキー反応のリアルタイム性を上げるため、デバウンス関係の待ちは入れない。

  ■[ALT] + [Up]/[Down]/[Left]/[Right]
    (MZ_DEBOUNCE_ADJUST 定義時)
  　デバウンス関係のパラメータ調整
  　[ALT]+[Up]/[Down]    : Press debounce +/-
  　[ALT]+[Left]/[Right] : Release debounce -/+
  ■[ALT] + [Left]/[Right]
  　デバウンス関係のパラメータ調整
  　[ALT]+[Left]/[Right] : Release debounce H,M,L切替え

  ===================================================================*/




#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "bsp/board.h"
#include "tusb.h"

// GPIO for MZ ver.
#include "pico/stdlib.h"
#include "hardware/gpio.h"

// flash memory access
#include "hardware/flash.h"

// PIO_USB_VBUSEN_PIN, PIO_USB_VBUSEN_STATE
#include "../../hw/bsp/rp2040/board.h"

//--------------------------------------------------------------------+
// MACRO CONSTANT TYPEDEF PROTYPES
//--------------------------------------------------------------------+

// uncomment if you are using colemak layout
// #define KEYBOARD_COLEMAK

#ifdef KEYBOARD_COLEMAK
const uint8_t colemak[128] = {
  0  ,  0,  0,  0,  0,  0,  0, 22,
  9  , 23,  7,  0, 24, 17,  8, 12,
  0  , 14, 28, 51,  0, 19, 21, 10,
  15 ,  0,  0,  0, 13,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0, 18,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0
};
#endif

static uint8_t const keycode2ascii[256][2] =  {
    {0     , 0      }, /* 0x00 */ \
    {0     , 0      }, /* 0x01 */ \
    {0     , 0      }, /* 0x02 */ \
    {0     , 0      }, /* 0x03 */ \
    {'a'   , 'A'    }, /* 0x04 */ \
    {'b'   , 'B'    }, /* 0x05 */ \
    {'c'   , 'C'    }, /* 0x06 */ \
    {'d'   , 'D'    }, /* 0x07 */ \
    {'e'   , 'E'    }, /* 0x08 */ \
    {'f'   , 'F'    }, /* 0x09 */ \
    {'g'   , 'G'    }, /* 0x0a */ \
    {'h'   , 'H'    }, /* 0x0b */ \
    {'i'   , 'I'    }, /* 0x0c */ \
    {'j'   , 'J'    }, /* 0x0d */ \
    {'k'   , 'K'    }, /* 0x0e */ \
    {'l'   , 'L'    }, /* 0x0f */ \
    {'m'   , 'M'    }, /* 0x10 */ \
    {'n'   , 'N'    }, /* 0x11 */ \
    {'o'   , 'O'    }, /* 0x12 */ \
    {'p'   , 'P'    }, /* 0x13 */ \
    {'q'   , 'Q'    }, /* 0x14 */ \
    {'r'   , 'R'    }, /* 0x15 */ \
    {'s'   , 'S'    }, /* 0x16 */ \
    {'t'   , 'T'    }, /* 0x17 */ \
    {'u'   , 'U'    }, /* 0x18 */ \
    {'v'   , 'V'    }, /* 0x19 */ \
    {'w'   , 'W'    }, /* 0x1a */ \
    {'x'   , 'X'    }, /* 0x1b */ \
    {'y'   , 'Y'    }, /* 0x1c */ \
    {'z'   , 'Z'    }, /* 0x1d */ \
    {'1'   , '!'    }, /* 0x1e */ \
    {'2'   , '"'    }, /* 0x1f */ \
    {'3'   , '#'    }, /* 0x20 */ \
    {'4'   , '$'    }, /* 0x21 */ \
    {'5'   , '%'    }, /* 0x22 */ \
    {'6'   , '&'    }, /* 0x23 */ \
    {'7'   , 0x27   }, /* 0x24 */ \
    {'8'   , '('    }, /* 0x25 */ \
    {'9'   , ')'    }, /* 0x26 */ \
    {'0'   , 0      }, /* 0x27 */ \
    {'\r'  , '\r'   }, /* 0x28 [CR] */ \
    {'\x1b', '\x1b' }, /* 0x29 [ESC] = SHIFT+SPACE in Hu-BASIC*/ \
    {'\x14', '\x14' }, /* 0x2a [BS] = [←] */ \
    {'\x15', '\x16' }, /* 0x2b TAB = [HOME/CLR] */ \
    {' '   , ' '    }, /* 0x2c [SPACE] */ \
    {'-'   , '-'    }, /* 0x2d */ \
    {'^'   , 0      }, /* 0x2e */ \
    {'@'   , '`'    }, /* 0x2f */ \
    {'['   , '{'    }, /* 0x30 */ \
    {0     , 0      }, /* 0x31 */ \
    {']'   , '}'    }, /* 0x32 */ \
    {';'   , '+'    }, /* 0x33 */ \
    {':'   , '*'    }, /* 0x34 */ \
    {'\x03', '\x03' }, /* 0x35 ZEN/HAN = [BREAK] key = ^C */ \
    {','   , '<'    }, /* 0x36 */ \
    {'.'   , '>'    }, /* 0x37 */ \
    {'/'   , '?'    }, /* 0x38 */ \
                                  \
    {0     , 0      }, /* 0x39: [CAPS] = [カナ/英数] */ \
    {0     , 0      }, /* 0x3a [F1] */ \
    {0     , 0      }, /* 0x3b [F2] */ \
    {0     , 0      }, /* 0x3c [F3] */ \
    {0     , 0      }, /* 0x3d [F4] */ \
    {0     , 0      }, /* 0x3e [F5] */ \
    {0     , 0      }, /* 0x3f [F6] */ \
    {0     , 0      }, /* 0x40 [F7] */ \
    {0     , 0      }, /* 0x41 [F8] */ \
    {0     , 0      }, /* 0x42:[F9]  */ \
    {0     , 0      }, /* 0x43:[F10] */ \
    {0     , 0      }, /* 0x44 [F11] */ \
    {0     , 0      }, /* 0x45:[F12] */ \
    {0     , 0      }, /* 0x46 */ \
    {0     , 0      }, /* 0x47 */ \
    {0     , 0      }, /* 0x48 */ \
    {0     , 0      }, /* 0x49 Insert */ \
    {'\x15', 0      }, /* 0x4a Home */ \
    {0     , 0      }, /* 0x4b PgUp */ \
    {0     , 0      }, /* 0x4c Delete */ \
    {0     , 0      }, /* 0x4d Pgdn */ \
    {0     , 0      }, /* 0x4e */ \
    {'\x13', 0      }, /* 0x4f right arrow */ \
    {'\x14', 0      }, /* 0x50 left arrow */ \
    {'\x11', 0      }, /* 0x51 down arrow */ \
    {'\x12', 0      }, /* 0x52 up arrow */ \
    {0     , 0      }, /* 0x53 */ \
                                  \
    {'/'   , '/'    }, /* 0x54 */ \
    {'*'   , '*'    }, /* 0x55 */ \
    {'-'   , '-'    }, /* 0x56 */ \
    {'+'   , '+'    }, /* 0x57 */ \
    {'\r'  , '\r'   }, /* 0x58 */ \
    {'1'   , 0      }, /* 0x59 */ \
    {'2'   , 0      }, /* 0x5a */ \
    {'3'   , 0      }, /* 0x5b */ \
    {'4'   , 0      }, /* 0x5c */ \
    {'5'   , 0      }, /* 0x5d */ \
    {'6'   , 0      }, /* 0x5e */ \
    {'7'   , 0      }, /* 0x5f */ \
    {'8'   , 0      }, /* 0x60 */ \
    {'9'   , 0      }, /* 0x61 */ \
    {'0'   , 0      }, /* 0x62 */ \
    {'.'   , 0      }, /* 0x63 */ \
    {0     , 0      }, /* 0x64 */ \
    {0     , 0      }, /* 0x65:[Application] */ \
    {0     , 0      }, /* 0x66 */ \
    {'='   , '='    }, /* 0x67 */ \
    				  \
    {0     , 0      }, /* 0x68 */ \
    {0     , 0      }, /* 0x69 */ \
    {0     , 0      }, /* 0x6a */ \
    {0     , 0      }, /* 0x6b */ \
    {0     , 0      }, /* 0x6c */ \
    {0     , 0      }, /* 0x6d */ \
    {0     , 0      }, /* 0x6e */ \
    {0     , 0      }, /* 0x6f */ \
    {0     , 0      }, /* 0x70 */ \
    {0     , 0      }, /* 0x71 */ \
    {0     , 0      }, /* 0x72 */ \
    {0     , 0      }, /* 0x73 */ \
    {0     , 0      }, /* 0x74 */ \
    {0     , 0      }, /* 0x75 */ \
    {0     , 0      }, /* 0x76 */ \
    {0     , 0      }, /* 0x77 */ \
    {0     , 0      }, /* 0x78 */ \
    {0     , 0      }, /* 0x79 */ \
    {0     , 0      }, /* 0x7a */ \
    {0     , 0      }, /* 0x7b */ \
    {0     , 0      }, /* 0x7c */ \
    {0     , 0      }, /* 0x7d */ \
    {0     , 0      }, /* 0x7e */ \
    {0     , 0      }, /* 0x7f */ \
    {0     , 0      }, /* 0x80 */ \
    {0     , 0      }, /* 0x81 */ \
    {0     , 0      }, /* 0x82 */ \
    {0     , 0      }, /* 0x83 */ \
    {0     , 0      }, /* 0x84 */ \
    {0     , 0      }, /* 0x85 */ \
    {0     , 0      }, /* 0x86 */ \
    				  \
    {'\x5c', '_'    }, /* 0x87:[Backslash]/[_] key */ \
    {0     , 0      }, /* 0x88:[Hiragana/Katakana] */ \
    {'\x5c', 0      }, /* 0x89:[Yen]/[|] key */ \
};


/* Blink pattern
 * - 250 ms  : device not mounted
 * - 1000 ms : device mounted
 * - 2500 ms : device is suspended
 */
enum  {
  BLINK_NOT_MOUNTED = 250,
  BLINK_MOUNTED = 1000,
  BLINK_SUSPENDED = 2500,
};

static uint32_t blink_interval_ms = BLINK_NOT_MOUNTED;

void led_blinking_task(void);

/*------------- Keyboard LED  -------------*/
static uint8_t leds = 0;
static uint8_t prev_leds = 0;

/* NUMLOCK Blink pattern
 * - 250 ms : RAW mode
 * - 0 ms   : KANA mode
 */
enum  {
  BLINK_NUMLOCK_LED_NONE = 0,
  BLINK_NUMLOCK_LED_RAW = 250,
  BLINK_NUMLOCK_LED_KANA = 0,
};

static uint32_t blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;

// Keyboard address and instance (assumes there is only one)
static uint8_t keybd_dev_addr = 0xFFu;
static uint8_t keybd_instance;

void keyboard_led_blinking_task(void);



/*------------- MZ-1200  -------------*/

/*
#====================================================================
# Scan Code: MZ-1200
#  ------+------------------------
#   row |  7  6  5  4  3  2  1  0
# +1----+------------------------
#  1 0 .| ┴ ┘  -  9  7  5  3  1
#      S| ┬ ┐  +  )  '  %  #  !
#      K| ャ「  ホ ヨ ヤ エ ア ヌ
#       |
#  2 1 .| 月 ├ └  0  8  6  4  2
#      S| 日 ┤ ┌  π (  &  $  "
#      K| ￥ ァ ケ ワ ユ オ ウ フ
#       |
#  3 2 .| ┘ F4  =  O  U  T  E  Q
#      S| ┐ C5  *  :  @  ] ←  <
#      K| ュ 」 ヘ ラ ナ カ イ タ
#       |
#  4 3 .| 水 └ E5  P  I  Y  R  W
#      S| 火 ┌ C3  ^  ? ＼  [  >	^=↑キー
#      K| ￡ ィ ム セ ニ ン ス テ
#       | 
#  5 4 .| D4 E3 ┼  L  J  G  D  A
#      S| ED E7 DE DC F1 ● ♦ ♠
#      K| ョ 、 ロ リ マ キ シ チ
#       |
#  6 5 .| 金 EE E3  ;  K  H  F  S
#      s| 木 D7 E4 DF DB 〇 ♣ ♥
#      K| 時 ゥ ヲ レ ノ ク ハ ト
#       |
#  7 6 .| C1 FD kn  .  M  B  C  Z 	kn = [カナ/英数]
#      S| D4 E7 kn EB FE E8 C0 C6
#      K| ッ ・ kn ル モ コ ソ ツ	・ = 中黒
#       |
#  8 7 .| 生 C2 E6  /  ,  N  V  X
#      S| 土 D7 E0 F6 EA C8 F4 FC
#      K| 分 ェ ゜ メ ネ ミ ヒ サ
#       |
#  9 8 .| CA C6 rs CR -> -- id ls	ls = Left SHIFT, rs = Right SHIFT
#      S| D6 F8 rs CR <- -- id ls	-> = CURSOR →
#      K| ー 。 rs CR <> -- id ls	<- = CURSOR ←
#       |
#  a 9 .| 円 CF ゛ -- ^C cd 20 hh	hh = [HOME], 20=[SPACE], cd = [CURSOR↓]
#      S| 年 D8 ゛ -- ^C cu 20 cc	cc = [CLR], cu = [CURSOR↑]
#      K| 秒 ォ ゛ -- ^C cd 20 HC	HC = [HOME/CLR], ^C ~ [BREAK]
#       |
#  ------+------------------------
#====================================================================
*/
/*------------- MZ-80A  -------------*/
/*
#====================================================================
# Scan Code: MZ-80A
#  ------+------------------------
#   row |  7  6  5  4  3  2  1  0
# +1----+------------------------
#  1 0 .| ct -- -- -- -- -- gr sh	cr=[CTRL],br=[BREAK],gr=[GRPH],sh=[SHIFT]
#      S| br
#      G| 
#       |
#  2 1 .|  2  1  W  Q  A dl --  Z	dl=[DEL]
#      S|  "  !          in --  	in=[INST]
#      G| 
#       |
#  3 2 .|  4  3  R  E  D  S  X  C
#      S|  $  #
#      G| 
#       |
#  4 3 .|  6  5  Y  T  G  F  V  B
#      S|  &  %
#      G| 
#       | 
#  5 4 .|  8  7  I  U  J  H  N sp
#      S|  (  '
#      G| 
#       |
#  6 5 .|  0  9  P  O  L  K  <  M
#      s|  -  )              ,
#      G| 
#       |
#  7 6 .|  ^  -  [  @  :  ;  /  .
#      S|  ~  =  {  \  *  + ←  >
#      G| 
#       |
#  8 7 .| hm  \ ri up CR  ] -- ↑
#      S| cl  | le dn CR  } --  ?
#      G| 
#       |
#  9 8 .|  8  7  5  4  2  1 00  0	10-KEY
#      S| 
#      G| 
#       |
#  a 9 .|  +  9  -  6 --  3 --  .	10-KEY
#      S| 
#      G| 
#       |
#  ------+------------------------
#====================================================================
*/
/*------------- MZ700  -------------*/

/*
#====================================================================
# Scan Code: MZ-700J
#  ------+------------------------
#   row |  7  6  5  4  3  2  1  0
# +1----+-----------------------
#  1 0 .| kn gr  = ei --  ;  : CR	 kn=[カナ], gr=[GRPH], ei=[英数], CR=[CR]
#       |
#  2 1 .|  Y  Z  @  (  ) -- -- --
#      S| 
#      K| 
#       |
#  3 2 .|  Q  R  S  T  U  V  W  X
#      S| 
#      K| 
#       |
#  4 3 .|  I  J  K  L  M  N  O  P
#      S| 
#      K| 
#       | 
#  5 4 .|  A  B  C  D  E  F  G  H
#      S| 
#      K| 
#       |
#  6 5 .|  1  2  3  4  5  6  7  8
#      s| 
#      K| 
#       |
#  7 6 .|  *  +  - sp  0  9  ,  .	sp=[SPACE]
#      S| 
#      K| 
#       |
#  8 7 .| in de up dn ri le  ?  /	in=[INST], de=[DEL], up,db,ri,le =Cursor up, down, right left
#      S| 
#      K| 
#       |
#  9 8 .| br ct -- -- -- -- -- sh	cr=[BREAK], ct=[CTRL], sh=[SHIFT]
#      S| 
#      K| 
#       |
#  a 9 .| F1 F2 F3 F4 F5 -- -- --
#      S| 
#      K| 
#       |
#  ------+------------------------
#====================================================================
# Scan Code: MZ-700EU
#  ------+------------------------
#   row |  7  6  5  4  3  2  1  0
# +1----+-----------------------
#  1 0 .| -- gr ↓ ei --  ;  : CR	 gr=[GRPH], ei=[英数], CR=[CR]
#       |
#  2 1 .|  Y  Z  @  (  ) -- -- --
#      S| 
#      K| 
#       |
#  3 2 .|  Q  R  S  T  U  V  W  X
#      S| 
#      K| 
#       |
#  4 3 .|  I  J  K  L  M  N  O  P
#      S| 
#      K| 
#       | 
#  5 4 .|  A  B  C  D  E  F  G  H
#      S| 
#      K| 
#       |
#  6 5 .|  1  2  3  4  5  6  7  8
#      s| 
#      K| 
#       |
#  7 6 .|  \ ↑  - sp  0  9  ,  .	sp=[SPACE]
#      S| 
#      K| 
#       |
#  8 7 .| in de up dn ri le  ?  /	in=[INST], de=[DEL], up,db,ri,le =Cursor up, down, right left
#      S| 
#      K| 
#       |
#  9 8 .| br ct -- -- -- -- -- sh	cr=[BREAK], ct=[CTRL], sh=[SHIFT]
#      S| 
#      K| 
#       |
#  a 9 .| F1 F2 F3 F4 F5 -- -- --
#      S| 
#      K| 
#       |
#  ------+------------------------
#====================================================================
*/

#define DELETE_KEY_CODE		0x4c	// for CTRL-ALT-DEL
#define END_KEY_CODE		0x4d	// for CTRL-ALT-END
#define C_KEY_CODE		0x06	// for CTRL-C
#define UP_KEY_CODE		0x52	// for CTRL-UP/DOWN/LEFT/RIGHT
#define DOWN_KEY_CODE		0x51	// for CTRL-UP/DOWN/LEFT/RIGHT
#define LEFT_KEY_CODE		0x50	// for CTRL-UP/DOWN/LEFT/RIGHT
#define RIGHT_KEY_CODE		0x4f	// for CTRL-UP/DOWN/LEFT/RIGHT
#define CAPS_KEY_CODE		0x39	// for ALPHA
#define KANA_KEY_CODE		0x88	// for KANA input mode
#define KANA_KEY_CODE2		0x4e	// for KANA input mode (=[PgDn] key)
#define GRPH_KEY_CODE		0x4b	// for GRPH input mode (=[PgUp] key)
#define F1_KEY_CODE		0x3a	// [F1] - [F12]
#define F2_KEY_CODE		0x3b	// [F1] - [F12]
#define F3_KEY_CODE		0x3c	// [F1] - [F12]
#define F4_KEY_CODE		0x3d	// [F1] - [F12]
#define F5_KEY_CODE		0x3e	// [F1] - [F12]
#define F6_KEY_CODE		0x3f	// [F1] - [F12]
#define F7_KEY_CODE		0x40	// [F1] - [F12]
#define F8_KEY_CODE		0x41	// [F1] - [F12]
#define F9_KEY_CODE		0x42	// [F1] - [F12]
#define F10_KEY_CODE		0x43	// [F1] - [F12]
#define F11_KEY_CODE		0x44	// [F1] - [F12]
#define F12_KEY_CODE		0x45	// [F1] - [F12]
#define TENKEY_1_KEY_CODE	0x59	// Tenkey [1] - [7]
#define TENKEY_7_KEY_CODE	0x5f	// Tenkey [1] - [7]
#define TENKEY_8_KEY_CODE	0x60	// Tenkey [8]
#define TENKEY_9_KEY_CODE	0x61	// Tenkey [9]
#define TENKEY_0_KEY_CODE	0x62	// Tenkey [0]
#define TENKEY_PLUS_KEY_CODE	0x57	// Tenkey [+]
#define TENKEY_MINUS_KEY_CODE	0x56	// Tenkey [-]
#define TENKEY_ASTERISK_KEY_CODE 0x55	// Tenkey [*]

#define MZ_KEYPRESS		0x100u
#define MZ_ISKEYPRESS(x)	((x & MZ_KEYPRESS) ? true : false)
#define MZ_BARE_SYX(x)		((uint16_t)(x & ~MZ_KEYPRESS))
#define MZ_SHIFT		0x80u
#define MZ_BARE_YX(x)		((uint16_t)(x & ~MZ_KEYPRESS & ~MZ_SHIFT))
#define MZ_ISSHIFT(x)		((x & MZ_SHIFT) ? 1 : 0)
#define MZ_Y(x)			((x >> 4) & 0x07)
#define MZ_X(x)			((x & 0x0f) - 1)

/*
  key code to switch matrix X-Y and SHIFT table
   (bit 8  : 1 = pressed, 0 = released, in queue only)
    bit 7  : Need SHIFT (1 = Generate with SHIFT key)
    bit 6-4: Y scanline (0-7)
    bit 3-0: X scanline + 1 (1-0a), i.e. valid key has non-zero code on this table
*/

#define MZ1200_KEYCODE_BREAK	0x3a	// MZ1200 [BREAK] key X-Y
#define MZ1200_KEYCODE_CTRL	0x00	// MZ1200 [CTRL] key X-Y (No key)
#define MZ1200_KEYCODE_LS	0x09	// MZ1200 [Left SHIFT] key X-Y
#define MZ1200_KEYCODE_RS	0x59	// MZ1200 [Right SHIFT] key X-Y
#define MZ1200_KEYCODE_ALPHA	0x57	// MZ1200 [英数] key X-Y
#define MZ1200_KEYCODE_KANA	0x57	// MZ1200 [カナ] key X-Y
#define MZ1200_KEYCODE_GRPH	0x00	// MZ1200 [GRPH] key X-Y (No key)

#define MZ700J_KEYCODE_BREAK	0x79	// MZ700J [BREAK] key X-Y
#define MZ700J_KEYCODE_CTRL	0x69	// MZ700J [CTRL] key X-Y
#define MZ700J_KEYCODE_LS	0x09	// MZ700J [Left SHIFT] key X-Y
#define MZ700J_KEYCODE_RS	0x09	// MZ700J [Right SHIFT] key X-Y
#define MZ700J_KEYCODE_ALPHA	0x41	// MZ700J [英数] key X-Y
#define MZ700J_KEYCODE_KANA	0x71	// MZ700J [カナ] key X-Y
#define MZ700J_KEYCODE_GRPH	0x61	// MZ700J [GRPH] key X-Y

#define MZ80A_KEYCODE_BREAK	0xF1	// MZ80A [BREAK] key X-Y (SHIFT+CTRL)
#define MZ80A_KEYCODE_CTRL	0x71	// MZ80A [CTRL] key X-Y
#define MZ80A_KEYCODE_LS	0x01	// MZ80A [Left SHIFT] key X-Y
#define MZ80A_KEYCODE_RS	0x01	// MZ80A [Right SHIFT] key X-Y
//#define MZ80A_KEYCODE_ALPHA	0x11	// MZ80A [英数] key X-Y
#define MZ80A_KEYCODE_ALPHA	0x12	// MZ80A [英数] key X-Y : 実機には無いキーを[ALPHA]専用に割り当てる 要パッチSA-1510: 0BF0, 0C38, 0C70: 00->C9
#define MZ80A_KEYCODE_KANA	0x00	// MZ80A [カナ] key X-Y (No key)
#define MZ80A_KEYCODE_GRPH	0x11	// MZ80A [GRPH] key X-Y

#define MZ700E_KEYCODE_BREAK	0x79	// MZ700E [BREAK] key X-Y
#define MZ700E_KEYCODE_CTRL	0x69	// MZ700E [CTRL] key X-Y
#define MZ700E_KEYCODE_LS	0x09	// MZ700E [Left SHIFT] key X-Y
#define MZ700E_KEYCODE_RS	0x09	// MZ700E [Right SHIFT] key X-Y
#define MZ700E_KEYCODE_ALPHA	0x41	// MZ700E [英数] key X-Y
#define MZ700E_KEYCODE_KANA	0x00	// MZ700E [カナ] key X-Y (No key)
#define MZ700E_KEYCODE_GRPH	0x61	// MZ700E [GRPH] key X-Y


// SYSTEM MODE (for switing ROM/KB MATRIX): 0-15
uint16_t system_mode = SYSTEM_MODE_DEFAULT;

// MZ KEYCODES FOR SPECIAL KEYS
const uint8_t mz_keycode_break[16] = {
  MZ1200_KEYCODE_BREAK,		// 0
  MZ1200_KEYCODE_BREAK,		// 1
  MZ1200_KEYCODE_BREAK,		// 2
  MZ1200_KEYCODE_BREAK,		// 3
  MZ700J_KEYCODE_BREAK,		// 4
  MZ700J_KEYCODE_BREAK,		// 5
  MZ700J_KEYCODE_BREAK,		// 6
  MZ700J_KEYCODE_BREAK,		// 7
  MZ80A_KEYCODE_BREAK,		// 8
  MZ1200_KEYCODE_BREAK,		// 9
  MZ80A_KEYCODE_BREAK,		// 10
  MZ1200_KEYCODE_BREAK,		// 11
  MZ700E_KEYCODE_BREAK,		// 12
  MZ700J_KEYCODE_BREAK,		// 13
  MZ700E_KEYCODE_BREAK,		// 14
  MZ700J_KEYCODE_BREAK,		// 15
};
#define MZ_KEYCODE_BREAK	(mz_keycode_break[system_mode])
const uint8_t mz_keycode_ctrl[16] = {
  MZ1200_KEYCODE_CTRL,		// 0
  MZ1200_KEYCODE_CTRL,		// 1
  MZ1200_KEYCODE_CTRL,		// 2
  MZ1200_KEYCODE_CTRL,		// 3
  MZ700J_KEYCODE_CTRL,		// 4
  MZ700J_KEYCODE_CTRL,		// 5
  MZ700J_KEYCODE_CTRL,		// 6
  MZ700J_KEYCODE_CTRL,		// 7
  MZ80A_KEYCODE_CTRL,		// 8
  MZ1200_KEYCODE_CTRL,		// 9
  MZ80A_KEYCODE_CTRL,		// 10
  MZ1200_KEYCODE_CTRL,		// 11
  MZ700E_KEYCODE_CTRL,		// 12
  MZ700J_KEYCODE_CTRL,		// 13
  MZ700E_KEYCODE_CTRL,		// 14
  MZ700J_KEYCODE_CTRL,		// 15
};
#define MZ_KEYCODE_CTRL	(mz_keycode_ctrl[system_mode])
const uint8_t mz_keycode_ls[16] = {
  MZ1200_KEYCODE_LS,		// 0
  MZ1200_KEYCODE_LS,		// 1
  MZ1200_KEYCODE_LS,		// 2
  MZ1200_KEYCODE_LS,		// 3
  MZ700J_KEYCODE_LS,		// 4
  MZ700J_KEYCODE_LS,		// 5
  MZ700J_KEYCODE_LS,		// 6
  MZ700J_KEYCODE_LS,		// 7
  MZ80A_KEYCODE_LS,		// 8
  MZ1200_KEYCODE_LS,		// 9
  MZ80A_KEYCODE_LS,		// 10
  MZ1200_KEYCODE_LS,		// 11
  MZ700E_KEYCODE_LS,		// 12
  MZ700J_KEYCODE_LS,		// 13
  MZ700E_KEYCODE_LS,		// 14
  MZ700J_KEYCODE_LS,		// 15
};
#define MZ_KEYCODE_LS	(mz_keycode_ls[system_mode])
const uint8_t mz_keycode_rs[16] = {
  MZ1200_KEYCODE_RS,		// 0
  MZ1200_KEYCODE_RS,		// 1
  MZ1200_KEYCODE_RS,		// 2
  MZ1200_KEYCODE_RS,		// 3
  MZ700J_KEYCODE_RS,		// 4
  MZ700J_KEYCODE_RS,		// 5
  MZ700J_KEYCODE_RS,		// 6
  MZ700J_KEYCODE_RS,		// 7
  MZ80A_KEYCODE_RS,		// 8
  MZ1200_KEYCODE_RS,		// 9
  MZ80A_KEYCODE_RS,		// 10
  MZ1200_KEYCODE_RS,		// 11
  MZ700E_KEYCODE_RS,		// 12
  MZ700J_KEYCODE_RS,		// 13
  MZ700E_KEYCODE_RS,		// 14
  MZ700J_KEYCODE_RS,		// 15
};
#define MZ_KEYCODE_RS	(mz_keycode_rs[system_mode])
const uint8_t mz_keycode_alpha[16] = {
  MZ1200_KEYCODE_ALPHA,		// 0
  MZ1200_KEYCODE_ALPHA,		// 1
  MZ1200_KEYCODE_ALPHA,		// 2
  MZ1200_KEYCODE_ALPHA,		// 3
  MZ700J_KEYCODE_ALPHA,		// 4
  MZ700J_KEYCODE_ALPHA,		// 5
  MZ700J_KEYCODE_ALPHA,		// 6
  MZ700J_KEYCODE_ALPHA,		// 7
  MZ80A_KEYCODE_ALPHA,		// 8
  MZ1200_KEYCODE_ALPHA,		// 9
  MZ80A_KEYCODE_ALPHA,		// 10
  MZ1200_KEYCODE_ALPHA,		// 11
  MZ700E_KEYCODE_ALPHA,		// 12
  MZ700J_KEYCODE_ALPHA,		// 13
  MZ700E_KEYCODE_ALPHA,		// 14
  MZ700J_KEYCODE_ALPHA,		// 15
};
#define MZ_KEYCODE_ALPHA	(mz_keycode_alpha[system_mode])
const uint8_t mz_keycode_kana[16] = {
  MZ1200_KEYCODE_KANA,		// 0
  MZ1200_KEYCODE_KANA,		// 1
  MZ1200_KEYCODE_KANA,		// 2
  MZ1200_KEYCODE_KANA,		// 3
  MZ700J_KEYCODE_KANA,		// 4
  MZ700J_KEYCODE_KANA,		// 5
  MZ700J_KEYCODE_KANA,		// 6
  MZ700J_KEYCODE_KANA,		// 7
  MZ80A_KEYCODE_KANA,		// 8
  MZ1200_KEYCODE_KANA,		// 9
  MZ80A_KEYCODE_KANA,		// 10
  MZ1200_KEYCODE_KANA,		// 11
  MZ700E_KEYCODE_KANA,		// 12
  MZ700J_KEYCODE_KANA,		// 13
  MZ700E_KEYCODE_KANA,		// 14
  MZ700J_KEYCODE_KANA,		// 15
};
#define MZ_KEYCODE_KANA	(mz_keycode_kana[system_mode])
const uint8_t mz_keycode_grph[16] = {
  MZ1200_KEYCODE_GRPH,		// 0
  MZ1200_KEYCODE_GRPH,		// 1
  MZ1200_KEYCODE_GRPH,		// 2
  MZ1200_KEYCODE_GRPH,		// 3
  MZ700J_KEYCODE_GRPH,		// 4
  MZ700J_KEYCODE_GRPH,		// 5
  MZ700J_KEYCODE_GRPH,		// 6
  MZ700J_KEYCODE_GRPH,		// 7
  MZ80A_KEYCODE_GRPH,		// 8
  MZ1200_KEYCODE_GRPH,		// 9
  MZ80A_KEYCODE_GRPH,		// 10
  MZ1200_KEYCODE_GRPH,		// 11
  MZ700E_KEYCODE_GRPH,		// 12
  MZ700J_KEYCODE_GRPH,		// 13
  MZ700E_KEYCODE_GRPH,		// 14
  MZ700J_KEYCODE_GRPH,		// 15
};
#define MZ_KEYCODE_GRPH	(mz_keycode_grph[system_mode])


typedef const uint8_t keycode2SYX_t[256][7];
/* MZ-1200 USB KB scan code to MZ switch matrix code
     w/o SHIFT        , w/ SHIFT         , kana             , kana+shift       , ALT (=GRPH)      , GRPH+shift       , RAW */
static keycode2SYX_t keycode2MZ1200SYX =  {
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x00   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x01   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x02   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x03   */ \
    {0x05             , 0x05|MZ_SHIFT    , 0x05             , 0x76             , 0x54             , 0x54             , 0x05             }, /* 0x04:a */ \
    {0x27             , 0x27|MZ_SHIFT    , 0x27             , 0                , 0x76             , 0x76             , 0x27             }, /* 0x05:b */ \
    {0x17             , 0x17|MZ_SHIFT    , 0x17             , 0                , 0x66             , 0x66             , 0x17             }, /* 0x06:c */ \
    {0x15             , 0x15|MZ_SHIFT    , 0x15             , 0x7a             , 0x64             , 0x64             , 0x15             }, /* 0x07:d */ \
    {0x13             , 0x13|MZ_SHIFT    , 0x13             , 0x64             , 0x62             , 0x62             , 0x13             }, /* 0x08:e */ \
    {0x16             , 0x16|MZ_SHIFT    , 0x16             , 0                , 0x73             , 0x73             , 0x16             }, /* 0x09:f */ \
    {0x25             , 0x25|MZ_SHIFT    , 0x25             , 0                , 0x74             , 0x74             , 0x25             }, /* 0x0a:g */ \
    {0x26             , 0x26|MZ_SHIFT    , 0x26             , 0                , 0x5a             , 0x5a             , 0x26             }, /* 0x0b:h */ \
    {0x34             , 0x38|MZ_SHIFT    , 0x34             , 0                , 0x68             , 0x68             , 0x34             }, /* 0x0c:i */ \
    {0x35             , 0x35|MZ_SHIFT    , 0x35             , 0                , 0x69             , 0x69             , 0x35             }, /* 0x0d:j */ \
    {0x36             , 0x36|MZ_SHIFT    , 0x36             , 0                , 0x6a             , 0x6a             , 0x36             }, /* 0x0e:k */ \
    {0x45             , 0x45|MZ_SHIFT    , 0x45             , 0                , 0x79             , 0x79             , 0x45             }, /* 0x0f:l */ \
\
    {0x37             , 0x37|MZ_SHIFT    , 0x37             , 0                , 0                , 0                , 0x37             }, /* 0x10:m */ \
    {0x28             , 0x28|MZ_SHIFT    , 0x28             , 0                , 0                , 0                , 0x28             }, /* 0x11:n */ \
    {0x43             , 0x47|MZ_SHIFT    , 0x43             , 0                , 0x77             , 0x77             , 0x43             }, /* 0x12:o */ \
    {0x44             , 0x44|MZ_SHIFT    , 0x44             , 0                , 0x78             , 0x78             , 0x44             }, /* 0x13:p */ \
    {0x03             , 0x42|MZ_SHIFT    , 0x03             , 0x72             , 0x52             , 0x52             , 0x03             }, /* 0x14:q/[Pi] */ \
    {0x14             , 0x46|MZ_SHIFT    , 0x14             , 0                , 0x71             , 0x71             , 0x14             }, /* 0x15:r */ \
    {0x06             , 0x06|MZ_SHIFT    , 0x06             , 0x78             , 0x63             , 0x63             , 0x06             }, /* 0x16:s */ \
    {0x23             , 0x55|MZ_SHIFT    , 0x23             , 0                , 0x72             , 0x72             , 0x23             }, /* 0x17:t */ \
    {0x33             , 0x33|MZ_SHIFT    , 0x33             , 0                , 0x67             , 0x67             , 0x33             }, /* 0x18:u */ \
    {0x18             , 0x18|MZ_SHIFT    , 0x18             , 0                , 0x75             , 0x75             , 0x18             }, /* 0x19:v */ \
    {0x04             , 0                , 0x04             , 0x74             , 0x61             , 0x61             , 0x04             }, /* 0x1a:w */ \
    {0x08             , 0x08|MZ_SHIFT    , 0x08             , 0                , 0x65             , 0x65             , 0x08             }, /* 0x1b:x */ \
    {0x24             , 0x55             , 0x24             , 0                , 0x58             , 0x58             , 0x24             }, /* 0x1c:y */ \
    {0x07             , 0x07|MZ_SHIFT    , 0x07             , 0x77             , 0x56             , 0x56             , 0x07             }, /* 0x1d:z */ \
    {0x01             , 0x01|MZ_SHIFT    , 0x01             , 0                , 0                , 0                , 0x01             }, /* 0x1e:1/! */ \
    {0x02             , 0x02|MZ_SHIFT    , 0x02             , 0                , 0                , 0                , 0x02             }, /* 0x1f:2/" */ \
\
    {0x11             , 0x11|MZ_SHIFT    , 0x11             , 0x62             , 0                , 0                , 0x11             }, /* 0x20:3/# */ \
    {0x12             , 0x12|MZ_SHIFT    , 0x12             , 0x66             , 0                , 0                , 0x12             }, /* 0x21:4/$ */ \
    {0x21             , 0x21|MZ_SHIFT    , 0x21             , 0x68             , 0                , 0                , 0x21             }, /* 0x22:5/% */ \
    {0x22             , 0x22|MZ_SHIFT    , 0x22             , 0x6a             , 0                , 0                , 0x22             }, /* 0x23:6/& */ \
    {0x31             , 0x31|MZ_SHIFT    , 0x31             , 0x71             , 0                , 0                , 0x31             }, /* 0x24:7/' */ \
    {0x32             , 0x32|MZ_SHIFT    , 0x32             , 0x73             , 0                , 0                , 0x32             }, /* 0x25:8/( */ \
    {0x41             , 0x41|MZ_SHIFT    , 0x41             , 0x75             , 0                , 0                , 0x41             }, /* 0x26:9/) */ \
    {0x42             , 0x42|MZ_SHIFT    , 0x42             , 0x56             , 0                , 0                , 0x42             }, /* 0x27:0 */ \
    {0x49             , 0x49|MZ_SHIFT    , 0x49             , 0                , 0                , 0                , 0x49             }, /* 0x28:[RETURN] */ \
    {0x1a|MZ_SHIFT    , 0x1a|MZ_SHIFT    , 0x1a|MZ_SHIFT    , 0                , 0                , 0                , 0                }, /* 0x29:[ESC] = SHIFT+SPACE In Hu-BASIC */ \
    {0x19             , 0x19|MZ_SHIFT    , 0x19             , 0x19|MZ_SHIFT    , 0                , 0                , 0x19             }, /* 0x2a:[BS] = [INST/DEL] key */ \
    {0x0a             , 0x0a|MZ_SHIFT    , 0x0a             , 0x0a|MZ_SHIFT    , 0                , 0                , 0x0a             }, /* 0x2b:[TAB] = Assign as [HOME/CLR] */ \
    {0x1a             , 0x1a|MZ_SHIFT    , 0x1a             , 0x1a|MZ_SHIFT    , 0                , 0                , 0x1a             }, /* 0x2c:[SPACE] */ \
    {0x51             , 0x53             , 0x51             , 0                , 0                , 0                , 0x51             }, /* 0x2d:-/= : Different key when SHIFT */ \
    {0x44|MZ_SHIFT    , 0x54|MZ_SHIFT    , 0x53             , 0                , 0                , 0                , 0                }, /* 0x2e:^/~ = [Upper arrow] */ \
    {0x33|MZ_SHIFT    , 0                , 0x5a             , 0                , 0                , 0                , 0x53             }, /* 0x2f:@/` = @ */ \
\
    {0x14|MZ_SHIFT    , 0                , 0x58             , 0x61             , 0                , 0                , 0                }, /* 0x30:[/「 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x31:NA */ \
    {0x23|MZ_SHIFT    , 0                , 0x54             , 0x63             , 0                , 0                , 0                }, /* 0x32:]/」  */ \
    {0x46             , 0x51|MZ_SHIFT    , 0x46             , 0                , 0x7a             , 0x7a             , 0x46             }, /* 0x33:;/+ */ \
    {0x43|MZ_SHIFT    , 0x53|MZ_SHIFT    , 0x52             , 0                , 0                , 0                , 0x55             }, /* 0x34:':'/'*' */ \
    {0x3a             , 0x3a|MZ_SHIFT    , 0x3a             , 0x3a|MZ_SHIFT    , 0                , 0                , 0x3a             }, /* 0x35 ZEN/HAN = [BREAK] key */ \
    {0x38             , 0x03|MZ_SHIFT    , 0x38             , 0x65             , 0                , 0                , 0x38             }, /* 0x36:,/< */ \
    {0x47             , 0x04|MZ_SHIFT    , 0x47             , 0x69             , 0                , 0                , 0x47             }, /* 0x37:./> */ \
    {0x48             , 0x34|MZ_SHIFT    , 0x48             , 0x67             , 0                , 0                , 0x48             }, /* 0x38:'/'/'?' */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x57             }, /* 0x39: [CAPS] = assaign as [カナ/英数] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3a:[F1] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3b:[F2] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3c:[F3] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3d:[F4] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3e:[F5] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3f:[F6] */ \
\
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x40:[F7] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x41:[F8] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x42:[F9] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x43:[F10] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x44 [F11] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x45:[F12] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x46 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x47 */ \
    {0x3a             , 0x3a|MZ_SHIFT    , 0x3a             , 0x3a|MZ_SHIFT    , 0                , 0                , 0x3a             }, /* 0x48 Pause/Break */ \
    {0x19|MZ_SHIFT    , 0x19             , 0x19|MZ_SHIFT    , 0x19             , 0                , 0                , 0                }, /* 0x49 Insert = SHIFT + [DEL/INST] */ \
    {0x0a             , 0x0a|MZ_SHIFT    , 0x0a             , 0x0a|MZ_SHIFT    , 0                , 0                , 0x0a             }, /* 0x4a Home = [HOME/CLR] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4b PgUp = [] */ \
    {0x19             , 0x19|MZ_SHIFT    , 0x19             , 0x19|MZ_SHIFT    , 0                , 0                , 0x19             }, /* 0x4c Delete = [DEL/INST] key */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4d End */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x57             }, /* 0x4e:PgDn = [KANA] */ \
    {0x39             , 0x39|MZ_SHIFT    , 0x39             , 0x39|MZ_SHIFT    , 0                , 0                , 0x39             }, /* 0x4f right arrow */ \
\
    {0x39|MZ_SHIFT    , 0x39             , 0x39|MZ_SHIFT    , 0x39             , 0                , 0                , 0                }, /* 0x50 left arrow */ \
    {0x2a             , 0x2a|MZ_SHIFT    , 0x2a             , 0x2a|MZ_SHIFT    , 0                , 0                , 0x2a             }, /* 0x51 down arrow */ \
    {0x2a|MZ_SHIFT    , 0x2a             , 0x2a|MZ_SHIFT    , 0x2a             , 0                , 0                , 0                }, /* 0x52 up arrow */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x53 */ \
    {0x48             , 0x48|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x47             }, /* 0x54:/ */ \
    {0x53|MZ_SHIFT    , 0x53|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0                }, /* 0x55:* */ \
    {0x51             , 0x51|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x51             }, /* 0x56:- */ \
    {0x51|MZ_SHIFT    , 0x51|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0                }, /* 0x57:+ */ \
    {0x49             , 0x49|MZ_SHIFT    , 0x49             , 0x49|MZ_SHIFT    , 0                , 0                , 0x49             }, /* 0x58:[RETURN] */ \
    {0x01             , 0x01|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x01             }, /* 0x59:1 */ \
    {0x02             , 0x02|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x02             }, /* 0x5a:2 */ \
    {0x11             , 0x11|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x11             }, /* 0x5b:3 */ \
    {0x12             , 0x12|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x12             }, /* 0x5c:4 */ \
    {0x21             , 0x21|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x21             }, /* 0x5d:5 */ \
    {0x22             , 0x22|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x22             }, /* 0x5e:6 */ \
    {0x31             , 0x31|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x31             }, /* 0x5f:7 */ \
\
    {0x32             , 0x32|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x32             }, /* 0x60:8 */ \
    {0x41             , 0x41|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x41             }, /* 0x61:9 */ \
    {0x42             , 0x42|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x42             }, /* 0x62:0 */ \
    {0x47             , 0x47|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x47             }, /* 0x63:. */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x64 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x65:[Application] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x66 */ \
    {0x53             , 0x53|MZ_SHIFT    , 0                , 0                , 0                , 0                , 0x53             }, /* 0x67:= */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x68 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x69 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x70 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x71 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x72 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x73 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x74 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x75 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x76 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x77 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x78 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x79 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x80 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x81 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x82 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x83 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x84 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x85 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x86 */ \
    {0x24|MZ_SHIFT    , 0x5a             , 0x55             , 0                , 0                , 0                , 0x48             }, /* 0x87:[Backslash]/_ key, '←' */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x57             }, /* 0x88:[Hiragana/Katakana] = [カナ/英数]=カナ */ \
    {0x7a             , 0x65             , 0x72             , 0                , 0                , 0                , 0x24             }, /* 0x89:[Yen]/[|] key */ \
};

/* MZ-700J USB KB scan code to MZ switch matrix code
     w/o SHIFT        , w/ SHIFT         , kana             , kana+shift       , GRPH             , GRPH+shift       , RAW */
static keycode2SYX_t keycode2MZ700JSYX =  {
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x00   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x01   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x02   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x03   */ \
    {0x75             , 0x75|MZ_SHIFT    , 0x03             , 0                , 0x75             , 0x75|MZ_SHIFT    , 0x75             }, /* 0x04:a/ち */ \
    {0x65             , 0x65|MZ_SHIFT    , 0x43             , 0                , 0x65             , 0x65|MZ_SHIFT    , 0x65             }, /* 0x05:b/こ */ \
    {0x55             , 0x55|MZ_SHIFT    , 0x15             , 0                , 0x55             , 0x55|MZ_SHIFT    , 0x55             }, /* 0x06:c/そ */ \
    {0x45             , 0x45|MZ_SHIFT    , 0x53             , 0                , 0x45             , 0x45|MZ_SHIFT    , 0x45             }, /* 0x07:d/し */ \
    {0x35             , 0x35|MZ_SHIFT    , 0x66             , 0x66|MZ_SHIFT    , 0x35             , 0x35|MZ_SHIFT    , 0x35             }, /* 0x08:e/い */ \
    {0x25             , 0x25|MZ_SHIFT    , 0x72             , 0                , 0x25             , 0x25|MZ_SHIFT    , 0x25             }, /* 0x09:f/は */ \
    {0x15             , 0x15|MZ_SHIFT    , 0x13             , 0                , 0x15             , 0x15|MZ_SHIFT    , 0x15             }, /* 0x0a:g/き */ \
    {0x05             , 0x05|MZ_SHIFT    , 0x35             , 0                , 0x05             , 0x05|MZ_SHIFT    , 0x05             }, /* 0x0b:h/く */ \
    {0x74             , 0x74|MZ_SHIFT    , 0x16             , 0                , 0x74             , 0x74|MZ_SHIFT    , 0x74             }, /* 0x0c:i/に */ \
    {0x64             , 0x64|MZ_SHIFT    , 0x05             , 0                , 0x64             , 0x64|MZ_SHIFT    , 0x64             }, /* 0x0d:j/ま */ \
    {0x54             , 0x54|MZ_SHIFT    , 0x37             , 0                , 0x54             , 0x54|MZ_SHIFT    , 0x54             }, /* 0x0e:k/の */ \
    {0x44             , 0x44|MZ_SHIFT    , 0x34             , 0                , 0x44             , 0x44|MZ_SHIFT    , 0x44             }, /* 0x0f:l/り */ \
\
    {0x34             , 0x34|MZ_SHIFT    , 0x21             , 0                , 0x34             , 0x34|MZ_SHIFT    , 0x34             }, /* 0x10:m/も */ \
    {0x24             , 0x24|MZ_SHIFT    , 0x64             , 0                , 0x24             , 0x24|MZ_SHIFT    , 0x24             }, /* 0x11:n/み */ \
    {0x14             , 0x14|MZ_SHIFT    , 0x24             , 0                , 0x14             , 0x14|MZ_SHIFT    , 0x14             }, /* 0x12:o/ら */ \
    {0x04             , 0x04|MZ_SHIFT    , 0x25             , 0                , 0x04             , 0x04|MZ_SHIFT    , 0x04             }, /* 0x13:p/せ */ \
    {0x73             , 0x73|MZ_SHIFT    , 0x62             , 0                , 0x73             , 0x73|MZ_SHIFT    , 0x73             }, /* 0x14:q/た */ \
    {0x63             , 0x63|MZ_SHIFT    , 0x45             , 0                , 0x63             , 0x63|MZ_SHIFT    , 0x63             }, /* 0x15:r/す */ \
    {0x53             , 0x53|MZ_SHIFT    , 0x65             , 0                , 0x53             , 0x53|MZ_SHIFT    , 0x53             }, /* 0x16:s/と */ \
    {0x43             , 0x43|MZ_SHIFT    , 0x73             , 0                , 0x43             , 0x43|MZ_SHIFT    , 0x43             }, /* 0x17:t/か */ \
    {0x33             , 0x33|MZ_SHIFT    , 0x26             , 0                , 0x33             , 0x33|MZ_SHIFT    , 0x33             }, /* 0x18:u/な */ \
    {0x23             , 0x23|MZ_SHIFT    , 0x33             , 0                , 0x23             , 0x23|MZ_SHIFT    , 0x23             }, /* 0x19:v/ひ */ \
    {0x13             , 0x13|MZ_SHIFT    , 0x23             , 0                , 0x13             , 0x13|MZ_SHIFT    , 0x13             }, /* 0x1a:w/て */ \
    {0x03             , 0x03|MZ_SHIFT    , 0x75             , 0                , 0x03             , 0x03|MZ_SHIFT    , 0x03             }, /* 0x1b:x/さ */ \
    {0x72             , 0x72|MZ_SHIFT    , 0x51             , 0                , 0x72             , 0x72|MZ_SHIFT    , 0x72             }, /* 0x1c:y/ん */ \
    {0x62             , 0x62|MZ_SHIFT    , 0x55             , 0x55|MZ_SHIFT    , 0x62             , 0x62|MZ_SHIFT    , 0x62             }, /* 0x1d:z/つ */ \
    {0x76             , 0x76|MZ_SHIFT    , 0x06             , 0                , 0x76             , 0x76|MZ_SHIFT    , 0x76             }, /* 0x1e:1/!/ぬ */ \
    {0x66             , 0x66|MZ_SHIFT    , 0x74             , 0                , 0x66             , 0x66|MZ_SHIFT    , 0x66             }, /* 0x1f:2/"/ふ */ \
\
    {0x56             , 0x56|MZ_SHIFT    , 0x76             , 0x76|MZ_SHIFT    , 0x56             , 0x56|MZ_SHIFT    , 0x56             }, /* 0x20:3/#/あ */ \
    {0x46             , 0x46|MZ_SHIFT    , 0x56             , 0x56|MZ_SHIFT    , 0x46             , 0x46|MZ_SHIFT    , 0x46             }, /* 0x21:4/$/う */ \
    {0x36             , 0x36|MZ_SHIFT    , 0x46             , 0x46|MZ_SHIFT    , 0x36             , 0x36|MZ_SHIFT    , 0x36             }, /* 0x22:5/%/え */ \
    {0x26             , 0x26|MZ_SHIFT    , 0x36             , 0x36|MZ_SHIFT    , 0x26             , 0x26|MZ_SHIFT    , 0x26             }, /* 0x23:6/&/お */ \
    {0x16             , 0x16|MZ_SHIFT    , 0x57             , 0x57|MZ_SHIFT    , 0x16             , 0x16|MZ_SHIFT    , 0x16             }, /* 0x24:7/'/や */ \
    {0x06             , 0x42             , 0x67             , 0x67|MZ_SHIFT    , 0x06             , 0x06|MZ_SHIFT    , 0x06             }, /* 0x25:8/[/ゆ */ \
    {0x27             , 0x32             , 0x77             , 0x77|MZ_SHIFT    , 0x27             , 0x27|MZ_SHIFT    , 0x27             }, /* 0x26:9/]/よ */ \
    {0x37             , 0x37|MZ_SHIFT    , 0x52             , 0x42             , 0x37             , 0x37|MZ_SHIFT    , 0x37             }, /* 0x27:0/[Pi]/わ/を */ \
    {0x01             , 0x01|MZ_SHIFT    , 0x01             , 0x01|MZ_SHIFT    , 0x01             , 0x01|MZ_SHIFT    , 0x01             }, /* 0x28:[RETURN] */ \
    {0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0                }, /* 0x29:[ESC] = SHIFT+SPACE In Hu-BASIC */ \
    {0x68             , 0x68             , 0x68             , 0x68             , 0x68             , 0x68             , 0x68             }, /* 0x2a:[BS] = [DEL] key */ \
    {0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0                }, /* 0x2b:[TAB] = Assign as [HOME]=[SHIFT]+[DEL]/[CLR]=[SHIFT]+[INST] */ \
    {0x47             , 0x47|MZ_SHIFT    , 0x47             , 0x47|MZ_SHIFT    , 0x47             , 0x47|MZ_SHIFT    , 0x47             }, /* 0x2c:[SPACE] */ \
    {0x57             , 0x51|MZ_SHIFT    , 0x04             , 0                , 0x57             , 0x57|MZ_SHIFT    , 0x57             }, /* 0x2d:'-'/'='/ほ */ \
    {0x42|MZ_SHIFT    , 0x67|MZ_SHIFT    , 0x14             , 0                , 0                , 0                , 0x51             }, /* 0x2e:'^'/'~'/へ = [Upper arrow]/￡ */ \
    {0x52             , 0x52|MZ_SHIFT    , 0x11             , 0                , 0x52             , 0x52|MZ_SHIFT    , 0x52             }, /* 0x2f:'@'/'`'/゛ */ \
\
    {0x16|MZ_SHIFT    , 0x42|MZ_SHIFT    , 0x32             , 042|MZ_SHIFT     , 0x42             , 0x42|MZ_SHIFT    , 0x42             }, /* 0x30:'['/'{'/゜/「 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x31: */ \
    {0x27|MZ_SHIFT    , 0x32|MZ_SHIFT    , 0x54             , 0x32|MZ_SHIFT    , 0x32             , 0x32|MZ_SHIFT    , 0x32             }, /* 0x32:']'/'}'/む/」  */ \
    {0x21             , 0x67             , 0x07             , 0                , 0x21             , 0x21|MZ_SHIFT    , 0x21             }, /* 0x33:';'/'+'/れ */ \
    {0x11             , 0x77             , 0x63             , 0                , 0                , 0                , 0x11             }, /* 0x34:':'/'*'/け */ \
    {0x79             , 0x79|MZ_SHIFT    , 0x79             , 0x79|MZ_SHIFT    , 0x79             , 0x79|MZ_SHIFT    , 0x79             }, /* 0x35 ZEN/HAN = [BREAK] key */ \
    {0x17             , 0x17|MZ_SHIFT    , 0x37             , 0x17|MZ_SHIFT    , 0x17             , 0x17|MZ_SHIFT    , 0x17             }, /* 0x36:','/'<'/ね/、 */ \
    {0x07             , 0x07|MZ_SHIFT    , 0x17             , 0x07|MZ_SHIFT    , 0x07             , 0x07|MZ_SHIFT    , 0x07             }, /* 0x37:'.'/'>'/る/。 */ \
    {0x08             , 0x18             , 0x44             , 0                , 0x08             , 0x08|MZ_SHIFT    , 0x08             }, /* 0x38:'/'/'?'/め/・ */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x41             }, /* 0x39: [CAPS] = assaign as [英数] */ \
    {0x7a             , 0x7a|MZ_SHIFT    , 0x7a             , 0x7a|MZ_SHIFT    , 0x7a             , 0x7a|MZ_SHIFT    , 0x7a             }, /* 0x3a:[F1] */ \
    {0x6a             , 0x6a|MZ_SHIFT    , 0x6a             , 0x6a|MZ_SHIFT    , 0x6a             , 0x6a|MZ_SHIFT    , 0x6a             }, /* 0x3b:[F2] */ \
    {0x5a             , 0x5a|MZ_SHIFT    , 0x5a             , 0x5a|MZ_SHIFT    , 0x5a             , 0x5a|MZ_SHIFT    , 0x5a             }, /* 0x3c:[F3] */ \
    {0x4a             , 0x4a|MZ_SHIFT    , 0x4a             , 0x4a|MZ_SHIFT    , 0x4a             , 0x4a|MZ_SHIFT    , 0x4a             }, /* 0x3d:[F4] */ \
    {0x3a             , 0x3a|MZ_SHIFT    , 0x3a             , 0x3a|MZ_SHIFT    , 0x3a             , 0x3a|MZ_SHIFT    , 0x3a             }, /* 0x3e:[F5] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3f:[F6] */ \
\
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x40:[F7] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x41:[F8] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x42:[F9] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x43:[F10] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x44 [F11] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x45:[F12] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x46 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x47 */ \
    {0x79             , 0x79|MZ_SHIFT    , 0x79             , 0x79|MZ_SHIFT    , 0x79             , 0x79|MZ_SHIFT    , 0x79             }, /* 0x48 Pause/Break = [BREAK] */ \
    {0x78             , 0x78             , 0x78             , 0x78             , 0x78             , 0x78             , 0x78             }, /* 0x49 Insert = [INST] */ \
    {0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0x68             , 0x78             , 0                }, /* 0x4a Home = [SHIFT]+[DEL] / [SHIFT]+[INST] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x61             }, /* 0x4b PgUp = [GRPH] */ \
    {0x68             , 0x68             , 0x68             , 0x68             , 0x68             , 0x68             , 0x68             }, /* 0x4c Delete = [DEL] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4d End */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x71             }, /* 0x4e PgDn = [KANA] */ \
    {0x38             , 0x38|MZ_SHIFT    , 0x38             , 0x38|MZ_SHIFT    , 0x38             , 0x38|MZ_SHIFT    , 0x38             }, /* 0x4f right arrow */ \
\
    {0x28             , 0x28|MZ_SHIFT    , 0x28             , 0x28|MZ_SHIFT    , 0x28             , 0x28|MZ_SHIFT    , 0x28             }, /* 0x50 left arrow */ \
    {0x48             , 0x48|MZ_SHIFT    , 0x48             , 0x48|MZ_SHIFT    , 0x48             , 0x48|MZ_SHIFT    , 0x48             }, /* 0x51 down arrow */ \
    {0x58             , 0x58|MZ_SHIFT    , 0x58             , 0x58|MZ_SHIFT    , 0x58             , 0x58|MZ_SHIFT    , 0x58             }, /* 0x52 up arrow */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x53 NumLock */ \
    {0x08             , 0x08|MZ_SHIFT    , 0x08             , 0x08|MZ_SHIFT    , 0x08             , 0x08|MZ_SHIFT    , 0x08             }, /* 0x54:/ */ \
    {0x77             , 0x77|MZ_SHIFT    , 0x77             , 0x77|MZ_SHIFT    , 0x77             , 0x77|MZ_SHIFT    , 0x77             }, /* 0x55:* */ \
    {0x57             , 0x57|MZ_SHIFT    , 0x57             , 0x57|MZ_SHIFT    , 0x57             , 0x57|MZ_SHIFT    , 0x57             }, /* 0x56:- */ \
    {0x67             , 0x67|MZ_SHIFT    , 0x67             , 0x67|MZ_SHIFT    , 0x67             , 0x67|MZ_SHIFT    , 0x67             }, /* 0x57:+ */ \
    {0x01             , 0x01|MZ_SHIFT    , 0x01             , 0x01|MZ_SHIFT    , 0x01             , 0x01|MZ_SHIFT    , 0x01             }, /* 0x58:[RETURN] */ \
    {0x76             , 0x76|MZ_SHIFT    , 0x76             , 0x76|MZ_SHIFT    , 0x76             , 0x76|MZ_SHIFT    , 0x76             }, /* 0x59:1 */ \
    {0x66             , 0x66|MZ_SHIFT    , 0x66             , 0x66|MZ_SHIFT    , 0x66             , 0x66|MZ_SHIFT    , 0x66             }, /* 0x5a:2 */ \
    {0x56             , 0x56|MZ_SHIFT    , 0x56             , 0x56|MZ_SHIFT    , 0x56             , 0x56|MZ_SHIFT    , 0x56             }, /* 0x5b:3 */ \
    {0x46             , 0x46|MZ_SHIFT    , 0x46             , 0x46|MZ_SHIFT    , 0x46             , 0x46|MZ_SHIFT    , 0x46             }, /* 0x5c:4 */ \
    {0x36             , 0x36|MZ_SHIFT    , 0x36             , 0x36|MZ_SHIFT    , 0x36             , 0x36|MZ_SHIFT    , 0x36             }, /* 0x5d:5 */ \
    {0x26             , 0x26|MZ_SHIFT    , 0x26             , 0x26|MZ_SHIFT    , 0x26             , 0x26|MZ_SHIFT    , 0x26             }, /* 0x5e:6 */ \
    {0x16             , 0x16|MZ_SHIFT    , 0x16             , 0x16|MZ_SHIFT    , 0x16             , 0x16|MZ_SHIFT    , 0x16             }, /* 0x5f:7 */ \
\
    {0x06             , 0x06|MZ_SHIFT    , 0x06             , 0x06|MZ_SHIFT    , 0x06             , 0x06|MZ_SHIFT    , 0x06             }, /* 0x60:8 */ \
    {0x27             , 0x27|MZ_SHIFT    , 0x27             , 0x27|MZ_SHIFT    , 0x27             , 0x27|MZ_SHIFT    , 0x27             }, /* 0x61:9 */ \
    {0x37             , 0x37|MZ_SHIFT    , 0x37             , 0x37|MZ_SHIFT    , 0x37             , 0x37|MZ_SHIFT    , 0x37             }, /* 0x62:0 */ \
    {0x07             , 0x07|MZ_SHIFT    , 0x07             , 0x07|MZ_SHIFT    , 0x07             , 0x07|MZ_SHIFT    , 0x01             }, /* 0x63:. */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x64 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x65:[Application] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x66 */ \
    {0x51             , 0x51|MZ_SHIFT    , 0x51             , 0x51|MZ_SHIFT    , 0x51             , 0x51|MZ_SHIFT    , 0x51             }, /* 0x67:= */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x68 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x69 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x70 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x71 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x72 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x73 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x74 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x75 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x76 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x77 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x78 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x79 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x80 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x81 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x82 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x83 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x84 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x85 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x86 */ \
    {0x57|MZ_SHIFT    , 0x08|MZ_SHIFT    , 0x08             , 0                , 0                , 0                , 0x18             }, /* 0x87:[Backslash]/_/ろ key = [￥][←][/] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x71             }, /* 0x88:[Hiragana/Katakana] = [カナ] */ \
    {0x57|MZ_SHIFT    , 0x18|MZ_SHIFT    , 0x18             , 0                , 0                , 0                , 0x24             }, /* 0x89:[Yen]/[|]/ー key = [￥][→] */ \
};

/* MZ-80A USB KB scan code to MZ switch matrix code
     w/o SHIFT        , w/ SHIFT         , kana             , kana+shift       , GRPH             , GRPH+shift       , RAW */
static keycode2SYX_t keycode2MZ80ASYX =  {
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x00   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x01   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x02   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x03   */ \
    {0x32             , 0x32|MZ_SHIFT    , 0                , 0                , 0x32             , 0x32|MZ_SHIFT    , 0x32             }, /* 0x04:a */ \
    {0x04             , 0x04|MZ_SHIFT    , 0                , 0                , 0x04             , 0x04|MZ_SHIFT    , 0x04             }, /* 0x05:b */ \
    {0x03             , 0x03|MZ_SHIFT    , 0                , 0                , 0x03             , 0x03|MZ_SHIFT    , 0x03             }, /* 0x06:c */ \
    {0x33             , 0x33|MZ_SHIFT    , 0                , 0                , 0x33             , 0x33|MZ_SHIFT    , 0x33             }, /* 0x07:d */ \
    {0x43             , 0x43|MZ_SHIFT    , 0                , 0                , 0x43             , 0x43|MZ_SHIFT    , 0x43             }, /* 0x08:e */ \
    {0x24             , 0x24|MZ_SHIFT    , 0                , 0                , 0x24             , 0x24|MZ_SHIFT    , 0x24             }, /* 0x09:f */ \
    {0x34             , 0x34|MZ_SHIFT    , 0                , 0                , 0x34             , 0x34|MZ_SHIFT    , 0x34             }, /* 0x0a:g */ \
    {0x25             , 0x25|MZ_SHIFT    , 0                , 0                , 0x25             , 0x25|MZ_SHIFT    , 0x25             }, /* 0x0b:h */ \
    {0x55             , 0x55|MZ_SHIFT    , 0                , 0                , 0x55             , 0x55|MZ_SHIFT    , 0x55             }, /* 0x0c:i */ \
    {0x35             , 0x35|MZ_SHIFT    , 0                , 0                , 0x35             , 0x35|MZ_SHIFT    , 0x35             }, /* 0x0d:j */ \
    {0x26             , 0x26|MZ_SHIFT    , 0                , 0                , 0x26             , 0x26|MZ_SHIFT    , 0x26             }, /* 0x0e:k */ \
    {0x36             , 0x36|MZ_SHIFT    , 0                , 0                , 0x36             , 0x36|MZ_SHIFT    , 0x36             }, /* 0x0f:l */ \
\
    {0x06             , 0x06|MZ_SHIFT    , 0                , 0                , 0x06             , 0x06|MZ_SHIFT    , 0x06             }, /* 0x10:m */ \
    {0x15             , 0x15|MZ_SHIFT    , 0                , 0                , 0x15             , 0x15|MZ_SHIFT    , 0x15             }, /* 0x11:n */ \
    {0x46             , 0x46|MZ_SHIFT    , 0                , 0                , 0x46             , 0x46|MZ_SHIFT    , 0x46             }, /* 0x12:o */ \
    {0x56             , 0x56|MZ_SHIFT    , 0                , 0                , 0x56             , 0x56|MZ_SHIFT    , 0x56             }, /* 0x13:p */ \
    {0x42             , 0x42|MZ_SHIFT    , 0                , 0                , 0x42             , 0x42|MZ_SHIFT    , 0x42             }, /* 0x14:q */ \
    {0x53             , 0x53|MZ_SHIFT    , 0                , 0                , 0x53             , 0x53|MZ_SHIFT    , 0x53             }, /* 0x15:r */ \
    {0x23             , 0x23|MZ_SHIFT    , 0                , 0                , 0x23             , 0x23|MZ_SHIFT    , 0x23             }, /* 0x16:s */ \
    {0x44             , 0x44|MZ_SHIFT    , 0                , 0                , 0x44             , 0x44|MZ_SHIFT    , 0x44             }, /* 0x17:t */ \
    {0x45             , 0x45|MZ_SHIFT    , 0                , 0                , 0x45             , 0x45|MZ_SHIFT    , 0x45             }, /* 0x18:u */ \
    {0x14             , 0x14|MZ_SHIFT    , 0                , 0                , 0x14             , 0x14|MZ_SHIFT    , 0x14             }, /* 0x19:v */ \
    {0x52             , 0x52|MZ_SHIFT    , 0                , 0                , 0x52             , 0x52|MZ_SHIFT    , 0x52             }, /* 0x1a:w */ \
    {0x13             , 0x13|MZ_SHIFT    , 0                , 0                , 0x13             , 0x13|MZ_SHIFT    , 0x13             }, /* 0x1b:x */ \
    {0x54             , 0x54|MZ_SHIFT    , 0                , 0                , 0x54             , 0x54|MZ_SHIFT    , 0x54             }, /* 0x1c:y */ \
    {0x02             , 0x02|MZ_SHIFT    , 0                , 0                , 0x02             , 0x02|MZ_SHIFT    , 0x02             }, /* 0x1d:z */ \
    {0x62             , 0x62|MZ_SHIFT    , 0                , 0                , 0x62             , 0x62|MZ_SHIFT    , 0x62             }, /* 0x1e:1/! */ \
    {0x72             , 0x72|MZ_SHIFT    , 0                , 0                , 0x72             , 0x72|MZ_SHIFT    , 0x72             }, /* 0x1f:2/" */ \
\
    {0x63             , 0x63|MZ_SHIFT    , 0                , 0                , 0x63             , 0x63|MZ_SHIFT    , 0x63             }, /* 0x20:3/# */ \
    {0x73             , 0x73|MZ_SHIFT    , 0                , 0                , 0x73             , 0x73|MZ_SHIFT    , 0x73             }, /* 0x21:4/$ */ \
    {0x64             , 0x64|MZ_SHIFT    , 0                , 0                , 0x64             , 0x64|MZ_SHIFT    , 0x64             }, /* 0x22:5/% */ \
    {0x74             , 0x74|MZ_SHIFT    , 0                , 0                , 0x74             , 0x74|MZ_SHIFT    , 0x74             }, /* 0x23:6/& */ \
    {0x65             , 0x65|MZ_SHIFT    , 0                , 0                , 0x65             , 0x65|MZ_SHIFT    , 0x65             }, /* 0x24:7/' */ \
    {0x75             , 0x75|MZ_SHIFT    , 0                , 0                , 0x75             , 0x75|MZ_SHIFT    , 0x75             }, /* 0x25:8/( */ \
    {0x66             , 0x66|MZ_SHIFT    , 0                , 0                , 0x66             , 0x66|MZ_SHIFT    , 0x66             }, /* 0x26:9/) */ \
    {0x76             , 0x76|MZ_SHIFT    , 0                , 0                , 0x76             , 0x76|MZ_SHIFT    , 0x76             }, /* 0x27:0 */ \
    {0x38             , 0x38|MZ_SHIFT    , 0                , 0                , 0x38             , 0x38|MZ_SHIFT    , 0x38             }, /* 0x28:[RETURN] */ \
    {0x05|MZ_SHIFT    , 0x05|MZ_SHIFT    , 0                , 0                , 0x05|MZ_SHIFT    , 0x05|MZ_SHIFT    , 0                }, /* 0x29:[ESC] = SHIFT+SPACE In Hu-BASIC */ \
    {0x22             , 0x22|MZ_SHIFT    , 0                , 0                , 0x22             , 0x22|MZ_SHIFT    , 0x22             }, /* 0x2a:[BS] = [INST/DEL] key */ \
    {0x78             , 0x78|MZ_SHIFT    , 0                , 0                , 0x78             , 0x78|MZ_SHIFT    , 0x78             }, /* 0x2b:[TAB] = Assign as [HOME/CLR] */ \
    {0x05             , 0x05|MZ_SHIFT    , 0                , 0                , 0x05             , 0x05|MZ_SHIFT    , 0x05             }, /* 0x2c:[SPACE] */ \
    {0x67             , 0x67|MZ_SHIFT    , 0                , 0                , 0x67             , 0x67|MZ_SHIFT    , 0x67             }, /* 0x2d:-/= */ \
    {0x77             , 0x77|MZ_SHIFT    , 0                , 0                , 0x77             , 0x77|MZ_SHIFT    , 0x77             }, /* 0x2e:^/~ */ \
    {0x47             , 0x47|MZ_SHIFT    , 0                , 0                , 0x47             , 0x47|MZ_SHIFT    , 0x47             }, /* 0x2f:@/` = @ */ \
\
    {0x57             , 0x57|MZ_SHIFT    , 0                , 0                , 0x57             , 0x57|MZ_SHIFT    , 0x57             }, /* 0x30:[/{ */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x31:NA */ \
    {0x28             , 0x28|MZ_SHIFT    , 0                , 0                , 0x28             , 0x28|MZ_SHIFT    , 0x28             }, /* 0x32:]/}  */ \
    {0x27             , 0x27|MZ_SHIFT    , 0                , 0                , 0x27             , 0x27|MZ_SHIFT    , 0x27             }, /* 0x33:;/+ */ \
    {0x37             , 0x37|MZ_SHIFT    , 0                , 0                , 0x37             , 0x37|MZ_SHIFT    , 0x37             }, /* 0x34:':'/'*' */ \
    {0x71             , 0x71|MZ_SHIFT    , 0                , 0                , 0x71             , 0x71|MZ_SHIFT    , 0x71             }, /* 0x35 ZEN/HAN = [BREAK] key */ \
    {0x16             , 0x16|MZ_SHIFT    , 0                , 0                , 0x16             , 0x16|MZ_SHIFT    , 0x16             }, /* 0x36:,/< */ \
    {0x07             , 0x07|MZ_SHIFT    , 0                , 0                , 0x07             , 0x07|MZ_SHIFT    , 0x07             }, /* 0x37:./> */ \
    {0x17             , 0x08             , 0                , 0                , 0x17             , 0x08             , 0x17             }, /* 0x38:'/'/'?' */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x12             }, /* 0x39: [CAPS] = assaign as [ALPHA] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3a:[F1] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3b:[F2] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3c:[F3] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3d:[F4] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3e:[F5] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3f:[F6] */ \
\
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x40:[F7] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x41:[F8] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x42:[F9] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x43:[F10] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x44 [F11] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x45:[F12] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x46 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x47 */ \
    {0x71             , 0x71|MZ_SHIFT    , 0                , 0                , 0x71             , 0x71|MZ_SHIFT    , 0x71             }, /* 0x48 Pause/Break */ \
    {0x22|MZ_SHIFT    , 0x22             , 0                , 0                , 0x22|MZ_SHIFT    , 0x22             , 0                }, /* 0x49 Insert = SHIFT + [DEL/INST] */ \
    {0x78             , 0x78|MZ_SHIFT    , 0                , 0                , 0x78             , 0x78|MZ_SHIFT    , 0x78             }, /* 0x4a Home = [HOME/CLR] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x11             }, /* 0x4b PgUp = [GRPH] */ \
    {0x22             , 0x19|MZ_SHIFT    , 0                , 0                , 0x22             , 0x19|MZ_SHIFT    , 0x22             }, /* 0x4c Delete = [DEL/INST] key */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4d End */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4e PgDn = [] */ \
    {0x58             , 0x58|MZ_SHIFT    , 0                , 0                , 0x58             , 0x58|MZ_SHIFT    , 0x58             }, /* 0x4f right arrow */ \
\
    {0x58|MZ_SHIFT    , 0x58             , 0                , 0                , 0x58|MZ_SHIFT    , 0x58             , 0                }, /* 0x50 left arrow */ \
    {0x48|MZ_SHIFT    , 0x48             , 0                , 0                , 0x48|MZ_SHIFT    , 0x48             , 0                }, /* 0x51 down arrow */ \
    {0x48             , 0x48|MZ_SHIFT    , 0                , 0                , 0x48             , 0x48|MZ_SHIFT    , 0x48             }, /* 0x52 up arrow */ \
    {0x19             , 0x19|MZ_SHIFT    , 0                , 0                , 0x19             , 0x19|MZ_SHIFT    , 0x19             }, /* 0x53 NumLock = [00] key */ \
    {0x17             , 0x17|MZ_SHIFT    , 0x17             , 0x17|MZ_SHIFT    , 0x17             , 0x17|MZ_SHIFT    , 0x17             }, /* 0x54:/ */ \
    {0x37|MZ_SHIFT    , 0x37|MZ_SHIFT    , 0                , 0                , 0x37|MZ_SHIFT    , 0x37|MZ_SHIFT    , 0                }, /* 0x55:* */ \
    {0x5a             , 0x5a|MZ_SHIFT    , 0                , 0                , 0x5a             , 0x5a|MZ_SHIFT    , 0x5a             }, /* 0x56:- */ \
    {0x7a             , 0x7a|MZ_SHIFT    , 0                , 0                , 0x7a             , 0x7a|MZ_SHIFT    , 0x7a             }, /* 0x57:+ */ \
    {0x38             , 0x38|MZ_SHIFT    , 0                , 0                , 0x38             , 0x38|MZ_SHIFT    , 0x38             }, /* 0x58:[RETURN] */ \
    {0x29             , 0x29|MZ_SHIFT    , 0                , 0                , 0x29             , 0x29|MZ_SHIFT    , 0x29             }, /* 0x59:1 */ \
    {0x39             , 0x39|MZ_SHIFT    , 0                , 0                , 0x39             , 0x39|MZ_SHIFT    , 0x39             }, /* 0x5a:2 */ \
    {0x2a             , 0x2a|MZ_SHIFT    , 0                , 0                , 0x2a             , 0x2a|MZ_SHIFT    , 0x2a             }, /* 0x5b:3 */ \
    {0x49             , 0x49|MZ_SHIFT    , 0                , 0                , 0x49             , 0x49|MZ_SHIFT    , 0x49             }, /* 0x5c:4 */ \
    {0x59             , 0x59|MZ_SHIFT    , 0                , 0                , 0x59             , 0x59|MZ_SHIFT    , 0x59             }, /* 0x5d:5 */ \
    {0x4a             , 0x4a|MZ_SHIFT    , 0                , 0                , 0x4a             , 0x4a|MZ_SHIFT    , 0x4a             }, /* 0x5e:6 */ \
    {0x69             , 0x69|MZ_SHIFT    , 0                , 0                , 0x69             , 0x69|MZ_SHIFT    , 0x69             }, /* 0x5f:7 */ \
\
    {0x79             , 0x79|MZ_SHIFT    , 0                , 0                , 0x79             , 0x79|MZ_SHIFT    , 0x79             }, /* 0x60:8 */ \
    {0x6a             , 0x6a|MZ_SHIFT    , 0                , 0                , 0x6a             , 0x6a|MZ_SHIFT    , 0x6a             }, /* 0x61:9 */ \
    {0x09             , 0x09|MZ_SHIFT    , 0                , 0                , 0x09             , 0x09|MZ_SHIFT    , 0x09             }, /* 0x62:0 */ \
    {0x0a             , 0x0a|MZ_SHIFT    , 0                , 0                , 0x0a             , 0x0a|MZ_SHIFT    , 0x0a             }, /* 0x63:. */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x64 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x65:[Application] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x66 */ \
    {0x67|MZ_SHIFT    , 0x53|MZ_SHIFT    , 0                , 0                , 0x67|MZ_SHIFT    , 0x53|MZ_SHIFT    , 0                }, /* 0x67:= */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x68 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x69 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x70 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x71 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x72 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x73 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x74 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x75 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x76 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x77 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x78 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x79 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x80 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x81 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x82 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x83 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x84 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x85 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x86 */ \
    {0x08             , 0x08|MZ_SHIFT    , 0                , 0                , 0x08             , 0x08|MZ_SHIFT    , 0x08             }, /* 0x87:[Backslash]/_ key, ?↑ */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x88:[Hiragana/Katakana] = [カナ/英数]=カナ */ \
    {0x68             , 0x68|MZ_SHIFT    , 0                , 0                , 0x68             , 0x68|MZ_SHIFT    , 0x68             }, /* 0x89:[Yen]/[|] key */ \
};

/* MZ-700E USB KB scan code to MZ switch matrix code
     w/o SHIFT        , w/ SHIFT         , kana             , kana+shift       , GRPH             , GRPH+shift       , RAW */
static keycode2SYX_t keycode2MZ700ESYX =  {
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x00   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x01   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x02   */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x03   */ \
    {0x75             , 0x75|MZ_SHIFT    , 0                , 0                , 0x75             , 0x75|MZ_SHIFT    , 0x75             }, /* 0x04:a */ \
    {0x65             , 0x65|MZ_SHIFT    , 0                , 0                , 0x65             , 0x65|MZ_SHIFT    , 0x65             }, /* 0x05:b */ \
    {0x55             , 0x55|MZ_SHIFT    , 0                , 0                , 0x55             , 0x55|MZ_SHIFT    , 0x55             }, /* 0x06:c */ \
    {0x45             , 0x45|MZ_SHIFT    , 0                , 0                , 0x45             , 0x45|MZ_SHIFT    , 0x45             }, /* 0x07:d */ \
    {0x35             , 0x35|MZ_SHIFT    , 0                , 0                , 0x35             , 0x35|MZ_SHIFT    , 0x35             }, /* 0x08:e */ \
    {0x25             , 0x25|MZ_SHIFT    , 0                , 0                , 0x25             , 0x25|MZ_SHIFT    , 0x25             }, /* 0x09:f */ \
    {0x15             , 0x15|MZ_SHIFT    , 0                , 0                , 0x15             , 0x15|MZ_SHIFT    , 0x15             }, /* 0x0a:g */ \
    {0x05             , 0x05|MZ_SHIFT    , 0                , 0                , 0x05             , 0x05|MZ_SHIFT    , 0x05             }, /* 0x0b:h */ \
    {0x74             , 0x74|MZ_SHIFT    , 0                , 0                , 0x74             , 0x74|MZ_SHIFT    , 0x74             }, /* 0x0c:i */ \
    {0x64             , 0x64|MZ_SHIFT    , 0                , 0                , 0x64             , 0x64|MZ_SHIFT    , 0x64             }, /* 0x0d:j */ \
    {0x54             , 0x54|MZ_SHIFT    , 0                , 0                , 0x54             , 0x54|MZ_SHIFT    , 0x54             }, /* 0x0e:k */ \
    {0x44             , 0x44|MZ_SHIFT    , 0                , 0                , 0x44             , 0x44|MZ_SHIFT    , 0x44             }, /* 0x0f:l */ \
\
    {0x34             , 0x34|MZ_SHIFT    , 0                , 0                , 0x34             , 0x34|MZ_SHIFT    , 0x34             }, /* 0x10:m */ \
    {0x24             , 0x24|MZ_SHIFT    , 0                , 0                , 0x24             , 0x24|MZ_SHIFT    , 0x24             }, /* 0x11:n */ \
    {0x14             , 0x14|MZ_SHIFT    , 0                , 0                , 0x14             , 0x14|MZ_SHIFT    , 0x14             }, /* 0x12:o */ \
    {0x04             , 0x04|MZ_SHIFT    , 0                , 0                , 0x04             , 0x04|MZ_SHIFT    , 0x04             }, /* 0x13:p */ \
    {0x73             , 0x73|MZ_SHIFT    , 0                , 0                , 0x73             , 0x73|MZ_SHIFT    , 0x73             }, /* 0x14:q */ \
    {0x63             , 0x63|MZ_SHIFT    , 0                , 0                , 0x63             , 0x63|MZ_SHIFT    , 0x63             }, /* 0x15:r */ \
    {0x53             , 0x53|MZ_SHIFT    , 0                , 0                , 0x53             , 0x53|MZ_SHIFT    , 0x53             }, /* 0x16:s */ \
    {0x43             , 0x43|MZ_SHIFT    , 0                , 0                , 0x43             , 0x43|MZ_SHIFT    , 0x43             }, /* 0x17:t */ \
    {0x33             , 0x33|MZ_SHIFT    , 0                , 0                , 0x33             , 0x33|MZ_SHIFT    , 0x33             }, /* 0x18:u */ \
    {0x23             , 0x23|MZ_SHIFT    , 0                , 0                , 0x23             , 0x23|MZ_SHIFT    , 0x23             }, /* 0x19:v */ \
    {0x13             , 0x13|MZ_SHIFT    , 0                , 0                , 0x13             , 0x13|MZ_SHIFT    , 0x13             }, /* 0x1a:w */ \
    {0x03             , 0x03|MZ_SHIFT    , 0                , 0                , 0x03             , 0x03|MZ_SHIFT    , 0x03             }, /* 0x1b:x */ \
    {0x72             , 0x72|MZ_SHIFT    , 0                , 0                , 0x72             , 0x72|MZ_SHIFT    , 0x72             }, /* 0x1c:y */ \
    {0x62             , 0x62|MZ_SHIFT    , 0                , 0                , 0x62             , 0x62|MZ_SHIFT    , 0x62             }, /* 0x1d:z */ \
    {0x76             , 0x76|MZ_SHIFT    , 0                , 0                , 0x76             , 0x76|MZ_SHIFT    , 0x76             }, /* 0x1e:1/! */ \
    {0x66             , 0x66|MZ_SHIFT    , 0                , 0                , 0x66             , 0x66|MZ_SHIFT    , 0x66             }, /* 0x1f:2/" */ \
\
    {0x56             , 0x56|MZ_SHIFT    , 0                , 0                , 0x56             , 0x56|MZ_SHIFT    , 0x56             }, /* 0x20:3/# */ \
    {0x46             , 0x46|MZ_SHIFT    , 0                , 0                , 0x46             , 0x46|MZ_SHIFT    , 0x46             }, /* 0x21:4/$ */ \
    {0x36             , 0x36|MZ_SHIFT    , 0                , 0                , 0x36             , 0x36|MZ_SHIFT    , 0x36             }, /* 0x22:5/% */ \
    {0x26             , 0x26|MZ_SHIFT    , 0                , 0                , 0x26             , 0x26|MZ_SHIFT    , 0x26             }, /* 0x23:6/& */ \
    {0x16             , 0x16|MZ_SHIFT    , 0                , 0                , 0x16             , 0x16|MZ_SHIFT    , 0x16             }, /* 0x24:7/' */ \
    {0x06             , 0x06|MZ_SHIFT    , 0                , 0                , 0x06             , 0x06|MZ_SHIFT    , 0x06             }, /* 0x25:8/( */ \
    {0x27             , 0x27|MZ_SHIFT    , 0                , 0                , 0x27             , 0x27|MZ_SHIFT    , 0x27             }, /* 0x26:9/) */ \
    {0x37             , 0x37|MZ_SHIFT    , 0                , 0                , 0x37             , 0x37|MZ_SHIFT    , 0x37             }, /* 0x27:0/[Paragraph]/わ */ \
    {0x01             , 0x01|MZ_SHIFT    , 0                , 0                , 0x01             , 0x01|MZ_SHIFT    , 0x01             }, /* 0x28:[RETURN] */ \
    {0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0                , 0                , 0x47|MZ_SHIFT    , 0x47|MZ_SHIFT    , 0                }, /* 0x29:[ESC] = SHIFT+SPACE In Hu-BASIC */ \
    {0x68             , 0x68             , 0                , 0                , 0x68             , 0x68             , 0x68             }, /* 0x2a:[BS] = [DEL] key */ \
    {0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0                , 0                , 0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0                }, /* 0x2b:Home = [SHIFT]+[DEL] / [SHIFT]+[INST] */ \
    {0x47             , 0x47|MZ_SHIFT    , 0                , 0                , 0x47             , 0x47|MZ_SHIFT    , 0x47             }, /* 0x2c:[SPACE] */ \
    {0x57             , 0x57|MZ_SHIFT    , 0                , 0                , 0x57             , 0x57|MZ_SHIFT    , 0x57             }, /* 0x2d:'-'/'=' */ \
    {0x67             , 0x67|MZ_SHIFT    , 0                , 0                , 0x67             , 0x67|MZ_SHIFT    , 0x67             }, /* 0x2e:'^'/'~' */ \
    {0x52             , 0x52|MZ_SHIFT    , 0                , 0                , 0x52             , 0x52|MZ_SHIFT    , 0x52             }, /* 0x2f:'@'/'`'/゛ */ \
\
    {0x42             , 0x42|MZ_SHIFT    , 0                , 0                , 0x42             , 0x42|MZ_SHIFT    , 0x42             }, /* 0x30:'['/'{' */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x31: */ \
    {0x32             , 0x32|MZ_SHIFT    , 0                , 0                , 0x32             , 0x32|MZ_SHIFT    , 0x32             }, /* 0x32:']'/'}'  */ \
    {0x21             , 0x21|MZ_SHIFT    , 0                , 0                , 0x21             , 0x21|MZ_SHIFT    , 0x21             }, /* 0x33:';'/'+' */ \
    {0x11             , 0x11|MZ_SHIFT    , 0                , 0                , 0x11             , 0x11|MZ_SHIFT    , 0x11             }, /* 0x34:':'/'*' */ \
    {0x79             , 0x79|MZ_SHIFT    , 0                , 0                , 0x79             , 0x79|MZ_SHIFT    , 0x79             }, /* 0x35 ZEN/HAN = [BREAK] key */ \
    {0x17             , 0x17|MZ_SHIFT    , 0                , 0                , 0x17             , 0x17|MZ_SHIFT    , 0x17             }, /* 0x36:','/'<' */ \
    {0x07             , 0x07|MZ_SHIFT    , 0                , 0                , 0x07             , 0x07|MZ_SHIFT    , 0x07             }, /* 0x37:'.'/'>' */ \
    {0x08             , 0x18             , 0                , 0                , 0x08             , 0x08|MZ_SHIFT    , 0x08             }, /* 0x38:'/'/'?' */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x41             }, /* 0x39: [CAPS] = assaign as [ALPHA] */ \
    {0x7a             , 0x7a|MZ_SHIFT    , 0                , 0                , 0x7a             , 0x7a|MZ_SHIFT    , 0x7a             }, /* 0x3a:[F1] */ \
    {0x6a             , 0x6a|MZ_SHIFT    , 0                , 0                , 0x6a             , 0x6a|MZ_SHIFT    , 0x6a             }, /* 0x3b:[F2] */ \
    {0x5a             , 0x5a|MZ_SHIFT    , 0                , 0                , 0x5a             , 0x5a|MZ_SHIFT    , 0x5a             }, /* 0x3c:[F3] */ \
    {0x4a             , 0x4a|MZ_SHIFT    , 0                , 0                , 0x4a             , 0x4a|MZ_SHIFT    , 0x4a             }, /* 0x3d:[F4] */ \
    {0x3a             , 0x3a|MZ_SHIFT    , 0                , 0                , 0x3a             , 0x3a|MZ_SHIFT    , 0x3a             }, /* 0x3e:[F5] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x3f:[F6] */ \
\
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x40:[F7] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x41:[F8] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x42:[F9] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x43:[F10] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x44 [F11] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x45:[F12] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x46 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x47 */ \
    {0x79             , 0x79|MZ_SHIFT    , 0                , 0                , 0x79             , 0x79|MZ_SHIFT    , 0x79             }, /* 0x48 Pause/Break = [BREAK] */ \
    {0x78             , 0x78             , 0                , 0                , 0x78             , 0x78             , 0x78             }, /* 0x49 Insert = [INST] */ \
    {0x68|MZ_SHIFT    , 0x78|MZ_SHIFT    , 0                , 0                , 0x68             , 0x78             , 0                }, /* 0x4a Home = [SHIFT]+[DEL] / [SHIFT]+[INST] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0x61             }, /* 0x4b PgUp = [GRPH] */ \
    {0x68             , 0x68             , 0                , 0                , 0x68             , 0x68             , 0x68             }, /* 0x4c Delete = [DEL] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4d End */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x4e PgDn = [] */ \
    {0x38             , 0x38|MZ_SHIFT    , 0                , 0                , 0x38             , 0x38|MZ_SHIFT    , 0x38             }, /* 0x4f right arrow */ \
\
    {0x28             , 0x28|MZ_SHIFT    , 0                , 0                , 0x28             , 0x28|MZ_SHIFT    , 0x28             }, /* 0x50 left arrow */ \
    {0x48             , 0x48|MZ_SHIFT    , 0                , 0                , 0x48             , 0x48|MZ_SHIFT    , 0x48             }, /* 0x51 down arrow */ \
    {0x58             , 0x58|MZ_SHIFT    , 0                , 0                , 0x58             , 0x58|MZ_SHIFT    , 0x58             }, /* 0x52 up arrow */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x53 NumLock */ \
    {0x08             , 0x08|MZ_SHIFT    , 0                , 0                , 0x08             , 0x08|MZ_SHIFT    , 0x08             }, /* 0x54:/ */ \
    {0x11|MZ_SHIFT    , 0x11             , 0                , 0                , 0x11|MZ_SHIFT    , 0x11             , 0x11             }, /* 0x55:* */ \
    {0x57             , 0x57|MZ_SHIFT    , 0                , 0                , 0x57             , 0x57|MZ_SHIFT    , 0x57             }, /* 0x56:- */ \
    {0x21|MZ_SHIFT    , 0x21             , 0                , 0                , 0x21|MZ_SHIFT    , 0x21             , 0x21             }, /* 0x57:+ */ \
    {0x01             , 0x01|MZ_SHIFT    , 0                , 0                , 0x01             , 0x01|MZ_SHIFT    , 0x01             }, /* 0x58:[RETURN] */ \
    {0x76             , 0x76|MZ_SHIFT    , 0                , 0                , 0x76             , 0x76|MZ_SHIFT    , 0x76             }, /* 0x59:1 */ \
    {0x66             , 0x66|MZ_SHIFT    , 0                , 0                , 0x66             , 0x66|MZ_SHIFT    , 0x66             }, /* 0x5a:2 */ \
    {0x56             , 0x56|MZ_SHIFT    , 0                , 0                , 0x56             , 0x56|MZ_SHIFT    , 0x56             }, /* 0x5b:3 */ \
    {0x46             , 0x46|MZ_SHIFT    , 0                , 0                , 0x46             , 0x46|MZ_SHIFT    , 0x46             }, /* 0x5c:4 */ \
    {0x36             , 0x36|MZ_SHIFT    , 0                , 0                , 0x36             , 0x36|MZ_SHIFT    , 0x36             }, /* 0x5d:5 */ \
    {0x26             , 0x26|MZ_SHIFT    , 0                , 0                , 0x26             , 0x26|MZ_SHIFT    , 0x26             }, /* 0x5e:6 */ \
    {0x16             , 0x16|MZ_SHIFT    , 0                , 0                , 0x16             , 0x16|MZ_SHIFT    , 0x16             }, /* 0x5f:7 */ \
\
    {0x06             , 0x06|MZ_SHIFT    , 0                , 0                , 0x06             , 0x06|MZ_SHIFT    , 0x06             }, /* 0x60:8 */ \
    {0x27             , 0x27|MZ_SHIFT    , 0                , 0                , 0x27             , 0x27|MZ_SHIFT    , 0x27             }, /* 0x61:9 */ \
    {0x37             , 0x37|MZ_SHIFT    , 0                , 0                , 0x37             , 0x37|MZ_SHIFT    , 0x37             }, /* 0x62:0 */ \
    {0x07             , 0x07|MZ_SHIFT    , 0                , 0                , 0x07             , 0x07|MZ_SHIFT    , 0x07             }, /* 0x63:. */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x64 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x65:[Application] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x66 */ \
    {0x51             , 0x51|MZ_SHIFT    , 0                , 0                , 0x51             , 0x51|MZ_SHIFT    , 0x51             }, /* 0x67:= */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x68 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x69 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x6f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x70 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x71 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x72 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x73 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x74 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x75 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x76 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x77 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x78 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x79 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7a */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7b */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7c */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7d */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7e */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x7f */ \
 \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x80 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x81 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x82 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x83 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x84 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x85 */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x86 */ \
    {0x18             , 0x18|MZ_SHIFT    , 0                , 0                , 0x18             , 0x18|MZ_SHIFT    , 0x18             }, /* 0x87:[Backslash]/_ key = [?][→] */ \
    {0                , 0                , 0                , 0                , 0                , 0                , 0                }, /* 0x88:[Hiragana/Katakana] = [カナ] */ \
    {0x77             , 0x77|MZ_SHIFT    , 0                , 0                , 0x77             , 0x77|MZ_SHIFT    , 0x77             }, /* 0x89:[Yen]/[|] */ \
};

// SYSTEM MODE vs. KB MATRIX table
static keycode2SYX_t *keycode2SYX[16]  = {
  &keycode2MZ1200SYX,	// 0
  &keycode2MZ1200SYX,	// 1
  &keycode2MZ1200SYX,	// 2
  &keycode2MZ1200SYX,	// 3
  &keycode2MZ700JSYX,	// 4
  &keycode2MZ700JSYX,	// 5
  &keycode2MZ700JSYX,	// 6
  &keycode2MZ700JSYX,	// 7
  &keycode2MZ80ASYX,	// 8
  &keycode2MZ1200SYX,	// 9
  &keycode2MZ80ASYX,	// 10
  &keycode2MZ1200SYX,	// 11
  &keycode2MZ700ESYX,	// 12
  &keycode2MZ700JSYX,	// 13
  &keycode2MZ700ESYX,	// 14
  &keycode2MZ700JSYX,	// 15
};
#define KEYCODE2SYX	(*keycode2SYX[system_mode])

// MZ-80A で [GRPH] モードとするのに [ALPHA]+[GRPH] が必要かどうか
static bool need_alpha_grph[16]  = {
  false,	// 0: MZ1200
  false,	// 1: MZ1200
  false,	// 2: MZ1200
  false,	// 3: MZ1200
  false,	// 4: MZ700J
  false,	// 5: MZ700J
  false,	// 6: MZ700J
  false,	// 7: MZ700J
  true,		// 8: MZ80A : 要
  false,	// 9: MZ1200
  true,		// 10: MZ80A : 要
  false,	// 11: MZ1200
  false,	// 12: MZ700E
  false,	// 13: MZ700J
  false,	// 14: MZ700E
  false,	// 15: MZ700J
};
#define NEED_ALPHA_GRPH	(need_alpha_grph[system_mode])



// [Fn] default string
#define MZ_START_FKEY	F6_KEY_CODE
#define MZ_END_FKEY	F12_KEY_CODE
#define MZ_NUM_FKEYS	(MZ_END_FKEY - MZ_START_FKEY + 1)
#define MZ_FKEY_MAXLEN	((FLASH_PAGE_SIZE - 8) / 2)

// ASCII to HID keycode + modifier code table (fill later)
static uint8_t ascii2keycode[256]= {0};
static uint8_t ascii2modifier[256]= {0};

// alpha, kana,grph,raw mode
typedef enum {
  MZ_KBMODE_ALPHA = 0,
  MZ_KBMODE_KANA = 2,
  MZ_KBMODE_GRPH = 4,
  MZ_KBMODE_RAW  = 6,
} mz_kb_mode_t;
static mz_kb_mode_t	mz_kb_mode = MZ_KBMODE_ALPHA;

// モード文字列を返す
static const char *mz_input_modestring(mz_kb_mode_t mode)
{
  if (mode == MZ_KBMODE_ALPHA) return "ALPHA";
  if (mode == MZ_KBMODE_KANA) return "KANA";
  if (mode == MZ_KBMODE_GRPH) return "GRPH";
  if (mode == MZ_KBMODE_RAW) return "RAW";
  return "UNKNOWN";
}


// MZ's last SHIFT Key state
static bool mz_last_shift_state = false;
static bool mz_last_lshift_state = false;
static bool mz_last_rshift_state = false;
static bool mz_last_ctrl_state = false;

// Function key definition mode
static bool    fkey_def_mode = false;
static uint16_t fkey_def_keynum  = 0;

// Function key buffer
typedef struct {
  size_t 	length;			// 4: Number of keycodes in this entry
  mz_kb_mode_t	initial_mz_kb_mode;	// 4: initial mz_kb_mode value of the fkey assume
  uint8_t modifier[MZ_FKEY_MAXLEN];	//  : HID modifier
  uint8_t keycode[MZ_FKEY_MAXLEN];	//  : HID keycode
} mz_func_key_store_t;			// フラッシュに保存するので256バイトに収まるように
static mz_func_key_store_t mz_func_key_store[MZ_NUM_FKEYS] = {0};
// ↑のサイズチェック↓。サイズがページサイズになっていないと配列のサイズがマイナスになってコンパイルエラーになる
typedef char compile_time_assert[(sizeof(mz_func_key_store_t) == FLASH_PAGE_SIZE) ? 1 : -1] __attribute__((unused));

// the string length must be less than MZ_FKEY_MAXLEN
static char const *mz_func_key_string_default[MZ_NUM_FKEYS] = {
  "fdl ",							// 6: 
  "*fdl ",							// 7: in DOS FILE: prompt
  "load\"*l",							// 8: in BASIC
  "",								// 9: 
  "poke $3d25,1\r",						// 10: SP-5030 auto repeat OFF
  "poke $3d25,0\r",						// 11: SP-5030 auto repeat ON
  "test:hhahhbhhchhdhhehhfhhghhhhhihhj\r",			// 12: 
};




// Wait time for debounce
#define MZ_KBIF_POWERON_WAIT_MS			500		// 
#define MZ_KBIF_RESET_MS			500
#define MZ_KBIF_STROBE_MS			1
#define MZ_KBIF_DEBOUNCE_MS			60		// MZ-1200 : 40mS ?
#define MZ_KBIF_RELEASE_DEBOUNCE_MS		150		// MZ-1200 : 130mS ?
#define MZ_KBIF_WAIT_BETWEEN_THE_SAME_KEY_MS	5
#define MZ_KBIF_CTRL_ALT_DEL_MS			500		// Duration from press MZ RESET SW to release the SW
#define MZ_KBIF_CTRL_ALT_END_MS			100		// Duration from release ALL keys to press CTRL
#define MZ_KBIF_CTRL_ALT_END_MS2		100		// Duration from press MZ RESET SW to release RESET
#define MZ_KBIF_CTRL_ALT_END_MS3		500		// Duration from release MZ RESET SW to release CTRL
#define MZ_KBIF_VBUS_CYCLE_MS			1000		// Duration of VBUS CYCLE

// Pin assignments
#define MZ_PIO_MOTOR_PIN			0
#define MZ_PIO_Z80_CLOCK_SW			1
#define MZ_PIO_ROM_A15_PIN			2
#define MZ_PIO_ROM_A14_PIN			3
#define MZ_PIO_ROM_A13_PIN			4
#define MZ_PIO_ROM_A12_PIN			5
#define MZ_PIO_ARRAY_RESET_PIN			6
#define MZ_PIO_ARRAY_DATA_PIN			7
#define MZ_PIO_ARRAY_STROBE_PIN			8
#define MZ_PIO_AX0_PIN				9
#define MZ_PIO_AX1_PIN				10
#define MZ_PIO_AX2_PIN				11
#define MZ_PIO_AX3_PIN				12
#define MZ_PIO_AY0_PIN				13
#define MZ_PIO_AY1_PIN				14
#define MZ_PIO_AY2_PIN				15
#define MZ_KEYSCAN_DETECTION_PIN		16		// key-scan detection with IRQ
#define MZ_PIO_MZ_RESET_PIN			19

// Key scan detection
#define L_KEYSCANS_RELEASE_DEBOUNCE_DEF			2		// Smallest stable value @ SP-1002 2MHz
#define M_KEYSCANS_RELEASE_DEBOUNCE_DEF			34		// Smallest stable value @ SP-1002 2MHz
#define	H_KEYSCANS_RELEASE_DEBOUNCE_DEF			76		// Smallest stable value @ SP-5030 Auto repeat
#define N_KEYSCANS_PRESS_DEBOUNCE_DEF			2		// Smallest stable value @ MZ-700
#define MZ700E_N_KEYSCANS_RELEASE_DEBOUNCE_DEF		2		// Smallest stable value @ MZ-700

const uint32_t n_keyscans_release_debounce_default[16] = {
  H_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 0  MZ1200 SP-1002
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 1  MZ1200
  H_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 2  MZ1200 SP-1002
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 3  MZ1200
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 4  MZ700J
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 5  MZ700J
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 6  MZ700J
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 7  MZ700J
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 8  MZ80A
  H_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 9  MZ1200 SP-1002
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 10 MZ80A
  H_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 11 MZ1200 SP-1002
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 12 MZ700E
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 13 MZ700J
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 14 MZ700E
  M_KEYSCANS_RELEASE_DEBOUNCE_DEF,	// 15 MZ700J
};

static uint32_t n_keyscans_press_debounce   = N_KEYSCANS_PRESS_DEBOUNCE_DEF;
static uint32_t n_keyscans_release_debounce = H_KEYSCANS_RELEASE_DEBOUNCE_DEF;

// init debounce count
void init_debounce_count(void)
{
  n_keyscans_press_debounce = N_KEYSCANS_PRESS_DEBOUNCE_DEF;
  n_keyscans_release_debounce = n_keyscans_release_debounce_default[system_mode];
}


// keyscan detection callback
uint32_t num_keyscan_called = 0;

void keyscan_detection_callback(uint gpio, uint32_t event_mask)
{
  if (gpio == MZ_KEYSCAN_DETECTION_PIN && event_mask == GPIO_IRQ_EDGE_FALL) {
    num_keyscan_called++;
  }
}

// fill ascii2*[] table
static void mz_fill_ascii2hid(void)
{
  for (uint16_t c = 1; c < 256; c++)
  {
    for (uint16_t k = 4; k < 256; k++)
    {
      for (uint16_t s = 0; s < 2; s++)
      {
        if (keycode2ascii[k][s] == (uint8_t)c)
        {
          ascii2keycode[c]  = (uint8_t)k;
          ascii2modifier[c] = s ? KEYBOARD_MODIFIER_LEFTSHIFT : 0;
          k = 256;	// found
          break;
        }
      }
    }
  }
  // CTRL
  for (uint16_t c = 1; c < 32; c++)
  {
    for (uint16_t k = 4; k < 256; k++)
    {
      uint8_t cc = (uint8_t)(c + 0x40u);
      if (cc >= 0x41 && cc <= 0x5a) cc += 0x20u;
      if (keycode2ascii[k][0] == cc)
      {
        if (ascii2keycode[c] == 0)
        {
          ascii2keycode[c]  = (uint8_t)k;
          ascii2modifier[c] = KEYBOARD_MODIFIER_LEFTCTRL;
        }
        k = 256;	// found
        break;
      }
    }
  }
  // CTRL-C
  ascii2keycode[3]  = C_KEY_CODE;
  ascii2modifier[3] = KEYBOARD_MODIFIER_LEFTCTRL;
}

// Store function key buffer default
// must be after mz_fill_ascii2hid()
static void mz_func_key_init(void)
{
  for (int i = 0; i < MZ_NUM_FKEYS; i++)
  {
    const char *s = mz_func_key_string_default[i];
    size_t l = strlen(s);
    mz_func_key_store[i].length = l;
    mz_func_key_store[i].initial_mz_kb_mode  = MZ_KBMODE_ALPHA;

    for (size_t n = 0; n < l; n++)
    {
      mz_func_key_store[i].keycode[n]  = ascii2keycode[(uint8_t)s[n]];
      mz_func_key_store[i].modifier[n] = ascii2modifier[(uint8_t)s[n]];
    }
  }

  fkey_def_mode = false;
}


// MZ key sending task
static enum  {
  MZ_TASK_STATE_POWERON = 0,
  MZ_TASK_STATE_POWERON_WAIT,
  MZ_TASK_STATE_RESET,
  MZ_TASK_STATE_RESET_ASSERTED,
  MZ_TASK_STATE_ARRAY_RESET_ASSERTED,
  MZ_TASK_STATE_GETKEY,
  MZ_TASK_STATE_KEY_STROBE_ASSERTED,
  MZ_TASK_STATE_KEY_STROBE_DEASSERTED,
  MZ_TASK_STATE_KEY_WAIT_DEBOUNCE,
  MZ_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE,
  MZ_TASK_STATE_CTRL_ALT_DEL,
  MZ_TASK_STATE_CTRL_ALT_DEL_ASSERTED,
  MZ_TASK_STATE_CTRL_ALT_END,
  MZ_TASK_STATE_CTRL_ALT_END_ASSERTED,
  MZ_TASK_STATE_CTRL_ALT_END_ASSERTED2,
  MZ_TASK_STATE_CTRL_ALT_END_ASSERTED3,
  MZ_TASK_STATE_CTRL_ALT_END_ASSERTED4,
  MZ_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY,
  MZ_TASK_STATE_CYCLE_VBUS,
  MZ_TASK_STATE_CYCLE_VBUS_WAITING,
} mz_key_sending_task_state = MZ_TASK_STATE_POWERON;
static uint32_t mz_task_start_ms = 0;
void mz_sendkey_task(void);

// Key queue for MZ
#define MZ_KEY_QUEUE_LEN	((uint16_t)256)
static uint16_t mz_key_queue[MZ_KEY_QUEUE_LEN] =  { 0 };
static uint16_t mz_key_queue_read = 0;
static uint16_t mz_key_queue_write = 0;

// return number of data in queue
uint16_t mz_key_queue_num_data(void)
{
  return (uint16_t)((mz_key_queue_write + MZ_KEY_QUEUE_LEN - mz_key_queue_read) % MZ_KEY_QUEUE_LEN);
}

// put key into queue
void mz_key_queue_put(uint16_t syx)
{
  if ((uint16_t)((mz_key_queue_write + 1) % MZ_KEY_QUEUE_LEN) != mz_key_queue_write)
  {
    mz_key_queue[mz_key_queue_write] = syx;
    mz_key_queue_write = (uint16_t)((mz_key_queue_write + 1) % MZ_KEY_QUEUE_LEN);
  }
  else
  {
    // TODO when queue is full
    mz_key_sending_task_state = MZ_TASK_STATE_RESET;
  }
}

// peek queue
uint16_t mz_key_queue_peek(void)
{
  if (mz_key_queue_read == mz_key_queue_write) return 0;	// No key in queue
  return mz_key_queue[mz_key_queue_read];			// Peek queue
}

// drop queue
void mz_key_queue_drop(void)
{
  if (mz_key_queue_read == mz_key_queue_write) return;	// No key in queue
  // advance queue read pointer
  mz_key_queue_read = (uint16_t)((mz_key_queue_read + 1) % MZ_KEY_QUEUE_LEN);
}

// Host PC to MZ
// Key queue for host
#define MZ_HOST_QUEUE_LEN	((uint16_t)128)
static char     mz_host_queue[MZ_HOST_QUEUE_LEN] =  { 0 };
static uint16_t mz_host_queue_read = 0;
static uint16_t mz_host_queue_write = 0;

void mz_host2mz_task(void);

// return number of data in queue
uint16_t mz_host_queue_num_data(void)
{
  return (uint16_t)((mz_host_queue_write + MZ_HOST_QUEUE_LEN - mz_host_queue_read) % MZ_HOST_QUEUE_LEN);
}

// put key into queue
void mz_host_queue_put(char c)
{
  if ((uint16_t)((mz_host_queue_write + 1) % MZ_HOST_QUEUE_LEN) != mz_host_queue_write)
  {
    mz_host_queue[mz_host_queue_write] = c;
    mz_host_queue_write = (uint16_t)((mz_host_queue_write + 1) % MZ_HOST_QUEUE_LEN);
  }
  else
  {
    // TODO when queue is full
    mz_key_sending_task_state = MZ_TASK_STATE_RESET;
  }
}

// peek queue
char mz_host_queue_peek(void)
{
  if (mz_host_queue_read == mz_host_queue_write) return 0;	// No key in queue
  return mz_host_queue[mz_host_queue_read];			// Peek queue
}

// drop queue
void mz_host_queue_drop(void)
{
  if (mz_host_queue_read == mz_host_queue_write) return;	// No key in queue
  // advance queue read pointer
  mz_host_queue_read = (uint16_t)((mz_host_queue_read + 1) % MZ_HOST_QUEUE_LEN);
}

// init queue
void mz_host_queue_init(void)
{
  mz_key_queue_read = 0;
  mz_key_queue_write = 0;
  mz_host_queue_read = 0;
  mz_host_queue_write = 0;
}

// init mode
void mz_mode_init(void)
{
  mz_kb_mode = MZ_KBMODE_ALPHA;
  mz_last_shift_state = false;
  mz_last_lshift_state = false;
  mz_last_rshift_state = false;
  mz_last_ctrl_state = false;
}


// init LED
void kb_led_init(void)
{
  leds = 0;
  prev_leds = 0;
  blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;
  if (keybd_dev_addr != 0xFFu)
  {
    tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &leds, sizeof(leds));
  }
}

// set ROM A15-A12
void mz_set_ROM_addr(void)
{
  gpio_put(MZ_PIO_ROM_A15_PIN, (system_mode & 0x8) ? 1 : 0);
  gpio_put(MZ_PIO_ROM_A14_PIN, (system_mode & 0x4) ? 1 : 0);
  gpio_put(MZ_PIO_ROM_A13_PIN, (system_mode & 0x2) ? 1 : 0);
  gpio_put(MZ_PIO_ROM_A12_PIN, (system_mode & 0x1) ? 1 : 0);
}

// システムクロック切り替え
// -------------------------------------------------------------------
typedef enum {
  Z80_CLOCK_MODE_AUTO = 0,
  Z80_CLOCK_MODE_2MHZ,
  Z80_CLOCK_MODE_4MHZ,
} z80_clock_mode_t;
static z80_clock_mode_t z80_clock_mode = Z80_CLOCK_MODE_DEFAULT;

typedef enum {
  Z80_CLOCK_2MHZ = 1,
  Z80_CLOCK_4MHZ = 0,
  Z80_CLOCK_UNKNOWN = 2,
} z80_clock_t;

static volatile z80_clock_t z80_clock = Z80_CLOCK_UNKNOWN;

void set_z80_system_clock(z80_clock_t clk)
{
   if (z80_clock != clk)
   {
     z80_clock = clk;
     gpio_put(MZ_PIO_Z80_CLOCK_SW, clk);
#ifdef MZ_CLK_DEBUG
     char tempbuf[256];
     int count = sprintf(tempbuf, "MZ: Z80 CLOCK set to %s\r\n", (clk == Z80_CLOCK_2MHZ) ? "2MHz" : "4MHz");
     tud_cdc_write(tempbuf, (uint32_t) count);
     tud_cdc_write_flush();
#endif
   }
}

void z80_system_clock_task(void)
{
  z80_clock_t	clk;

  switch(z80_clock_mode)
  {
    case Z80_CLOCK_MODE_2MHZ:
      clk = Z80_CLOCK_2MHZ;
      break;

    case Z80_CLOCK_MODE_4MHZ:
      clk = Z80_CLOCK_4MHZ;
      break;

    case Z80_CLOCK_MODE_AUTO:
    default:
      clk = (gpio_get(MZ_PIO_MOTOR_PIN) ? Z80_CLOCK_4MHZ : Z80_CLOCK_2MHZ);
      break;
  }
  set_z80_system_clock(clk);
}


// GPIO Initialize
// -------------------------------------------------------------------
static void mz_switch_init(void)
{
  gpio_init(MZ_PIO_MOTOR_PIN);
  gpio_init(MZ_PIO_Z80_CLOCK_SW);
  gpio_init(MZ_PIO_ROM_A15_PIN);
  gpio_init(MZ_PIO_ROM_A14_PIN);
  gpio_init(MZ_PIO_ROM_A13_PIN);
  gpio_init(MZ_PIO_ROM_A12_PIN);
  gpio_init(MZ_PIO_ARRAY_RESET_PIN);
  gpio_init(MZ_PIO_ARRAY_DATA_PIN);
  gpio_init(MZ_PIO_ARRAY_STROBE_PIN);
  gpio_init(MZ_PIO_AX0_PIN);
  gpio_init(MZ_PIO_AX1_PIN);
  gpio_init(MZ_PIO_AX2_PIN);
  gpio_init(MZ_PIO_AX3_PIN);
  gpio_init(MZ_PIO_AY0_PIN);
  gpio_init(MZ_PIO_AY1_PIN);
  gpio_init(MZ_PIO_AY2_PIN);
  gpio_init(MZ_PIO_MZ_RESET_PIN);
  gpio_init(MZ_KEYSCAN_DETECTION_PIN);

  gpio_set_dir(MZ_PIO_MOTOR_PIN, GPIO_IN);
  gpio_pull_up(MZ_PIO_MOTOR_PIN);
  gpio_set_dir(MZ_PIO_Z80_CLOCK_SW, GPIO_OUT);

  gpio_set_dir(MZ_PIO_ROM_A15_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_ROM_A14_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_ROM_A13_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_ROM_A12_PIN, GPIO_OUT);

  gpio_set_dir(MZ_PIO_ARRAY_RESET_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_ARRAY_DATA_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_ARRAY_STROBE_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AX0_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AX1_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AX2_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AX3_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AY0_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AY1_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_AY2_PIN, GPIO_OUT);
  gpio_set_dir(MZ_PIO_MZ_RESET_PIN, GPIO_OUT);
  gpio_set_dir(MZ_KEYSCAN_DETECTION_PIN, GPIO_IN);
  gpio_pull_up(MZ_KEYSCAN_DETECTION_PIN);

  gpio_put(MZ_PIO_ROM_A15_PIN, 0);
  gpio_put(MZ_PIO_ROM_A14_PIN, 0);
  gpio_put(MZ_PIO_ROM_A13_PIN, 0);
  gpio_put(MZ_PIO_ROM_A12_PIN, 0);
  gpio_put(MZ_PIO_ARRAY_RESET_PIN, 0);
  gpio_put(MZ_PIO_ARRAY_DATA_PIN, 0);
  gpio_put(MZ_PIO_ARRAY_STROBE_PIN, 0);
  gpio_put(MZ_PIO_AX0_PIN, 0);
  gpio_put(MZ_PIO_AX1_PIN, 0);
  gpio_put(MZ_PIO_AX2_PIN, 0);
  gpio_put(MZ_PIO_AX3_PIN, 0);
  gpio_put(MZ_PIO_AY0_PIN, 0);
  gpio_put(MZ_PIO_AY1_PIN, 0);
  gpio_put(MZ_PIO_AY2_PIN, 0);
  gpio_put(MZ_PIO_MZ_RESET_PIN, 0);

  // init queue
  mz_host_queue_init();
  
  // init mode
  mz_mode_init();

  // set clock to safer value
  set_z80_system_clock(Z80_CLOCK_2MHZ);

  // set ROM A15-A12
  system_mode = 0; // always SP-1002 while power-on init
  mz_set_ROM_addr();

  // init LED
  kb_led_init();
}


// last pressed key
static uint16_t last_on_syx = 0;

void mz_switch_all_relase(void)
{
  // Release all keys
  // Assert Reset of switch array IC
  gpio_put(MZ_PIO_ARRAY_RESET_PIN, 1);

  // init queue
  mz_host_queue_init();

  // init mode
  mz_last_shift_state = false;
  mz_last_lshift_state = false;
  mz_last_rshift_state = false;
  mz_last_ctrl_state = false;
  fkey_def_mode = false;

  // clear last pressed key
  last_on_syx = 0;
}

// Switch ON/OFF
void mz_switch_set(uint8_t x, uint8_t y, bool onoff)
{
  if (x > 5) x += 2;	// No switch on X=6 and X=7

  gpio_put(MZ_PIO_AX0_PIN, x & 1);
  gpio_put(MZ_PIO_AX1_PIN, (x & 2) ? 1 : 0);
  gpio_put(MZ_PIO_AX2_PIN, (x & 4) ? 1 : 0);
  gpio_put(MZ_PIO_AX3_PIN, (x & 8) ? 1 : 0);
  gpio_put(MZ_PIO_AY0_PIN, y & 1);
  gpio_put(MZ_PIO_AY1_PIN, (y & 2) ? 1 : 0);
  gpio_put(MZ_PIO_AY2_PIN, (y & 4) ? 1 : 0);
  gpio_put(MZ_PIO_ARRAY_DATA_PIN, (onoff) ? 1 : 0);
  gpio_put(MZ_PIO_ARRAY_STROBE_PIN, 1);
}

void mz_switch_deassert_strobe(void)
{
  gpio_put(MZ_PIO_ARRAY_STROBE_PIN, 0);
}

// debounce
void mz_switch_start_waiting_debounce(void)
{
  // Change task state
  mz_key_sending_task_state =  gpio_get(MZ_PIO_ARRAY_DATA_PIN) ? MZ_TASK_STATE_KEY_WAIT_DEBOUNCE : MZ_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE;
  mz_task_start_ms = board_millis();
  num_keyscan_called = 0;
}

// get next key
void mz_switch_get_next_key(void)
{
  // Change task state
  mz_key_sending_task_state = MZ_TASK_STATE_GETKEY;
  mz_task_start_ms = board_millis();
}

// wait between the same key pressed again
void mz_switch_start_waiting_between_the_same_key(void)
{
  // Change task state
  mz_key_sending_task_state =  MZ_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY;
  mz_task_start_ms = board_millis();
}

static void mz_switch_ctrl_alt_del(void)
{
  // set ROM A15-A12
  mz_set_ROM_addr();

  // Assert RESET on MZ
  gpio_put(MZ_PIO_MZ_RESET_PIN, 1);
}

static void mz_switch_ctrl_alt_end(void)
{
  // Assert RESET on switch array IC
  gpio_put(MZ_PIO_ARRAY_RESET_PIN, 1);

  // init queue
  mz_host_queue_init();

  // init mode
  mz_mode_init();

  // init LED
  kb_led_init();

  // Change task state
  mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_END_ASSERTED;
  mz_task_start_ms = board_millis();
}

// Deassert RESET on SW array
static void mz_switch_deassert_array_reset(void)
{
  // Dessert RESET on switch array IC
  gpio_put(MZ_PIO_ARRAY_RESET_PIN, 0);
}

// Deassert RESET on MZ
static void mz_switch_deassert_ctrl_alt_del(void)
{
  // Dessert RESET on MZ
  gpio_put(MZ_PIO_MZ_RESET_PIN, 0);
}

// Send ASCII string as key strokes
// must be after mz_fill_ascii2hid()
static void mz_queue_string_as_key(const char *s)
{
  size_t l = strlen(s);

  // RAWモードの時はやらない
  if (mz_kb_mode == MZ_KBMODE_RAW) return;

  // ALPHAモード以外(KANA,GRPH)ならALPHAモードにする
  if (mz_kb_mode != MZ_KBMODE_ALPHA)
  {
    // [英数] キーをキュー
    mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
    mz_key_queue_put(MZ_KEYCODE_ALPHA);
  }
  mz_kb_mode = MZ_KBMODE_ALPHA;

  // Emulate key press
  for (size_t n = 0; n < l; n++)
  {
    uint8_t fkeycode  = ascii2keycode[(uint8_t)s[n]];
    uint8_t fmodifier = ascii2modifier[(uint8_t)s[n]];
    bool       fis_shift = fmodifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
    bool       fis_ctrl  = fmodifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
    bool const fis_alt   = fmodifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);
    // bool const fis_del   = (fkeycode == DELETE_KEY_CODE);
    // bool const fis_end   = (fkeycode == END_KEY_CODE);
    bool const fis_c     = (fkeycode == C_KEY_CODE);
    bool const fis_caps  = (fkeycode == CAPS_KEY_CODE);
    bool const fis_kana  = (fkeycode == KANA_KEY_CODE) || (fkeycode == KANA_KEY_CODE2);
    bool const fis_grph  = (fkeycode == GRPH_KEY_CODE);
    uint16_t syx;

// モードシフト処理: KANA, GRPH, ALPHA (RAW以外)
// -------------------------------------------------------------------
    // KANA mode on
    if ((MZ_KEYCODE_KANA != 0) && (fis_kana || (fis_caps && fis_shift && !fis_alt)))
    {
      mz_kb_mode = MZ_KBMODE_KANA;

      if (MZ_KEYCODE_KANA == MZ_KEYCODE_ALPHA)
      {
        // [英数/カナ] キーの場合、シフト+英数キーをキュー
        mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_KANA);
        mz_key_queue_put(MZ_KEYCODE_LS);
      }
      else
      {
        // [英数]/[カナ] 独立の場合、カナキーをキュー
        mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_KANA);
      }
      // go to next key
      continue;
    }
    // GRPH  mode on
    else if ((MZ_KEYCODE_GRPH != 0) && fis_grph)
    {
      mz_kb_mode = MZ_KBMODE_GRPH;

      if (NEED_ALPHA_GRPH)
      {
        // SA-1510(パッチ済み)の場合、[ALPHA][GRPH]の2キーを押す
        mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_ALPHA);
        mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_GRPH);
      }
      else
      {
        // [GRPH]キーをキュー
        mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
        mz_key_queue_put(MZ_KEYCODE_GRPH);
      }
      // go to next key
      continue;
    }
    // ALPHA mode on
    else if (fis_caps && !fis_shift && !fis_alt)
    {
      mz_kb_mode = MZ_KBMODE_ALPHA;

      // [英数] キーをキュー
      mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
      mz_key_queue_put(MZ_KEYCODE_ALPHA);
      // go to next key
      continue;
    }
// -------------------------------------------------------------------

// キーエンコード:
// -------------------------------------------------------------------
    // GRPH が無い場合、ALTでGRPH代わりとする
    if (MZ_KEYCODE_GRPH == 0)
    {
      if (fis_alt)
      {
        syx = (uint16_t)KEYCODE2SYX[fkeycode][MZ_KBMODE_GRPH];
      }
      else
      {
        syx = (uint16_t)KEYCODE2SYX[fkeycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && fis_shift) ? 1 : 0)];
      }
    }
    else
    {
      syx = (uint16_t)KEYCODE2SYX[fkeycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && fis_shift) ? 1 : 0)];
    }

    // Check CTRL-C / SHIFT-CTRL-C
    // MZ-700J など、S-BASIC で CTRL-C (=ひらがな入力) など意味を持っている可能性があるため、CTRLキーを持つ機種でのこの処理は止める
    if (MZ_KEYCODE_CTRL == 0 && fis_ctrl && fis_c)
    {
      // Queue [SHIFT] + [BREAK] key pressed
      syx = MZ_KEYCODE_BREAK | MZ_SHIFT;
      fis_ctrl = 0;
    }
// -------------------------------------------------------------------

// キー押しエミュレーション (syx != 0)
// -------------------------------------------------------------------
    if (syx)
    {
      // コントロールキー
      if (MZ_KEYCODE_CTRL != 0 && (fis_ctrl != mz_last_ctrl_state))
      {
        mz_last_ctrl_state = fis_ctrl;
        mz_key_queue_put(MZ_KEYCODE_CTRL | (fis_ctrl ? MZ_KEYPRESS : 0));
      }
      bool sft = (syx & MZ_SHIFT);
      syx = MZ_BARE_YX(syx);			// bare code
      mz_last_shift_state = sft;
      mz_last_lshift_state = false;
      mz_last_rshift_state = false;
      // press-release emulation
      if (sft) mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);	// SHIFT
      mz_key_queue_put(syx | MZ_KEYPRESS);			// press
      mz_key_queue_put(syx);					// release
      if (sft) mz_key_queue_put(MZ_KEYCODE_LS);			// SHIFT
    }
// -------------------------------------------------------------------
  }	// go to next key
  // 最後にコントロールキーの辻褄を合わせる
  if (MZ_KEYCODE_CTRL != 0 && mz_last_ctrl_state)
  {
    mz_last_ctrl_state = 0;
    mz_key_queue_put(MZ_KEYCODE_CTRL);
  }
}

// =======================================================================
// flash access:

const uint32_t			FLASH_TARGET_OFFSET = 0x1f0000u;	// 256MBのflashの最後のブロックのオフセット(64KB)
static uint8_t			flash_data[FLASH_PAGE_SIZE];		// 256バイト
static const uint8_t		FLASH_SIGNATURE[] = "kaokun";
#define DATA_START_IN_PAGE	8					// シグネチャの後
#define DATA_ERASED_FLAG	(FLASH_PAGE_SIZE - 1)			// 消去済フラグのページ内オフセット。0x00 erased
#define DATA_PAGES		(FLASH_BLOCK_SIZE / FLASH_PAGE_SIZE)	// wear levellingのため: 64KB/256 = 256 pages
#define FLASH_MEM_PTR(p)	((void *)(XIP_BASE + FLASH_TARGET_OFFSET + ((p) * FLASH_PAGE_SIZE)))

#define SETTINGS_PAGES		(MZ_NUM_FKEYS + 1)			// 8
#define LAST_PAGE		(DATA_PAGES - SETTINGS_PAGES)		// 256-8 = 248 : このページまでは書ける。計32個のデータをラウンドロビンで使う事でウェアレベリングとする。

// 指定の頁にシグネチャがあるかチェック
static bool flash_check_signature(uint32_t page)
{
  // check signature
  return (memcmp(FLASH_MEM_PTR(page), FLASH_SIGNATURE, sizeof(FLASH_SIGNATURE)) == 0);
}

// 設定消去 (フラッシュのerase)
static void erase_settings(void)
{
  // get latest settings
  bool found = false;
  uint32_t page;
  for (page = 0; page <= LAST_PAGE; page += SETTINGS_PAGES)
  {
    if (flash_check_signature(page))
    {
      found = true;
      // read data
      // 設定
      memcpy(flash_data, (const uint8_t *)(XIP_BASE + FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page), FLASH_PAGE_SIZE);
    };
  }
  if (found && page >= LAST_PAGE)	// 見つけたのが最後のページだった場合は全消去
  {
    // disable interrupt
    uint32_t ints = save_and_disable_interrupts();
    // erase
    flash_range_erase(FLASH_TARGET_OFFSET, FLASH_BLOCK_SIZE);	// ブロック64KB全部消す (本当はセクタ4096byteの倍数で消せるが)
    // restore interrupt
    restore_interrupts(ints);
  }
  else if (found && flash_data[DATA_ERASED_FLAG] == 0xffu)
  {
    // シグネチャ有効かつ未消去ページが見つかった場合
    // このセクタの消去済フラグに0x00を書き込む
    flash_data[DATA_ERASED_FLAG] = 0;
    // disable interrupt
    uint32_t ints = save_and_disable_interrupts();
    // write
    flash_range_program(FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page, flash_data, FLASH_PAGE_SIZE);
    // restore interrupt
    restore_interrupts(ints);
  }
}

// 設定保存
static void save_settings(void)
{
  // fill with FF
  for (unsigned int i = 0; i < FLASH_PAGE_SIZE; i++) flash_data[i] = (uint8_t)0xffu;

  // set signature
  memcpy(flash_data, FLASH_SIGNATURE, sizeof(FLASH_SIGNATURE));

  // set sysmode
  *((uint16_t *)        (void *)&(flash_data[DATA_START_IN_PAGE])) = system_mode;
  //set clock mode
  *((z80_clock_mode_t *)(void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t)])) = z80_clock_mode;
  // debounce counters
  *((uint32_t *)        (void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t) + sizeof(uint16_t)])) = n_keyscans_press_debounce;
  *((uint32_t *)        (void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t) + sizeof(uint16_t) + sizeof(uint32_t)])) = n_keyscans_release_debounce;

  // get free page
  bool erase = false;
  uint32_t page;
  for (page = 0; page <= LAST_PAGE; page += SETTINGS_PAGES)
  {
    if (!flash_check_signature(page))	break;
  }
  if (page > LAST_PAGE)
  {
    page = 0;
    erase = true;
  }

  // disable interrupt
  uint32_t ints = save_and_disable_interrupts();
  // erase
  if (erase) flash_range_erase(FLASH_TARGET_OFFSET, FLASH_BLOCK_SIZE);	// ブロック64KB全部消す (本当はセクタ4096byteの倍数で消せるが)

  // write
  // 設定
  flash_range_program(FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page++, flash_data, FLASH_PAGE_SIZE);
  // ファンクションキー
  for (uint32_t fn = 0; fn < MZ_NUM_FKEYS; fn++)
  {
    flash_range_program(FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page++, (uint8_t *)&(mz_func_key_store[fn]), FLASH_PAGE_SIZE);
  }

  // restore interrupt
  restore_interrupts(ints);
}

// 設定の読み出し、またはデフォルトのセット
//   system_mode, z80_clock_mode, debounce_count，ファンクションキーマクロ
static void load_settings(void)
{
  // 設定が無かったときのためにまずデフォルト値をセットしておく
  system_mode = SYSTEM_MODE_DEFAULT;
  z80_clock_mode = Z80_CLOCK_MODE_AUTO;
  init_debounce_count();
  mz_func_key_init();


  // get latest settings
  bool found = false;
  uint32_t page, found_page;
  for (page = 0; page <= (DATA_PAGES - SETTINGS_PAGES); page += SETTINGS_PAGES)
  {
    if (flash_check_signature(page))
    {
      found = true;
      found_page = page;
    };
  }

  if (found)
  {
    page = found_page;
    // 設定部分をとりあえずリードしておく
    memcpy(flash_data, (const uint8_t *)(XIP_BASE + FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page++), FLASH_PAGE_SIZE);

    // 有効なデータか？
    if (flash_data[DATA_ERASED_FLAG] == 0xffu)
    {
      // signature check OK, return the data
      // sysmode
      system_mode =                 *((uint16_t *)(void *)&(flash_data[DATA_START_IN_PAGE]));								// offset 8
      // clock mode
      z80_clock_mode =      *((z80_clock_mode_t *)(void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t)]));					// offset 10
      // debounce counters
      n_keyscans_press_debounce   = *((uint32_t *)(void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t) + sizeof(uint16_t)]));			// offset 12
      n_keyscans_release_debounce = *((uint32_t *)(void *)&(flash_data[DATA_START_IN_PAGE + sizeof(uint16_t) + sizeof(uint16_t) + sizeof(uint32_t)]));	// offset 16

      // ファンクションキーのリード
      for (uint32_t fn = 0; fn < MZ_NUM_FKEYS; fn++)
      {
        memcpy((uint8_t *)&(mz_func_key_store[fn]), (const uint8_t *)(XIP_BASE + FLASH_TARGET_OFFSET + FLASH_PAGE_SIZE * page++), FLASH_PAGE_SIZE);
      }
    }
  }
}

// =======================================================================

/*------------- MAIN -------------*/
int main(void)
{
  board_init();

  // init GPIO and switches
  mz_switch_init();

  // fill ascii2hid table
  mz_fill_ascii2hid();

  // printf("MZKB + TinyUSB Host HID <-> Device CDC Example\r\n");

  // init device and host stack on configured roothub port
  tud_init(BOARD_TUD_RHPORT);
  tuh_init(BOARD_TUH_RHPORT);

  // enable keyscan detection
  gpio_set_irq_enabled_with_callback(MZ_KEYSCAN_DETECTION_PIN, GPIO_IRQ_EDGE_FALL, true, &keyscan_detection_callback);
  num_keyscan_called = 0;

  // 設定の読み出し、またはデフォルトのセット
  //   system_mode, z80_clock_mode, debounce_count，ファンクションキーマクロ
  load_settings();

  // initial task state
  mz_key_sending_task_state = MZ_TASK_STATE_POWERON;

  while (1)
  {
    tud_task(); // tinyusb device task
    tuh_task(); // tinyusb host task
    led_blinking_task();
    mz_host2mz_task();
    mz_sendkey_task();
    keyboard_led_blinking_task();
    z80_system_clock_task();
  }

  return 0;
}

//--------------------------------------------------------------------+
// Device CDC
//--------------------------------------------------------------------+

// Invoked when device is mounted
void tud_mount_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}

// Invoked when device is unmounted
void tud_umount_cb(void)
{
  blink_interval_ms = BLINK_NOT_MOUNTED;
}

// Invoked when usb bus is suspended
// remote_wakeup_en : if host allow us  to perform remote wakeup
// Within 7ms, device must draw an average of current less than 2.5 mA from bus
void tud_suspend_cb(bool remote_wakeup_en)
{
  (void) remote_wakeup_en;
  blink_interval_ms = BLINK_SUSPENDED;
}

// Invoked when usb bus is resumed
void tud_resume_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}

// Invoked when CDC interface received data from host
void tud_cdc_rx_cb(uint8_t itf)
{
  (void) itf;

  char buf[64];
  uint32_t count = tud_cdc_read(buf, sizeof(buf));

  for (uint32_t i = 0; i < count; i++)
  {
    mz_host_queue_put(buf[i]);
  }
}

//--------------------------------------------------------------------+
// Host HID
//--------------------------------------------------------------------+

// Invoked when device with hid interface is mounted
// Report descriptor is also available for use. tuh_hid_parse_report_descriptor()
// can be used to parse common/simple enough descriptor.
// Note: if report descriptor length > CFG_TUH_ENUMERATION_BUFSIZE, it will be skipped
// therefore report_desc = NULL, desc_len = 0
void tuh_hid_mount_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* desc_report, uint16_t desc_len)
{
  (void)desc_report;
  (void)desc_len;

  // Interface protocol (hid_interface_protocol_enum_t)
  const char* protocol_str[] = { "None", "Keyboard", "Mouse" };
  uint8_t const itf_protocol = tuh_hid_interface_protocol(dev_addr, instance);

  uint16_t vid, pid;
  tuh_vid_pid_get(dev_addr, &vid, &pid);

  char tempbuf[256];
  int count = sprintf(tempbuf, "[%04x:%04x][%u] HID Interface%u, Protocol = %s\r\n", vid, pid, dev_addr, instance, protocol_str[itf_protocol]);
  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();

  // Receive report from boot keyboard & mouse only
  // tuh_hid_report_received_cb() will be invoked when report is available
  if (itf_protocol == HID_ITF_PROTOCOL_KEYBOARD || itf_protocol == HID_ITF_PROTOCOL_MOUSE)
  {
    if ( !tuh_hid_receive_report(dev_addr, instance) )
    {
      tud_cdc_write_str("Error: cannot request report\r\n");
    }
  }

  // When HID Keyboard attached
  if (itf_protocol == HID_ITF_PROTOCOL_KEYBOARD)
  {
    // Init LED
    leds = 0;
    prev_leds = 0;
    keybd_dev_addr = dev_addr;
    keybd_instance = instance;
    tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &leds, sizeof(leds));

    // Reset SW Array & key state
    mz_switch_all_relase();
    // VBUS電源入れ直し中は状態変化させないが、他は初期状態へ
    if (mz_key_sending_task_state != MZ_TASK_STATE_CYCLE_VBUS_WAITING)
    {
      mz_key_sending_task_state = MZ_TASK_STATE_RESET_ASSERTED;
    }
    mz_task_start_ms = board_millis();
  }
}

// Invoked when device with hid interface is un-mounted
void tuh_hid_umount_cb(uint8_t dev_addr, uint8_t instance)
{
  char tempbuf[256];
  int count = sprintf(tempbuf, "[%u] HID Interface%u is unmounted\r\n", dev_addr, instance);
  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();

  // Reset SW Array & key state
  mz_switch_all_relase();
  // VBUS電源入れ直し中は状態変化させないが、他は初期状態へ
  if (mz_key_sending_task_state != MZ_TASK_STATE_CYCLE_VBUS_WAITING)
  {
    mz_key_sending_task_state = MZ_TASK_STATE_RESET_ASSERTED;
  }
  mz_task_start_ms = board_millis();

  keybd_dev_addr = 0xFFu;

  // Init KB LED
  leds = 0;
  prev_leds = 0;
  blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;

  // init mode
  mz_mode_init();
}

// look up new key in previous keys
static inline bool find_key_in_report(hid_keyboard_report_t const *report, uint8_t keycode)
{
  for(uint8_t i=0; i<6; i++)
  {
    if (report->keycode[i] == keycode)  return true;
  }

  return false;
}


// convert hid keycode to ascii and print via usb device CDC (ignore non-printable)
static void process_kbd_report(uint8_t dev_addr, hid_keyboard_report_t const *report)
{
  (void) dev_addr;
  static hid_keyboard_report_t prev_report = { 0, 0, {0} }; // previous report to check key released
  bool flush = false;
  static uint8_t last_modifier = 0;

  bool       is_shift  = report->modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
  bool const is_lshift = report->modifier & KEYBOARD_MODIFIER_LEFTSHIFT;
  bool const is_rshift = report->modifier & KEYBOARD_MODIFIER_RIGHTSHIFT;
  bool const is_ctrl   = report->modifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
  bool const is_alt    = report->modifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);

  char tempbuf[256];
  int count;

  // Check modifier change
  // シフトキー、コントロールを処理する
  if (last_modifier != report->modifier)
  {
    count = sprintf(tempbuf, "Modifier: %02x -> %02x\r\n", last_modifier, report->modifier);
    tud_cdc_write(tempbuf, (uint32_t) count);
    flush = true;

    // シフトキーは RAW モード時のみ処理する
    // (Cooked modeではシフトキーはキー変換に応じて処理されるので、ここではやらない)
    // -->Report the changed modifier
    if (mz_kb_mode == MZ_KBMODE_RAW)
    {
      if (MZ_KEYCODE_LS != MZ_KEYCODE_RS) {
        // LS and RS are different keys on the matrix
        if ((last_modifier ^ report->modifier) & KEYBOARD_MODIFIER_LEFTSHIFT)
        {
          // LS changed
          mz_key_queue_put(MZ_KEYCODE_LS | (is_lshift ? MZ_KEYPRESS : 0));
        }
        if ((last_modifier ^ report->modifier) & KEYBOARD_MODIFIER_RIGHTSHIFT)
        {
          // RS changed
          mz_key_queue_put(MZ_KEYCODE_RS | (is_rshift ? MZ_KEYPRESS : 0));
        }
      }
      else {
        // LS and RS are the same key on the matrix
        if ((last_modifier ^ report->modifier) & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT))
        {
          // LS or RSchanged
          mz_key_queue_put(MZ_KEYCODE_LS | (is_shift ? MZ_KEYPRESS : 0));
        }
      }
    }

    // コントロールキーはRAWモードかどうかかかわらずやる
    if (MZ_KEYCODE_CTRL != 0 && (is_ctrl != mz_last_ctrl_state))
    {
      mz_last_ctrl_state = is_ctrl;
      mz_key_queue_put(MZ_KEYCODE_CTRL | (is_ctrl ? MZ_KEYPRESS : 0));
    }
  }
  last_modifier = report->modifier;

  for(uint8_t i=0; i<6; i++)
  {
    uint8_t keycode = report->keycode[i];
    bool const is_del   = (keycode == DELETE_KEY_CODE);
    bool const is_end   = (keycode == END_KEY_CODE);
    bool const is_c     = (keycode == C_KEY_CODE);
    bool const is_caps  = (keycode == CAPS_KEY_CODE);
    bool const is_kana  = (keycode == KANA_KEY_CODE) || (keycode == KANA_KEY_CODE2);
    bool const is_grph  = (keycode == GRPH_KEY_CODE);
#ifdef MZ_DEBOUNCE_ADJUST
    bool const is_up    = (keycode == UP_KEY_CODE);
    bool const is_down  = (keycode == DOWN_KEY_CODE);
#endif
    bool const is_left  = (keycode == LEFT_KEY_CODE);
    bool const is_right = (keycode == RIGHT_KEY_CODE);

    if ( keycode )
    {
      if ( keycode && find_key_in_report(&prev_report, keycode) )
      {
        // exists in previous report means the current key is still holding
      }
      else
      {
        // not exist in previous report means the current key is newly pressed

        // remap the key code for Colemak layout
        #ifdef KEYBOARD_COLEMAK
        uint8_t colemak_key_code = colemak[keycode];
        if (colemak_key_code != 0) keycode = colemak_key_code;
        #endif

// モードシフト処理: RAW, KANA, GRPH, ALPHA
// -------------------------------------------------------------------
        // [ALT]+[CAPS]: RAW mode / COOKED mode 切替え
        if (is_caps && is_alt)
        {
          // RAWならALPHAへ、そうで無ければRAWへ
          mz_kb_mode = (mz_kb_mode == MZ_KBMODE_RAW) ? MZ_KBMODE_ALPHA : MZ_KBMODE_RAW;

          // All key relase when entering/leaving RAW mode
          mz_switch_all_relase();

          // Change task state
          mz_key_sending_task_state = MZ_TASK_STATE_ARRAY_RESET_ASSERTED;
          mz_task_start_ms = board_millis();

          // ALPHA とするため [英数] キーをキュー (★MZ New Monitorはカナモードのトグルで同期が取れなくなるためパッチ必要)
          mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
          mz_key_queue_put(MZ_KEYCODE_ALPHA);

          count = sprintf(tempbuf, "MZ: KB MODE = %s\r\n", mz_input_modestring(mz_kb_mode));
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
          // go to next key
          continue;
        }

        // KANA mode on
        else if ((mz_kb_mode != MZ_KBMODE_RAW) && (MZ_KEYCODE_KANA != 0) && (is_kana || (is_caps && is_shift && !is_alt)))
        {
          mz_kb_mode = MZ_KBMODE_KANA;

          if (MZ_KEYCODE_KANA == MZ_KEYCODE_ALPHA)
          {
            // [英数/カナ] キーの場合、シフト+英数キーをキュー
            mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_KANA);
            mz_key_queue_put(MZ_KEYCODE_LS);
          }
          else
          {
            // [英数]/[カナ] 独立の場合、カナキーをキュー
            mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_KANA);
          }

          count = sprintf(tempbuf, "[KANA ON]\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

          // go to next key
          continue;
        }

        // GRPH  mode on
        else if ((mz_kb_mode != MZ_KBMODE_RAW) && (MZ_KEYCODE_GRPH != 0) && is_grph)
        {
          mz_kb_mode = MZ_KBMODE_GRPH;

          if (NEED_ALPHA_GRPH)
          {
            // SA-1510(パッチ済み)の場合、[ALPHA][GRPH]の2キーを押す
            mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_ALPHA);
            mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_GRPH);
          }
          else
          {
            // [GRPH]キーをキュー
            mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_GRPH);
          }

          count = sprintf(tempbuf, "[GRPH ON]\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

          // go to next key
          continue;
        }

        // ALPHA mode on
        else if ((mz_kb_mode != MZ_KBMODE_RAW) && is_caps && !is_shift && !is_alt)
        {
          mz_kb_mode = MZ_KBMODE_ALPHA;

          // [英数] キーをキュー
          mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
          mz_key_queue_put(MZ_KEYCODE_ALPHA);

          count = sprintf(tempbuf, "[ALPHA ON]\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

          // go to next key
          continue;
        }
// -------------------------------------------------------------------

// ファンクションキー(キーマクロ)定義モードの検出とキーの記録:
// -------------------------------------------------------------------
        // キーマクロ定義モードの検出と遷移: [ALT]+[Fn]
        // disabled in RAW mode
        //------------------------------------------------------------
        if (mz_kb_mode != MZ_KBMODE_RAW && is_alt && (keycode >= MZ_START_FKEY) && (keycode <= MZ_END_FKEY))
        {
          uint16_t keynum = keycode - MZ_START_FKEY;

          if (!fkey_def_mode)
          {
            // enter fkey definition mode
            count = sprintf(tempbuf, "Enter [F%d] definition mode\r\n", keynum + (MZ_START_FKEY - F1_KEY_CODE) + 1);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;

            fkey_def_mode = true;
            fkey_def_keynum  = keynum;
            mz_func_key_store[fkey_def_keynum].length = 0;
            mz_func_key_store[fkey_def_keynum].initial_mz_kb_mode  = mz_kb_mode;
          }
          else
          {
            // exit from fkey definition mode
            count = sprintf(tempbuf, "Exit [F%d] definition mode\r\n", fkey_def_keynum + 1);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;

            fkey_def_mode = false;
          }
          // once enter / exit the mode, this key is done and wait for the next key
          continue;
        }
        //------------------------------------------------------------

        // キーマクロ定義モードならキーとmodifierの記録
        // if fkey_def_mode, record the keycode and modifier
        //------------------------------------------------------------
        if (fkey_def_mode)
        {
            if (mz_func_key_store[fkey_def_keynum].length < MZ_FKEY_MAXLEN)
            {
              mz_func_key_store[fkey_def_keynum].keycode[mz_func_key_store[fkey_def_keynum].length]  = keycode;
              mz_func_key_store[fkey_def_keynum].modifier[mz_func_key_store[fkey_def_keynum].length] = report->modifier;
              mz_func_key_store[fkey_def_keynum].length++;
            }
            if (mz_func_key_store[fkey_def_keynum].length >= MZ_FKEY_MAXLEN)
            {
              // exit from fkey definition mode
              count = sprintf(tempbuf, "Exit [F%d] definition mode due to buffer full\r\n", fkey_def_keynum + 1);
              tud_cdc_write(tempbuf, (uint32_t) count);
              flush = true;

              fkey_def_mode = false;
            }
        }
        //------------------------------------------------------------
// -------------------------------------------------------------------

// 入力したキーの表示(デバッグ用)
// -------------------------------------------------------------------
        uint8_t ch = keycode2ascii[keycode][is_shift ? 1 : 0];
        if (ch && !(ch & 0x80))
        {
          tud_cdc_write("C:", 2);
          if (ch == '\r') tud_cdc_write("[CR]", 4);
          else if (ch == '\t') tud_cdc_write("[TAB]", 5);
          else if (ch == '\b') tud_cdc_write("[BS]", 4);
          else if (ch == ' ') tud_cdc_write("[SP]", 4);
          else if (ch < 0x20u || ch >= 0x80u)
          {
            count = sprintf(tempbuf, "[%02x]", ch);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;
          }
          else tud_cdc_write(&ch, 1);
          tud_cdc_write("\r\n", 2);
          flush = true;
        }
        else
        {
          count = sprintf(tempbuf, "H:%02x/%02x\r\n", keycode, report->modifier);
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
        }
// -------------------------------------------------------------------


// 特殊キー操作
/*
  ■[CTRL]+[ALT]+[DEL]: 現在のシステムモードでROMを切り替えずリセットスイッチを押す (Cold Reset)
  ■[CTRL]+[ALT]+[END]: 現在のシステムモードでROMを切り替えず[CTRL]+リセットスイッチを押す (MZ-700系のWarm Resetのエミュレーション)
  ■[ALT] (+ [CTRL]) + テンキー[0]-[7]: システムモードの切り替え
  　ROMを切り替えてリセットスイッチを押す(Cold Reset)
*/
// -------------------------------------------------------------------
        // Check CTRL-ALT-DEL
        if (is_ctrl && is_alt && is_del)
        {
          mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_DEL;
          // no need to continue. just return.
          return;
        }

        // Check CTRL-ALT-END
        if (is_ctrl && is_alt && is_end)
        {
          if (MZ_KEYCODE_CTRL)
          {
            // コントロールキーがあるシステムのみ
            mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_END;
          }
          else
          {
            // コントロールキーが無いシステムではCTRL-ALT-DELと同じ
            mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_DEL;
          }
          // no need to continue. just return.
          return;
        }

        // Check ALT + ten key [0]-[7] (+ CTRL)
        if (is_alt && ((keycode >= TENKEY_1_KEY_CODE && keycode <= TENKEY_7_KEY_CODE) || (keycode == TENKEY_0_KEY_CODE)))
        {
          uint16_t keynum = keycode - TENKEY_1_KEY_CODE + 1;	// 1-7
          if (keynum > 7) keynum = 0;				// 0-7
	  if (is_ctrl) keynum += 8;				// 8-15

          count = sprintf(tempbuf, "MZ: system_mode = %d\r\n", keynum);
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

          system_mode = keynum;

          // init debounce count according to system mode
          init_debounce_count();

          mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_DEL;
          // no need to continue. just return.
          return;
        }

        // Check ALT + ten key [+][-][*]
        if (is_alt && (keycode == TENKEY_PLUS_KEY_CODE))
        {
          count = sprintf(tempbuf, "MZ: CLK 4MHz\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
          z80_clock_mode = Z80_CLOCK_MODE_4MHZ;
          continue;
        }
        if (is_alt && (keycode == TENKEY_MINUS_KEY_CODE))
        {
          count = sprintf(tempbuf, "MZ: CLK 2MHz\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
          z80_clock_mode = Z80_CLOCK_MODE_2MHZ;
          continue;
        }
        if (is_alt && (keycode == TENKEY_ASTERISK_KEY_CODE))
        {
          count = sprintf(tempbuf, "MZ: CLK AUTO\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
          z80_clock_mode = Z80_CLOCK_MODE_AUTO;
          continue;
        }

	// [ALT] + ten key [8]: erase settings
        if (is_alt && !is_shift && !is_ctrl && keycode == TENKEY_8_KEY_CODE)
	{
          count = sprintf(tempbuf, "MZ: erase settings\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
	  flush = true;
	  erase_settings();
          // この後、タイミングによってはUSBからの割り込みが来なくなるのでいったんVBUSを落とす
          mz_key_sending_task_state = MZ_TASK_STATE_CYCLE_VBUS;
          mz_task_start_ms = board_millis();
          continue;
	}

	// [ALT] + ten key [9]: save settings
        if (is_alt && !is_shift && !is_ctrl && keycode == TENKEY_9_KEY_CODE)
	{
          count = sprintf(tempbuf, "MZ: save settings\r\n");
          tud_cdc_write(tempbuf, (uint32_t) count);
	  flush = true;
	  save_settings();
          // この後、タイミングによってはUSBからの割り込みが来なくなるのでいったんVBUSを落とす
          mz_key_sending_task_state = MZ_TASK_STATE_CYCLE_VBUS;
          continue;
	}

// -------------------------------------------------------------------

// キータイミングのデバッグ用:
// -------------------------------------------------------------------
#ifdef MZ_DEBOUNCE_ADJUST
        // ALT-UP/DOWN/LEFT/RIGHT
        // adjust debounce timing
        if (is_alt & is_down) {
          if (n_keyscans_press_debounce > 1) n_keyscans_press_debounce--;
          sprintf(tempbuf, "press debounce = %u\r", n_keyscans_press_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
        else if (is_alt & is_up) {
          if (n_keyscans_press_debounce < 1000) n_keyscans_press_debounce++;
          sprintf(tempbuf, "press debounce = %u\r", n_keyscans_press_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
        else if (is_alt & is_left) {
          if (n_keyscans_release_debounce > 1) n_keyscans_release_debounce--;
          sprintf(tempbuf, "release debounce = %u\r", n_keyscans_release_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
        else if (is_alt & is_right) {
          if (n_keyscans_release_debounce < 1000) n_keyscans_release_debounce++;
          sprintf(tempbuf, "release debounce = %u\r", n_keyscans_release_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
#else
        if (is_alt & is_left) {
          if (n_keyscans_release_debounce > M_KEYSCANS_RELEASE_DEBOUNCE_DEF)		n_keyscans_release_debounce = M_KEYSCANS_RELEASE_DEBOUNCE_DEF;
          else if (n_keyscans_release_debounce > L_KEYSCANS_RELEASE_DEBOUNCE_DEF)	n_keyscans_release_debounce = L_KEYSCANS_RELEASE_DEBOUNCE_DEF;
          sprintf(tempbuf, "release debounce = %u\r", n_keyscans_release_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
        else if (is_alt & is_right) {
          if (n_keyscans_release_debounce < M_KEYSCANS_RELEASE_DEBOUNCE_DEF)		n_keyscans_release_debounce = M_KEYSCANS_RELEASE_DEBOUNCE_DEF;
          else if (n_keyscans_release_debounce < H_KEYSCANS_RELEASE_DEBOUNCE_DEF)	n_keyscans_release_debounce = H_KEYSCANS_RELEASE_DEBOUNCE_DEF;
          sprintf(tempbuf, "release debounce = %u\r", n_keyscans_release_debounce);
          mz_queue_string_as_key(tempbuf);
          continue;
        }
#endif
// -------------------------------------------------------------------


// ファンクションキー(キーマクロ)の検出とマクロの処理:
// -------------------------------------------------------------------
        // [F1] - [F12]
        // function key
        // [ =============================================================
        if (mz_kb_mode != MZ_KBMODE_RAW && (keycode >= MZ_START_FKEY) && (keycode <= MZ_END_FKEY))
        {
          // Function keys are disabled in RAW mode
          uint16_t keynum = keycode - MZ_START_FKEY;
          size_t l = mz_func_key_store[keynum].length;

          mz_kb_mode  =  mz_func_key_store[keynum].initial_mz_kb_mode;

          count = sprintf(tempbuf, "[F%d],kb:%s\r\n", keynum + (MZ_START_FKEY - F1_KEY_CODE) + 1, mz_input_modestring(mz_kb_mode));
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

        // ファンクションキーマクロ用の初期モードシフト処理: KANA, GRPH, ALPHA (RAWはやらない)
        // -------------------------------------------------------------------
          // KANA mode on
          if ((MZ_KEYCODE_KANA != 0) && (mz_kb_mode == MZ_KBMODE_KANA))
          {
            if (MZ_KEYCODE_KANA == MZ_KEYCODE_ALPHA)
            {
              // [英数/カナ] キーの場合、シフト+英数キーをキュー
              mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_KANA);
              mz_key_queue_put(MZ_KEYCODE_LS);
            }
            else
            {
              // [英数]/[カナ] 独立の場合、カナキーをキュー
              mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_KANA);
            }

            count = sprintf(tempbuf, "[KANA mode ON]\r\n");
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;
          }
          // GRPH  mode on
          else if ((MZ_KEYCODE_GRPH != 0) && (mz_kb_mode == MZ_KBMODE_GRPH))
          {
            if (NEED_ALPHA_GRPH)
            {
              // SA-1510(パッチ済み)の場合、[ALPHA][GRPH]の2キーを押す
              mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_ALPHA);
              mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_GRPH);
            }
            else
            {
              // [GRPH]キーをキュー
              mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_GRPH);
            }

            count = sprintf(tempbuf, "[GRPH mode ON]\r\n");
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;
          }
          // ALPHA mode on
          else
          {
            mz_kb_mode = MZ_KBMODE_ALPHA;

            // [英数] キーをキュー
            mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
            mz_key_queue_put(MZ_KEYCODE_ALPHA);

            count = sprintf(tempbuf, "[ALPHA mode ON]\r\n");
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;
          }
        // -------------------------------------------------------------------

        // ファンクションキーマクロの実行
        // -------------------------------------------------------------------
          for (size_t n = 0; n < l; n++)
          {
            uint8_t fkeycode     = mz_func_key_store[keynum].keycode[n];
            uint8_t fmodifier    = mz_func_key_store[keynum].modifier[n];
            bool       fis_shift = fmodifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
            bool       fis_ctrl  = fmodifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
            bool const fis_alt   = fmodifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);
            // bool const fis_del   = (fkeycode == DELETE_KEY_CODE);
            // bool const fis_end   = (fkeycode == END_KEY_CODE);
            bool const fis_c     = (fkeycode == C_KEY_CODE);
            bool const fis_caps  = (fkeycode == CAPS_KEY_CODE);
            bool const fis_kana  = (fkeycode == KANA_KEY_CODE) || (fkeycode == KANA_KEY_CODE2);
            bool const fis_grph  = (fkeycode == GRPH_KEY_CODE);
            uint16_t syx;


          // キーマクロ実行内モードシフト処理: KANA, GRPH, ALPHA (RAW以外)
          // -------------------------------------------------------------------
            // KANA mode on
            if ((MZ_KEYCODE_KANA != 0) && (fis_kana || (fis_caps && fis_shift && !fis_alt)))
            {
              mz_kb_mode = MZ_KBMODE_KANA;

              if (MZ_KEYCODE_KANA == MZ_KEYCODE_ALPHA)
              {
                // [英数/カナ] キーの場合、シフト+英数キーをキュー
                mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_KANA);
                mz_key_queue_put(MZ_KEYCODE_LS);
              }
              else
              {
                // [英数]/[カナ] 独立の場合、カナキーをキュー
                mz_key_queue_put(MZ_KEYCODE_KANA | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_KANA);
              }
              // go to next key
              continue;
            }
            // GRPH  mode on
            else if ((MZ_KEYCODE_GRPH != 0) && fis_grph)
            {
              mz_kb_mode = MZ_KBMODE_GRPH;

              if (NEED_ALPHA_GRPH)
              {
                // SA-1510(パッチ済み)の場合、[ALPHA][GRPH]の2キーを押す
                mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_ALPHA);
                mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_GRPH);
              }
              else
              {
                // [GRPH]キーをキュー
                mz_key_queue_put(MZ_KEYCODE_GRPH | MZ_KEYPRESS);
                mz_key_queue_put(MZ_KEYCODE_GRPH);
              }

              // go to next key
              continue;
            }
            // ALPHA mode on
            else if (fis_caps && !fis_shift && !fis_alt)
            {
              mz_kb_mode = MZ_KBMODE_ALPHA;

              // [英数] キーをキュー
              mz_key_queue_put(MZ_KEYCODE_ALPHA | MZ_KEYPRESS);
              mz_key_queue_put(MZ_KEYCODE_ALPHA);
              // go to next key
              continue;
            }
          // -------------------------------------------------------------------

          // キーエンコード:
          // -------------------------------------------------------------------
            // GRPH が無い場合、ALTでGRPH代わりとする
            if (MZ_KEYCODE_GRPH == 0)
            {
              if (fis_alt)
              {
                syx = KEYCODE2SYX[fkeycode][MZ_KBMODE_GRPH];
              }
              else
              {
                syx = KEYCODE2SYX[fkeycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && fis_shift) ? 1 : 0)];
              }
            }
            else
            {
              syx = KEYCODE2SYX[fkeycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && fis_shift) ? 1 : 0)];
            }

            // Check CTRL-C / SHIFT-CTRL-C
            // MZ-700J など、S-BASIC で CTRL-C (=ひらがな入力) など意味を持っている可能性があるため、CTRLキーを持つ機種でのこの処理は止める
            if (MZ_KEYCODE_CTRL == 0 && fis_ctrl && fis_c)
            {
              // Queue [SHIFT] + [BREAK] key pressed
              syx = MZ_KEYCODE_BREAK | MZ_SHIFT;
              fis_ctrl = 0;
            }
          // -------------------------------------------------------------------
          
          // キー押しエミュレーション (syx != 0)
          // -------------------------------------------------------------------
            if (syx)
            {
              // コントロールキー
              if (MZ_KEYCODE_CTRL != 0 && (fis_ctrl != mz_last_ctrl_state))
              {
                mz_last_ctrl_state = fis_ctrl;
                mz_key_queue_put(MZ_KEYCODE_CTRL | (fis_ctrl ? MZ_KEYPRESS : 0));
              }
              bool sft = (syx & MZ_SHIFT);
              syx = MZ_BARE_YX(syx);			// bare code
              mz_last_shift_state = sft;
              mz_last_lshift_state = false;
              mz_last_rshift_state = false;
              // press-release emulation
              if (sft) mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);	// SHIFT
              mz_key_queue_put(syx | MZ_KEYPRESS);			// press
              mz_key_queue_put(syx);					// release
              if (sft) mz_key_queue_put(MZ_KEYCODE_LS);			// SHIFT
            }
          // -------------------------------------------------------------------
          }	// go to next key
          // 最後にコントロールキーの辻褄を合わせる
          if (MZ_KEYCODE_CTRL != 0 && mz_last_ctrl_state)
          {
            mz_last_ctrl_state = 0;
            mz_key_queue_put(MZ_KEYCODE_CTRL);
          }
          continue;
        }
        // ] =============================================================
        else
        {
// 押されたキーをエンコード:
// -------------------------------------------------------------------
          uint16_t syx;
          // GRPH が無い場合、ALTでGRPH代わりとする
          if (MZ_KEYCODE_GRPH == 0)
          {
            if (is_alt)
            {
              syx = KEYCODE2SYX[keycode][MZ_KBMODE_GRPH];
            }
            else
            {
              syx = KEYCODE2SYX[keycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && is_shift) ? 1 : 0)];
            }
          }
          else
          {
            syx = KEYCODE2SYX[keycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && is_shift) ? 1 : 0)];
          }

          // Check CTRL-C / SHIFT-CTRL-C
          // MZ-700J など、S-BASIC で CTRL-C (=ひらがな入力) など意味を持っている可能性があるため、CTRLキーを持つ機種でのこの処理は止める
          if (mz_kb_mode != MZ_KBMODE_RAW && MZ_KEYCODE_CTRL == 0 && is_ctrl && is_c)
          {
            // Queue [SHIFT] + [BREAK] key pressed
            syx = MZ_KEYCODE_BREAK | MZ_SHIFT;
          }
// -------------------------------------------------------------------
        // キー押しエミュレーション (syx != 0)
        // -------------------------------------------------------------------
          if (syx)
          {
            if (mz_kb_mode == MZ_KBMODE_RAW)
            {
              // simply queue bare key press
              syx = MZ_BARE_YX(syx);		// bare code
              if (syx) mz_key_queue_put(syx | MZ_KEYPRESS);
            }
            else
            {
              if (syx & MZ_SHIFT)
              {
                mz_last_shift_state = true;
                // First, queue only SHIFT
                mz_key_queue_put(MZ_KEYCODE_LS | MZ_KEYPRESS);
                // Clear SHIFT bit and queue the bare key press
                syx = MZ_BARE_YX(syx);
              }
              else
              {
                mz_last_shift_state = false;
              }
              // queue bare key press
              mz_key_queue_put(syx | MZ_KEYPRESS);
            }
          }
        // -------------------------------------------------------------------
        }
      }
    }
  }

// キーリリース処理:
// -------------------------------------------------------------------
  // Handle released key
  bool       pis_shift  = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
  bool const pis_ctrl   = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
  bool const pis_alt    = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);

  for(uint8_t i=0; i<6; i++)
  {
    uint8_t keycode = prev_report.keycode[i];
    bool const pis_c = (keycode == C_KEY_CODE);

    if ( keycode )
    {
      if (find_key_in_report(report, keycode) && (mz_kb_mode == MZ_KBMODE_RAW || prev_report.modifier == report->modifier))
      {
        // exist in current report means the previous key is still holding
        // kaokun: however, modifier may be changed, e.g. the following sequence:
        // [Press Shift] - [Press a] - [Release Shift] - [release a]
        // we have to release the modifier-changed key other than in RAW mode.
      }
      else
      {
        // not existed in current report means the previous key is released, or the modifier changed

        // remap the key code for Colemak layout
        #ifdef KEYBOARD_COLEMAK
        uint8_t colemak_key_code = colemak[keycode];
        if (colemak_key_code != 0) keycode = colemak_key_code;
        #endif

// キーエンコード:
// -------------------------------------------------------------------
        uint16_t syx;
        // GRPH が無い場合、ALTでGRPH代わりとする
        if (MZ_KEYCODE_GRPH == 0)
        {
          if (pis_alt)
          {
            syx = KEYCODE2SYX[keycode][MZ_KBMODE_GRPH];
          }
          else
          {
            syx = KEYCODE2SYX[keycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && pis_shift) ? 1 : 0)];
          }
        }
        else
        {
          syx = KEYCODE2SYX[keycode][mz_kb_mode + ((mz_kb_mode != MZ_KBMODE_RAW && pis_shift) ? 1 : 0)];
        }

        // Check CTRL-C / SHIFT-CTRL-C
        // MZ-700J など、S-BASIC で CTRL-C (=ひらがな入力) など意味を持っている可能性があるため、CTRLキーを持つ機種でのこの処理は止める
        if (mz_kb_mode != MZ_KBMODE_RAW && MZ_KEYCODE_CTRL == 0 && pis_ctrl && pis_c)
        {
          // Queue [SHIFT] + [BREAK] key released
          syx = MZ_KEYCODE_BREAK | MZ_SHIFT;
        }
// -------------------------------------------------------------------
      // キー離しエミュレーション (syx != 0)
      // -------------------------------------------------------------------
        if (syx)
        {
          if (mz_kb_mode == MZ_KBMODE_RAW)
          {
            // simply queue bare key release
            syx = MZ_BARE_YX(syx);	// bare code
            if (syx) mz_key_queue_put(syx);
          }
          else
          {
            // First, queue only bare code
            mz_key_queue_put(syx & (uint16_t)~MZ_SHIFT);
            if (syx & MZ_SHIFT)
            {
              // Then release SHIFT
              mz_key_queue_put(MZ_KEYCODE_LS);
              mz_last_shift_state = false;
            }
          }
        }
      // -------------------------------------------------------------------
      }
    }
  }

  // Change LED
  leds = 0;
  if (mz_kb_mode == MZ_KBMODE_KANA)
  {
    leds = leds | KEYBOARD_LED_KANA | KEYBOARD_LED_NUMLOCK;
    blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_KANA;
  }
  if (mz_kb_mode == MZ_KBMODE_RAW)
  {
    leds = leds | KEYBOARD_LED_SCROLLLOCK | KEYBOARD_LED_NUMLOCK;
    blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_RAW;
  }

  if (flush) tud_cdc_write_flush();
  prev_report = *report;
}

// send mouse report to usb device CDC
static void process_mouse_report(uint8_t dev_addr, hid_mouse_report_t const * report)
{
  //------------- button state  -------------//
  //uint8_t button_changed_mask = report->buttons ^ prev_report.buttons;
  char l = report->buttons & MOUSE_BUTTON_LEFT   ? 'L' : '-';
  char m = report->buttons & MOUSE_BUTTON_MIDDLE ? 'M' : '-';
  char r = report->buttons & MOUSE_BUTTON_RIGHT  ? 'R' : '-';

  char tempbuf[32];
  int count = sprintf(tempbuf, "[%u] %c%c%c %d %d %d\r\n", dev_addr, l, m, r, report->x, report->y, report->wheel);

  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();
}

// Invoked when received report from device via interrupt endpoint
void tuh_hid_report_received_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* report, uint16_t len)
{
  (void) len;
  uint8_t const itf_protocol = tuh_hid_interface_protocol(dev_addr, instance);

  switch(itf_protocol)
  {
    case HID_ITF_PROTOCOL_KEYBOARD:
      process_kbd_report(dev_addr, (hid_keyboard_report_t const*) report );
      keybd_dev_addr = dev_addr;
      keybd_instance = instance;
    break;

    case HID_ITF_PROTOCOL_MOUSE:
      process_mouse_report(dev_addr, (hid_mouse_report_t const*) report );
    break;

    default: break;
  }

  // continue to request to receive report
  if ( !tuh_hid_receive_report(dev_addr, instance) )
  {
    tud_cdc_write_str("Error: cannot request report\r\n");
  }
}

//--------------------------------------------------------------------+
// Blinking Task
//--------------------------------------------------------------------+
void led_blinking_task(void)
{
  static uint32_t start_ms = 0;
  static bool led_state = false;

  // Blink every interval ms
  if ( board_millis() - start_ms < blink_interval_ms) return; // not enough time
  start_ms += blink_interval_ms;

  board_led_write(led_state);
  led_state = 1 - led_state; // toggle
}

// HID Keyboard LED
void keyboard_led_blinking_task(void)
{
  static uint32_t start_ms = 0;
  const bool is_numlock = leds & KEYBOARD_LED_NUMLOCK;
  static bool led_state = false;
  static uint8_t my_leds;
#ifdef HID_LED_DEBUG
  char tempbuf[256];
  int count;
#endif

  if (keybd_dev_addr == 0xFFu) return;

  my_leds = leds;
  if (is_numlock && (blink_numlock_led_interval_ms != BLINK_NUMLOCK_LED_NONE))
  {
    if (board_millis() - start_ms >= blink_numlock_led_interval_ms)
    {
      // Blink every interval ms
      start_ms = board_millis();
      led_state = 1 - led_state; // toggle
    }
    if (led_state)
    {
      my_leds = (uint8_t)(my_leds | KEYBOARD_LED_NUMLOCK);
    }
    else
    {
      my_leds = (uint8_t)(my_leds & ~KEYBOARD_LED_NUMLOCK);
    }
  }
  if (prev_leds != my_leds)
  {
    if (!tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &my_leds, sizeof(my_leds)))
    {
#ifdef HID_LED_DEBUG
      count = sprintf(tempbuf, "HID KB LED %02x fail\r\n", my_leds);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
#endif
      prev_leds = 0xFFu;	// for retry
    }
    else
    {
#ifdef HID_LED_DEBUG
      count = sprintf(tempbuf, "HID KB LED %02x Success\r\n", my_leds);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
#endif
      prev_leds = my_leds;
    }
  }
}

//--------------------------------------------------------------------+
// MZ key sending task
//--------------------------------------------------------------------+
void mz_sendkey_task(void)
{
  switch(mz_key_sending_task_state)
  {
    char tempbuf[256];
    int count;

    case MZ_TASK_STATE_POWERON:
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_POWERON_WAIT;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_POWERON_WAIT:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_POWERON_WAIT_MS) break;
      count = sprintf(tempbuf, "MZ: asserting SYSTEM RESET \r\n");
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_RESET;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_RESET:
      // release keys and queue clear
      mz_switch_all_relase();
      // Assert RESET on MZ
      mz_switch_ctrl_alt_del();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_RESET_ASSERTED;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_RESET_ASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_RESET_MS) break;
      // Deassert RESET on MZ and SW array
      mz_switch_deassert_array_reset();
      mz_switch_deassert_ctrl_alt_del();
      // init queue
      mz_host_queue_init();
      // init mode
      mz_mode_init();
      // init LED
      kb_led_init();
      // init fkey def mode
      fkey_def_mode = false;
      count = sprintf(tempbuf, "MZ: Switch array ready\r\nsystem mode=%0d\r\n", system_mode);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_GETKEY;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_ARRAY_RESET_ASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_RESET_MS) break;
      // Deassert RESET on SW array
      mz_switch_deassert_array_reset();
      // init queue
      mz_host_queue_init();
      // init fkey def mode
      fkey_def_mode = false;
      count = sprintf(tempbuf, "MZ: Switch array ready\r\nsystem mode=%0d\r\n", system_mode);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_GETKEY;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_GETKEY:
      if (!mz_key_queue_num_data()) break;			// queue empty
  
      uint16_t syx  = mz_key_queue_peek();			// Peek queue
      uint16_t bare_yx = MZ_BARE_YX(syx);
      bool onoff    = MZ_ISKEYPRESS(syx);
      uint8_t x     = MZ_X(syx);
      uint8_t y     = MZ_Y(syx);

      if (!syx) {
        // current syx is processed
        mz_key_queue_drop();
        break;
      }

      if (onoff && syx == last_on_syx)
      {
        // the same key is pressed. need extra delay
        mz_switch_start_waiting_between_the_same_key();
        break;
      }

      // current syx is being processed
      mz_key_queue_drop();

      // avoid SHIFT bounce, ON->OFF->ON
      if ((!onoff) && (bare_yx == MZ_KEYCODE_LS || bare_yx == MZ_KEYCODE_RS) && mz_key_queue_num_data())
      {
        // Current: Key off, the key is SHIFT and there is next data
        uint16_t next_syx = mz_key_queue_peek();	// Peek next data
        uint16_t next_bare_yx  = MZ_BARE_YX(next_syx);
        bool next_onoff = MZ_ISKEYPRESS(next_syx);
        if (next_onoff && (next_bare_yx == MZ_KEYCODE_LS || next_bare_yx == MZ_KEYCODE_RS))
        {
          // Next key: key on, the key is SHIFT
          mz_key_queue_drop();	// drop the next key
          // and no process for current SHIFT OFF
          break;
        }
      }
#ifdef MZ_KEYCODE_DEBUG
      count = sprintf(tempbuf, "MZ: Array (%d, %d) = %s\r\n", x, y, (onoff) ? "ON" : "OFF");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
#endif
      // Switch array control
      mz_switch_set(x, y, onoff);
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_KEY_STROBE_ASSERTED;
      mz_task_start_ms = board_millis();
      if (onoff && !(bare_yx == MZ_KEYCODE_LS || bare_yx == MZ_KEYCODE_RS))
      {
        // save the last pressed key other than [SHIFT]
        last_on_syx = syx;
      }

      // OFF->OFF->OFF->... does not need debounce time
      while ((!onoff) && mz_key_queue_num_data())
      {
        // Current: Key off and there is next data
        uint16_t next_syx = mz_key_queue_peek();	// Peek next data
        onoff = MZ_ISKEYPRESS(next_syx);
        if (!onoff)
        {
          x = MZ_X(next_syx);
          y = MZ_Y(next_syx);
#ifdef MZ_KEYCODE_DEBUG
          count = sprintf(tempbuf, "MZ: Array (%d, %d) = %s\r\n", x, y, (onoff) ? "ON" : "OFF");
          tud_cdc_write(tempbuf, (uint32_t) count);
          tud_cdc_write_flush();
#endif
          // Release the next key also
          mz_switch_set(x, y, onoff);
          // Change task state
          mz_key_sending_task_state = MZ_TASK_STATE_KEY_STROBE_ASSERTED;
          mz_task_start_ms = board_millis();
          // current syx is being processed
          mz_key_queue_drop();
        }
      }
      break;

    case MZ_TASK_STATE_KEY_STROBE_ASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_STROBE_MS) break;
      mz_switch_deassert_strobe();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_KEY_STROBE_DEASSERTED;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_KEY_STROBE_DEASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_STROBE_MS) break;
      mz_switch_start_waiting_debounce();
      break;

    case MZ_TASK_STATE_KEY_WAIT_DEBOUNCE:
      // RAWモードの時はdebounceなし (ゲームの応答性確保のため)
      if (mz_kb_mode != MZ_KBMODE_RAW && num_keyscan_called < n_keyscans_press_debounce)
      {
        if (board_millis() - mz_task_start_ms < MZ_KBIF_DEBOUNCE_MS) break;
      }
      mz_switch_get_next_key();
      break;

    case MZ_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE:
      // RAWモードの時はdebounceなし (ゲームの応答性確保のため)
      if (mz_kb_mode != MZ_KBMODE_RAW && num_keyscan_called < n_keyscans_release_debounce)
      {
        if (board_millis() - mz_task_start_ms < MZ_KBIF_RELEASE_DEBOUNCE_MS) break;
      }
      mz_switch_get_next_key();
      break;

    case MZ_TASK_STATE_CTRL_ALT_DEL:
      count = sprintf(tempbuf, "MZ: Asserting RESET on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // release keys and queue clear
      mz_switch_all_relase();
      // Assert RESET on MZ
      mz_switch_ctrl_alt_del();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_DEL_ASSERTED;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CTRL_ALT_DEL_ASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_CTRL_ALT_DEL_MS) break;
      // Deassert RESET on MZ and SW array
      mz_switch_deassert_array_reset();
      mz_switch_deassert_ctrl_alt_del();
      // init queue
      mz_host_queue_init();
      // init mode
      mz_mode_init();
      // init LED
      kb_led_init();
      // init fkey def mode
      fkey_def_mode = false;
      count = sprintf(tempbuf, "MZ: Deassert RESET on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_GETKEY;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CTRL_ALT_END:
      count = sprintf(tempbuf, "MZ: Asserting RESET on array\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      mz_switch_ctrl_alt_end();
      last_on_syx = 0;
      break;

    case MZ_TASK_STATE_CTRL_ALT_END_ASSERTED:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_CTRL_ALT_END_MS) break;
      // Dessert Reset of switch array IC
      mz_switch_deassert_array_reset();
      count = sprintf(tempbuf, "MZ: Deassert RESET on array IC\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Assert CTRL on MZ keyboard
      syx = MZ_KEYCODE_CTRL;
      mz_switch_set(MZ_X(syx), MZ_Y(syx), true);
      count = sprintf(tempbuf, "MZ: Assert CTRL on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_END_ASSERTED2;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CTRL_ALT_END_ASSERTED2:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_STROBE_MS) break;
      mz_switch_deassert_strobe();
      // set ROM A15-A12
      mz_set_ROM_addr();
      // Assert RESET on MZ
      gpio_put(MZ_PIO_MZ_RESET_PIN, 1);
      count = sprintf(tempbuf, "MZ: Assert RESET on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_END_ASSERTED3;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CTRL_ALT_END_ASSERTED3:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_CTRL_ALT_END_MS2) break;
      // Deassert RESET on MZ, still asserting CTRL
      gpio_put(MZ_PIO_MZ_RESET_PIN, 0);
      count = sprintf(tempbuf, "MZ: Deassert RESET on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_CTRL_ALT_END_ASSERTED4;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CTRL_ALT_END_ASSERTED4:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_CTRL_ALT_END_MS3) break;
      // Deassert CTRL on MZ keyboard
      syx = MZ_KEYCODE_CTRL;
      mz_switch_set(MZ_X(syx), MZ_Y(syx), false);
      count = sprintf(tempbuf, "MZ: Deassert CTRL on MZ\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_GETKEY;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_WAIT_BETWEEN_THE_SAME_KEY_MS) break;
      mz_switch_get_next_key();
      last_on_syx = 0;
      break;

    case MZ_TASK_STATE_CYCLE_VBUS:
      // DROP VBUSEN
      gpio_put(PIO_USB_VBUSEN_PIN, (1 - PIO_USB_VBUSEN_STATE));
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_CYCLE_VBUS_WAITING;
      mz_task_start_ms = board_millis();
      break;

    case MZ_TASK_STATE_CYCLE_VBUS_WAITING:
      if (board_millis() - mz_task_start_ms < MZ_KBIF_VBUS_CYCLE_MS)	break;
      // Enable VBUSEN
      gpio_put(PIO_USB_VBUSEN_PIN, PIO_USB_VBUSEN_STATE);
      // Change task state
      mz_key_sending_task_state = MZ_TASK_STATE_RESET;
      break;

    default:
      mz_key_sending_task_state = MZ_TASK_STATE_RESET;
      break;
  }
}

//
// host to MZ
//
void mz_host2mz_task(void)
{
  char buf[2];
  buf[1] = 0;
  char tempbuf[256];
  int count;

  while (mz_host_queue_num_data())
  {
    buf[0] = mz_host_queue_peek();
    count = sprintf(tempbuf, "HOSTQ:%02X\r\n", buf[0]);
    tud_cdc_write(tempbuf, (uint32_t) count);
    tud_cdc_write_flush();
    mz_host_queue_drop();
    mz_queue_string_as_key(buf);
  }
}
