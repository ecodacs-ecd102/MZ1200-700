/* 
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Ha Thach (tinyusb.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

// This example runs both host and device concurrently. The USB host receive
// reports from HID device and print it out over USB Device CDC interface.

// for PET-2001N with PCG-6500
#define PET2001N		1

// Array switch debug
#define PET_KEYCODE_DEBUG	1

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "bsp/board.h"
#include "tusb.h"

// GPIO for PET
#include "pico/stdlib.h"
#include "hardware/gpio.h"

//--------------------------------------------------------------------+
// MACRO CONSTANT TYPEDEF PROTYPES
//--------------------------------------------------------------------+

// uncomment if you are using colemak layout
// #define KEYBOARD_COLEMAK

#ifdef KEYBOARD_COLEMAK
const uint8_t colemak[128] = {
  0  ,  0,  0,  0,  0,  0,  0, 22,
  9  , 23,  7,  0, 24, 17,  8, 12,
  0  , 14, 28, 51,  0, 19, 21, 10,
  15 ,  0,  0,  0, 13,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0, 18,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0,
  0  ,  0,  0,  0,  0,  0,  0,  0
};
#endif

static uint8_t const keycode2ascii[256][2] =  {
    {0     , 0      }, /* 0x00 */ \
    {0     , 0      }, /* 0x01 */ \
    {0     , 0      }, /* 0x02 */ \
    {0     , 0      }, /* 0x03 */ \
    {'a'   , 'A'    }, /* 0x04 */ \
    {'b'   , 'B'    }, /* 0x05 */ \
    {'c'   , 'C'    }, /* 0x06 */ \
    {'d'   , 'D'    }, /* 0x07 */ \
    {'e'   , 'E'    }, /* 0x08 */ \
    {'f'   , 'F'    }, /* 0x09 */ \
    {'g'   , 'G'    }, /* 0x0a */ \
    {'h'   , 'H'    }, /* 0x0b */ \
    {'i'   , 'I'    }, /* 0x0c */ \
    {'j'   , 'J'    }, /* 0x0d */ \
    {'k'   , 'K'    }, /* 0x0e */ \
    {'l'   , 'L'    }, /* 0x0f */ \
    {'m'   , 'M'    }, /* 0x10 */ \
    {'n'   , 'N'    }, /* 0x11 */ \
    {'o'   , 'O'    }, /* 0x12 */ \
    {'p'   , 'P'    }, /* 0x13 */ \
    {'q'   , 'Q'    }, /* 0x14 */ \
    {'r'   , 'R'    }, /* 0x15 */ \
    {'s'   , 'S'    }, /* 0x16 */ \
    {'t'   , 'T'    }, /* 0x17 */ \
    {'u'   , 'U'    }, /* 0x18 */ \
    {'v'   , 'V'    }, /* 0x19 */ \
    {'w'   , 'W'    }, /* 0x1a */ \
    {'x'   , 'X'    }, /* 0x1b */ \
    {'y'   , 'Y'    }, /* 0x1c */ \
    {'z'   , 'Z'    }, /* 0x1d */ \
    {'1'   , '!'    }, /* 0x1e */ \
    {'2'   , '"'    }, /* 0x1f */ \
    {'3'   , '#'    }, /* 0x20 */ \
    {'4'   , '$'    }, /* 0x21 */ \
    {'5'   , '%'    }, /* 0x22 */ \
    {'6'   , '&'    }, /* 0x23 */ \
    {'7'   , '\x27' }, /* 0x24 "'" */ \
    {'8'   , '('    }, /* 0x25 */ \
    {'9'   , ')'    }, /* 0x26 */ \
    {'0'   , 0      }, /* 0x27 */ \
    {'\r'  , '\r'   }, /* 0x28 */ \
    {'\x1b', '\x1b' }, /* 0x29 [ESC] */ \
    {'\b'  , '\b'   }, /* 0x2a [BS] */ \
    {'\t'  , '\t'   }, /* 0x2b [TAB] */ \
    {' '   , ' '    }, /* 0x2c [SPACE] */ \
    {'-'   , '='    }, /* 0x2d */ \
    {'^'   , '~'    }, /* 0x2e */ \
    {'@'   , '`'    }, /* 0x2f */ \
    {'['   , '{'    }, /* 0x30 */ \
    {0     , 0      }, /* 0x31 */ \
    {']'   , '}'    }, /* 0x32 */ \
    {';'   , '+'    }, /* 0x33 */ \
    {':'   , '*'    }, /* 0x34 */ \
    {'\x12', '\x12' }, /* 0x35 ZEN/HAN = [RVS/OFF] key = ^R */ \
    {','   , '<'    }, /* 0x36 */ \
    {'.'   , '>'    }, /* 0x37 */ \
    {'/'   , '?'    }, /* 0x38 */ \
                                  \
    {0     , 0      }, /* 0x39: [CAPS] = SHIFT Lock */ \
    {0     , 0      }, /* 0x3a */ \
    {0     , 0      }, /* 0x3b */ \
    {0     , 0      }, /* 0x3c */ \
    {0     , 0      }, /* 0x3d */ \
    {0     , 0      }, /* 0x3e */ \
    {0     , 0      }, /* 0x3f */ \
    {0     , 0      }, /* 0x40 */ \
    {0     , 0      }, /* 0x41 */ \
    {'<'   , '<'    }, /* 0x42:[F9]  = < */ \
    {'>'   , '>'    }, /* 0x43:[F10] = > */ \
    {0     , 0      }, /* 0x44 [F11] */ \
    {'_'   , '_'    }, /* 0x45:[F12] = [Back Arrow]=chr$($5C) key on PET */ \
    {0     , 0      }, /* 0x46 */ \
    {0     , 0      }, /* 0x47 */ \
    {0     , 0      }, /* 0x48 */ \
    {0     , '\x14' }, /* 0x49 Insert */ \
    {'\x13', 0      }, /* 0x4a Home */ \
    {0     , 0      }, /* 0x4b */ \
    {'\x14', 0      }, /* 0x4c Delete */ \
    {0     , 0      }, /* 0x4d */ \
    {0     , 0      }, /* 0x4e */ \
    {'\x1d', 0      }, /* 0x4f right arrow */ \
    {'\x9d', 0      }, /* 0x50 left arrow */ \
    {'\x11', 0      }, /* 0x51 down arrow */ \
    {'\x91', 0      }, /* 0x52 up arrow */ \
    {0     , 0      }, /* 0x53 */ \
                                  \
    {'/'   , '/'    }, /* 0x54 */ \
    {'*'   , '*'    }, /* 0x55 */ \
    {'-'   , '-'    }, /* 0x56 */ \
    {'+'   , '+'    }, /* 0x57 */ \
    {'\r'  , '\r'   }, /* 0x58 */ \
    {'1'   , 0      }, /* 0x59 */ \
    {'2'   , 0      }, /* 0x5a */ \
    {'3'   , 0      }, /* 0x5b */ \
    {'4'   , 0      }, /* 0x5c */ \
    {'5'   , 0      }, /* 0x5d */ \
    {'6'   , 0      }, /* 0x5e */ \
    {'7'   , 0      }, /* 0x5f */ \
    {'8'   , 0      }, /* 0x60 */ \
    {'9'   , 0      }, /* 0x61 */ \
    {'0'   , 0      }, /* 0x62 */ \
    {'.'   , 0      }, /* 0x63 */ \
    {0     , 0      }, /* 0x64 */ \
    {'\x10', '\x10' }, /* 0x65:[Application] = PET [Repeat] key */ \
    {0     , 0      }, /* 0x66 */ \
    {'='   , '='    }, /* 0x67 */ \
    				  \
    {0     , 0      }, /* 0x68 */ \
    {0     , 0      }, /* 0x69 */ \
    {0     , 0      }, /* 0x6a */ \
    {0     , 0      }, /* 0x6b */ \
    {0     , 0      }, /* 0x6c */ \
    {0     , 0      }, /* 0x6d */ \
    {0     , 0      }, /* 0x6e */ \
    {0     , 0      }, /* 0x6f */ \
    {0     , 0      }, /* 0x70 */ \
    {0     , 0      }, /* 0x71 */ \
    {0     , 0      }, /* 0x72 */ \
    {0     , 0      }, /* 0x73 */ \
    {0     , 0      }, /* 0x74 */ \
    {0     , 0      }, /* 0x75 */ \
    {0     , 0      }, /* 0x76 */ \
    {0     , 0      }, /* 0x77 */ \
    {0     , 0      }, /* 0x78 */ \
    {0     , 0      }, /* 0x79 */ \
    {0     , 0      }, /* 0x7a */ \
    {0     , 0      }, /* 0x7b */ \
    {0     , 0      }, /* 0x7c */ \
    {0     , 0      }, /* 0x7d */ \
    {0     , 0      }, /* 0x7e */ \
    {0     , 0      }, /* 0x7f */ \
    {0     , 0      }, /* 0x80 */ \
    {0     , 0      }, /* 0x81 */ \
    {0     , 0      }, /* 0x82 */ \
    {0     , 0      }, /* 0x83 */ \
    {0     , 0      }, /* 0x84 */ \
    {0     , 0      }, /* 0x85 */ \
    {0     , 0      }, /* 0x86 */ \
    				  \
    {'\x5c', '_'    }, /* 0x87:[Backslash]/[_] key */ \
    {0     , 0      }, /* 0x88:[Hiragana/Katakana] */ \
    {'\x5c', 0      }, /* 0x89:[Yen]/[|] key */ \
};


/* Blink pattern
 * - 250 ms  : device not mounted
 * - 1000 ms : device mounted
 * - 2500 ms : device is suspended
 */
enum  {
  BLINK_NOT_MOUNTED = 250,
  BLINK_MOUNTED = 1000,
  BLINK_SUSPENDED = 2500,
};

static uint32_t blink_interval_ms = BLINK_NOT_MOUNTED;

void led_blinking_task(void);

/*------------- Keyboard LED  -------------*/
static uint8_t leds = 0;
static uint8_t prev_leds = 0;

/* NUMLOCK Blink pattern
 * - 250 ms : GAME mode
 * - 0 ms   : KANA mode
 */
enum  {
  BLINK_NUMLOCK_LED_NONE = 0,
  BLINK_NUMLOCK_LED_GAME = 250,
  BLINK_NUMLOCK_LED_KANA = 0,
};

static uint32_t blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;

// Keyboard address and instance (assumes there is only one)
static uint8_t keybd_dev_addr = 0xFFu;
static uint8_t keybd_instance;

void keyboard_led_blinking_task(void)
;

/*------------- PET  -------------*/

/*
#====================================================================
# Scan Code (Graphics keyboard)
#  ------+------------------------
#   row  |  7  6  5  4  3  2  1  0
#  +1 +0 |  H  G  F  E  D  C  B  A
#  ------+------------------------
#  a  9  | 3D 2E 10 03 3C 20 5B 12
#        |  =  . ^P ^C  < sp  [ ^R   ^C = STOP, ^R = Reverse on, ^P = [Repeat] key
#        |
#  9  8  | 2D 30 00 3E FF 5D 40 00
#        |  -  0 rs  > --  ] @  ls   rs = right shift, ls = left shift
#        |
#  8  7  | 2B 32 FF 3F 2C 4E 56 58
#        |  +  2 --  ?  ,  n  v  x
#        |
#  7  6  | 33 31 0D 3B 4D 42 43 5A
#        |  3  1 ^M  ;  m  b  c  z   ^M = return
#        |
#  6  5  | 2A 35 FF 3A 4B 48 46 53
#        |  *  5 --  :  k  h  f  s
#        |
#  5  4  | 36 34 FF 4C 4A 47 44 41
#        |  6  4 --  l  j  g  d  a
#        |
#  4  3  | 2F 38 9B 50 49 59 52 57
#        |  /  8 ^[  p  i  y  r  w   ^[ = ESC
#        |
#  3  2  | 39 37 5E 4F 55 54 45 51
#        |  9  7  ^  o  u  t  e  q   ^ = [Upper arrow]
#        |
#  2  1  | 14 11 09 29 5C 27 24 22
#        | ^T ^Q \t  )  \  '  $  "   ^T = DEL, ^Q = cursor down, \t=TAB
#        |
#  1  0  | 1d 13 5F 28 26 25 23 21
#        | ^] ^S  _  (  &  %  #  !   ^] = cursor right, _ = Back arrow, ^S = home
#  ------+------------------------
#====================================================================
*/
/*
  key code to switch matrix X-Y and SHIFT table
   (bit 8  : 1 = pressed, 0 = released, in queue only)
    bit 7  : Need SHIFT (1 = Generate with SHIFT key)
    bit 6-4: Y scanline (0-7)
    bit 3-0: X scanline + 1 (1-a), i.e. valid key has non-zero code on this table
*/
#define PET_KEYPRESS	0x100u
#define PET_ISKEYPRESS(x)	((x & PET_KEYPRESS) ? true : false)
#define PET_BARE_SYX(x)		((uint16_t)(x & ~PET_KEYPRESS))
#define PET_SHIFT	0x80u
#define PET_BARE_YX(x)		((uint16_t)(x & ~PET_KEYPRESS & ~PET_SHIFT))
#define PET_ISSHIFT(x)	((x & PET_SHIFT) ? 1 : 0)
#define PET_Y(x)	((x >> 4) & 0x07)
#define PET_X(x)	((x & 0x0f) - 1)
#define PET_LSX		8	// Left  shift X
#define PET_LSY		0	// Left  shift Y
#define PET_RSX		8	// Right shift X
#define PET_RSY		5	// Right shift Y
#define DELETE_KEY_CODE	0x4c	// for CTRL-ALT-DEL
#define C_KEY_CODE		0x06	// for CTRL-C
#define CAPS_KEY_CODE		0x39	// for SHIFT Lock
#define KANA_KEY_CODE		0x88	// for KANA input mode
#define F1_KEY_CODE		0x3a	// [F1] - [F8]: string send
#define PET_KEYCODE_RUN_STOP	0x4a	// PET [RUN/STOP] key X-Y
#define PET_KEYCODE_LS		0x09	// PET [Left SHIFT] key X-Y
#define PET_KEYCODE_RS		0x59	// PET [Right SHIFT] key X-Y
#define PET_KEYCODE_REPEAT	0x5a	// PET [Repeat] Key  X-Y
static uint8_t const keycode2petSYX[256][2] =  {
    {0             , 0             }, /* 0x00   */ \
    {0             , 0             }, /* 0x01   */ \
    {0             , 0             }, /* 0x02   */ \
    {0             , 0             }, /* 0x03   */ \
    {0x05          , 0x05|PET_SHIFT}, /* 0x04:a */ \
    {0x27          , 0x27|PET_SHIFT}, /* 0x05:b */ \
    {0x17          , 0x17|PET_SHIFT}, /* 0x06:c */ \
    {0x15          , 0x15|PET_SHIFT}, /* 0x07:d */ \
    {0x13          , 0x13|PET_SHIFT}, /* 0x08:e */ \
    {0x16          , 0x16|PET_SHIFT}, /* 0x09:f */ \
    {0x25          , 0x25|PET_SHIFT}, /* 0x0a:g */ \
    {0x26          , 0x26|PET_SHIFT}, /* 0x0b:h */ \
    {0x34          , 0x34|PET_SHIFT}, /* 0x0c:i */ \
    {0x35          , 0x35|PET_SHIFT}, /* 0x0d:j */ \
    {0x36          , 0x36|PET_SHIFT}, /* 0x0e:k */ \
    {0x45          , 0x45|PET_SHIFT}, /* 0x0f:l */ \
\
    {0x37          , 0x37|PET_SHIFT}, /* 0x10:m */ \
    {0x28          , 0x28|PET_SHIFT}, /* 0x11:n */ \
    {0x43          , 0x43|PET_SHIFT}, /* 0x12:o */ \
    {0x44          , 0x44|PET_SHIFT}, /* 0x13:p */ \
    {0x03          , 0x03|PET_SHIFT}, /* 0x14:q */ \
    {0x14          , 0x14|PET_SHIFT}, /* 0x15:r */ \
    {0x06          , 0x06|PET_SHIFT}, /* 0x16:s */ \
    {0x23          , 0x23|PET_SHIFT}, /* 0x17:t */ \
    {0x33          , 0x33|PET_SHIFT}, /* 0x18:u */ \
    {0x18          , 0x18|PET_SHIFT}, /* 0x19:v */ \
    {0x04          , 0x04|PET_SHIFT}, /* 0x1a:w */ \
    {0x08          , 0x08|PET_SHIFT}, /* 0x1b:x */ \
    {0x24          , 0x24|PET_SHIFT}, /* 0x1c:y */ \
    {0x07          , 0x07|PET_SHIFT}, /* 0x1d:z */ \
    {0x67          , 0x01          }, /* 0x1e:1/! */ \
    {0x68          , 0x02          }, /* 0x1f:2/" */ \
\
    {0x77          , 0x11          }, /* 0x20:3/# */ \
    {0x65          , 0x12          }, /* 0x21:4/$ */ \
    {0x66          , 0x21          }, /* 0x22:5/% */ \
    {0x75          , 0x31          }, /* 0x23:6/& */ \
    {0x63          , 0x22          }, /* 0x24:7/' */ \
    {0x64          , 0x41          }, /* 0x25:8/( */ \
    {0x73          , 0x42          }, /* 0x26:9/) */ \
    {0x69          , 0x69|PET_SHIFT}, /* 0x27:0 */ \
    {0x57          , 0x57|PET_SHIFT}, /* 0x28:[RETURN] */ \
    {0x54          , 0x54|PET_SHIFT}, /* 0x29:[ESC] = Unassigned key Graphics Keyboard */ \
    {0x72          , 0x72|PET_SHIFT}, /* 0x2a:[BS] = [INST/DEL] key */ \
    {0x52          , 0x52|PET_SHIFT}, /* 0x2b:[TAB] = Unassigned key Graphics Keyboard */ \
    {0x2a          , 0x2a|PET_SHIFT}, /* 0x2c:[SPACE] */ \
    {0x79          , 0x7a          }, /* 0x2d:-/= */ \
    {0x53          , 0x53|PET_SHIFT}, /* 0x2e:^/~ = [Upper arrow] / */ \
    {0x19          , 0x22          }, /* 0x2f:@/` = @/' */ \
\
    {0x1a          , 0x1a|PET_SHIFT}, /* 0x30:[  */ \
    {0             , 0             }, /* 0x31:NA */ \
    {0x29          , 0x29|PET_SHIFT}, /* 0x32:]  */ \
    {0x47          , 0x78          }, /* 0x33:;/+ */ \
    {0x46          , 0x76          }, /* 0x34:':'/'*' */ \
    {0x0a          , 0x0a|PET_SHIFT}, /* 0x35 ZEN/HAN = [RVS/OFF] key */ \
    {0x38          , 0x3a          }, /* 0x36:,/< */ \
    {0x6a          , 0x49          }, /* 0x37:./> */ \
    {0x74          , 0x48          }, /* 0x38:'/'/'?' */ \
    {0             , 0             }, /* 0x39: [SHIFT]+[CAPS] = SHIFT Lock ON/OFF */ \
    {0             , 0             }, /* 0x3a:[F1] */ \
    {0             , 0             }, /* 0x3b:[F2] */ \
    {0             , 0             }, /* 0x3c:[F3] */ \
    {0             , 0             }, /* 0x3d:[F4] */ \
    {0             , 0             }, /* 0x3e:[F5] */ \
    {0             , 0             }, /* 0x3f:[F6] */ \
\
    {0             , 0             }, /* 0x40:[F7] */ \
    {0             , 0             }, /* 0x41:[F8] */ \
    {0x3a          , 0x31|PET_SHIFT}, /* 0x42:[F9]  = < for 'TRON' game */ \
    {0x49          , 0x49|PET_SHIFT}, /* 0x43:[F10] = > for 'TRON' game */ \
    {0             , 0             }, /* 0x44 [F11] */ \
    {0x51          , 0x51|PET_SHIFT}, /* 0x45:[F12] = [Back Arrow] key on PET */ \
    {0             , 0             }, /* 0x46 */ \
    {0             , 0             }, /* 0x47 */ \
    {0             , 0             }, /* 0x48 */ \
    {0x72|PET_SHIFT, 0x72|PET_SHIFT}, /* 0x49 Insert = SHIFT + [DEL/INST] */ \
    {0x61          , 0x61|PET_SHIFT}, /* 0x4a Home = [HOME/CLR] */ \
    {0             , 0             }, /* 0x4b */ \
    {0x72          , 0x72|PET_SHIFT}, /* 0x4c Delete = [DEL/INST] key */ \
    {0             , 0             }, /* 0x4d */ \
    {0             , 0             }, /* 0x4e */ \
    {0x71          , 0x71|PET_SHIFT}, /* 0x4f right arrow */ \
\
    {0x71|PET_SHIFT, 0x71          }, /* 0x50 left arrow */ \
    {0x62          , 0x62|PET_SHIFT}, /* 0x51 down arrow */ \
    {0x62|PET_SHIFT, 0x62          }, /* 0x52 up arrow */ \
    {0             , 0             }, /* 0x53 */ \
    {0x74          , 0x74|PET_SHIFT}, /* 0x54:/ */ \
    {0x76          , 0x76|PET_SHIFT}, /* 0x55:* */ \
    {0x79          , 0x79|PET_SHIFT}, /* 0x56:- */ \
    {0x78          , 0x78|PET_SHIFT}, /* 0x57:+ */ \
    {0x57          , 0x57|PET_SHIFT}, /* 0x58:[RETURN] */ \
    {0x67          , 0x67|PET_SHIFT}, /* 0x59:1 */ \
    {0x68          , 0x68|PET_SHIFT}, /* 0x5a:2 */ \
    {0x77          , 0x77|PET_SHIFT}, /* 0x5b:3 */ \
    {0x65          , 0x65|PET_SHIFT}, /* 0x5c:4 */ \
    {0x66          , 0x66|PET_SHIFT}, /* 0x5d:5 */ \
    {0x75          , 0x75|PET_SHIFT}, /* 0x5e:6 */ \
    {0x63          , 0x63|PET_SHIFT}, /* 0x5f:7 */ \
\
    {0x64          , 0x64|PET_SHIFT}, /* 0x60:8 */ \
    {0x73          , 0x73|PET_SHIFT}, /* 0x61:9 */ \
    {0x69          , 0x69|PET_SHIFT}, /* 0x62:0 */ \
    {0x6a          , 0x6a|PET_SHIFT}, /* 0x63:. */ \
    {0             , 0             }, /* 0x64 */ \
    {0x5a          , 0x5a          }, /* 0x65:[Application] = PET [Repeat] key */ \
    {0             , 0             }, /* 0x66 */ \
    {0x7a          , 0x7a|PET_SHIFT}, /* 0x67:= */ \
    {0             , 0             }, /* 0x68 */ \
    {0             , 0             }, /* 0x69 */ \
    {0             , 0             }, /* 0x6a */ \
    {0             , 0             }, /* 0x6b */ \
    {0             , 0             }, /* 0x6c */ \
    {0             , 0             }, /* 0x6d */ \
    {0             , 0             }, /* 0x6e */ \
    {0             , 0             }, /* 0x6f */ \
 \
    {0             , 0             }, /* 0x70 */ \
    {0             , 0             }, /* 0x71 */ \
    {0             , 0             }, /* 0x72 */ \
    {0             , 0             }, /* 0x73 */ \
    {0             , 0             }, /* 0x74 */ \
    {0             , 0             }, /* 0x75 */ \
    {0             , 0             }, /* 0x76 */ \
    {0             , 0             }, /* 0x77 */ \
    {0             , 0             }, /* 0x78 */ \
    {0             , 0             }, /* 0x79 */ \
    {0             , 0             }, /* 0x7a */ \
    {0             , 0             }, /* 0x7b */ \
    {0             , 0             }, /* 0x7c */ \
    {0             , 0             }, /* 0x7d */ \
    {0             , 0             }, /* 0x7e */ \
    {0             , 0             }, /* 0x7f */ \
 \
    {0             , 0             }, /* 0x80 */ \
    {0             , 0             }, /* 0x81 */ \
    {0             , 0             }, /* 0x82 */ \
    {0             , 0             }, /* 0x83 */ \
    {0             , 0             }, /* 0x84 */ \
    {0             , 0             }, /* 0x85 */ \
    {0             , 0             }, /* 0x86 */ \
    {0x32          , 0x51          }, /* 0x87:[Backslash]/[_] key, '_' = CHR$(0x5f) = Backarrow in PETSCII */ \
    {0             , 0             }, /* 0x88:[Hiragana/Katakana] */ \
    {0x32          , 0x29|PET_SHIFT}, /* 0x89:[Yen]/[|] key */ \
};

// table for KANA shift
static uint8_t const keycode2petSYX_kana[256][2] =  {
    {0             , 0             }, /* 0x00   */ \
    {0             , 0             }, /* 0x01   */ \
    {0             , 0             }, /* 0x02   */ \
    {0             , 0             }, /* 0x03   */ \
    {0x05|PET_SHIFT, 0x05|PET_SHIFT}, /* 0x04:[PET:A] チ */ \
    {0x46|PET_SHIFT, 0x46|PET_SHIFT}, /* 0x05:[PET::] コ */ \
    {0x48|PET_SHIFT, 0x48|PET_SHIFT}, /* 0x06:[PET:?] ソ */ \
    {0x3a|PET_SHIFT, 0x3a|PET_SHIFT}, /* 0x07:[PET:<] シ */ \
    {0x02|PET_SHIFT, 0x02|PET_SHIFT}, /* 0x08:[PET:"] イ */ \
    {0x35|PET_SHIFT, 0x35|PET_SHIFT}, /* 0x09:[PET:J] ハ */ \
    {0x22|PET_SHIFT, 0x22|PET_SHIFT}, /* 0x0a:[PET:'] キ */ \
    {0x41|PET_SHIFT, 0x41|PET_SHIFT}, /* 0x0b:[PET:(] ク */ \
    {0x16|PET_SHIFT, 0x16|PET_SHIFT}, /* 0x0c:[PET:F] ニ */ \
    {0x43|PET_SHIFT, 0x43|PET_SHIFT}, /* 0x0d:[PET:O] マ */ \
    {0x34|PET_SHIFT, 0x34|PET_SHIFT}, /* 0x0e:[PET:I] ノ */ \
    {0x08|PET_SHIFT, 0x08|PET_SHIFT}, /* 0x0f:[PET:X] リ */ \
\
    {0x06|PET_SHIFT, 0x06|PET_SHIFT}, /* 0x10:[PET:S] モ */ \
    {0x44|PET_SHIFT, 0x44|PET_SHIFT}, /* 0x11:[PET:P] ミ */ \
    {0x04|PET_SHIFT, 0x04|PET_SHIFT}, /* 0x12:[PET:W] ラ */ \
    {0x49|PET_SHIFT, 0x49|PET_SHIFT}, /* 0x13:[PET:>] セ */ \
    {0x63|PET_SHIFT, 0x63|PET_SHIFT}, /* 0x14:[PET:7] タ */ \
    {0x38|PET_SHIFT, 0x38|PET_SHIFT}, /* 0x15:[PET:,] ス */ \
    {0x15|PET_SHIFT, 0x15|PET_SHIFT}, /* 0x16:[PET:D] ト */ \
    {0x31|PET_SHIFT, 0x31|PET_SHIFT}, /* 0x17:[PET:&] カ */ \
    {0x13|PET_SHIFT, 0x13|PET_SHIFT}, /* 0x18:[PET:E] ナ */ \
    {0x36|PET_SHIFT, 0x36|PET_SHIFT}, /* 0x19:[PET:K] ヒ */ \
    {0x17|PET_SHIFT, 0x17|PET_SHIFT}, /* 0x1a:[PET:C] テ */ \
    {0x47|PET_SHIFT, 0x47|PET_SHIFT}, /* 0x1b:[PET:;] サ */ \
    {0x73|PET_SHIFT, 0x73|PET_SHIFT}, /* 0x1c:[PET:9] ン */ \
    {0x27|PET_SHIFT, 0x27|PET_SHIFT}, /* 0x1d:[PET:B] ツ */ \
    {0x25|PET_SHIFT, 0x25|PET_SHIFT}, /* 0x1e:[PET:G] ヌ */ \
    {0x45|PET_SHIFT, 0x45|PET_SHIFT}, /* 0x1f:[PET:L] フ */ \
\
    {0x01|PET_SHIFT, 0x01|PET_SHIFT}, /* 0x20:[PET:!] ア */ \
    {0x11|PET_SHIFT, 0x11|PET_SHIFT}, /* 0x21:[PET:#] ウ */ \
    {0x12|PET_SHIFT, 0x12|PET_SHIFT}, /* 0x22:[PET:$] エ */ \
    {0x21|PET_SHIFT, 0x21|PET_SHIFT}, /* 0x23:[PET:%] オ */ \
    {0x23|PET_SHIFT, 0x23|PET_SHIFT}, /* 0x24:[PET:T] ヤ */ \
    {0x33|PET_SHIFT, 0x33|PET_SHIFT}, /* 0x25:[PET:U] ユ */ \
    {0x18|PET_SHIFT, 0x18|PET_SHIFT}, /* 0x26:[PET:V] ヨ */ \
    {0x32|PET_SHIFT, 0x51|PET_SHIFT}, /* 0x27:[PET:＼]/[PET:←] ワ/ヲ */ \
    {0x57          , 0x57|PET_SHIFT}, /* 0x28:[RETURN] */ \
    {0x54          , 0x54|PET_SHIFT}, /* 0x29:[ESC] = Unassigned key Graphics Keyboard */ \
    {0x72          , 0x72|PET_SHIFT}, /* 0x2a:[BS] = [INST/DEL] key */ \
    {0x52          , 0x52|PET_SHIFT}, /* 0x2b:[TAB] = Unassigned key Graphics Keyboard */ \
    {0x2a          , 0x2a|PET_SHIFT}, /* 0x2c:[SPACE] */ \
    {0x28|PET_SHIFT, 0x28|PET_SHIFT}, /* 0x2d:[PET:N] ホ */ \
    {0x37|PET_SHIFT, 0x37|PET_SHIFT}, /* 0x2e:[PET:M] ヘ */ \
    {0x76|PET_SHIFT, 0x76|PET_SHIFT}, /* 0x2f:[PET:*] ゛/ */ \
\
    {0x74|PET_SHIFT, 0x69|PET_SHIFT}, /* 0x30:[PET:/][PET:0] ゜/「 */ \
    {0             , 0             }, /* 0x31 */ \
    {0x03|PET_SHIFT, 0x7a|PET_SHIFT}, /* 0x32:[PET:Q][PET:=] ム/」  */ \
    {0x07|PET_SHIFT, 0x07|PET_SHIFT}, /* 0x33:[PET:Z] レ */ \
    {0x42|PET_SHIFT, 0x42|PET_SHIFT}, /* 0x34:[PET:)] ケ */ \
    {0x0a          , 0x0a|PET_SHIFT}, /* 0x35 ZEN/HAN = [RVS/OFF] key */ \
    {0x26|PET_SHIFT, 0x38          }, /* 0x36:[PET:H]/[PET:,] ネ/、 */ \
    {0x24|PET_SHIFT, 0x6a          }, /* 0x37:[PET:Y]/[PET:.] ル/。 */ \
    {0x14|PET_SHIFT, 0             }, /* 0x38:[PET:R]/[PET:NA] メ/・ */ \
    {0             , 0             }, /* 0x39: [SHIFT]+[CAPS] = SHIFT Lock ON/OFF */ \
    {0             , 0             }, /* 0x3a:[F1] */ \
    {0             , 0             }, /* 0x3b:[F2] */ \
    {0             , 0             }, /* 0x3c:[F3] */ \
    {0             , 0             }, /* 0x3d:[F4] */ \
    {0             , 0             }, /* 0x3e:[F5] */ \
    {0             , 0             }, /* 0x3f:[F6] */ \
\
    {0             , 0             }, /* 0x40:[F7] */ \
    {0             , 0             }, /* 0x41:[F8] */ \
    {0x65|PET_SHIFT, 0x65|PET_SHIFT}, /* 0x42:[F9] [PET:4] 年 */ \
    {0x66|PET_SHIFT, 0x66|PET_SHIFT}, /* 0x43:[F10][PET:5] 月 */ \
    {0x75|PET_SHIFT, 0x75|PET_SHIFT}, /* 0x44:[F11][PET:6] 日 */ \
    {0x51          , 0x51|PET_SHIFT}, /* 0x45:[F12] = [Back Arrow] key on PET */ \
    {0             , 0             }, /* 0x46 */ \
    {0             , 0             }, /* 0x47 */ \
    {0             , 0             }, /* 0x48 */ \
    {0x72|PET_SHIFT, 0x72|PET_SHIFT}, /* 0x49 Insert = SHIFT + [DEL/INST] */ \
    {0x61          , 0x61|PET_SHIFT}, /* 0x4a Home = [HOME/CLR] */ \
    {0             , 0             }, /* 0x4b */ \
    {0x72          , 0x72|PET_SHIFT}, /* 0x4c Delete = [DEL/INST] key */ \
    {0             , 0             }, /* 0x4d */ \
    {0             , 0             }, /* 0x4e */ \
    {0x71          , 0x71|PET_SHIFT}, /* 0x4f right arrow */ \
\
    {0x71|PET_SHIFT, 0x71          }, /* 0x50 left arrow */ \
    {0x62          , 0x62|PET_SHIFT}, /* 0x51 down arrow */ \
    {0x62|PET_SHIFT, 0x62          }, /* 0x52 up arrow */ \
    {0             , 0             }, /* 0x53 */ \
    {0x74          , 0x74|PET_SHIFT}, /* 0x54:/ */ \
    {0x76          , 0x76|PET_SHIFT}, /* 0x55:* */ \
    {0x79          , 0x79|PET_SHIFT}, /* 0x56:- */ \
    {0x78          , 0x78|PET_SHIFT}, /* 0x57:+ */ \
    {0x57          , 0x57|PET_SHIFT}, /* 0x58:[RETURN] */ \
    {0x67          , 0x67|PET_SHIFT}, /* 0x59:1 */ \
    {0x68          , 0x68|PET_SHIFT}, /* 0x5a:2 */ \
    {0x77          , 0x77|PET_SHIFT}, /* 0x5b:3 */ \
    {0x65          , 0x65|PET_SHIFT}, /* 0x5c:4 */ \
    {0x66          , 0x66|PET_SHIFT}, /* 0x5d:5 */ \
    {0x75          , 0x75|PET_SHIFT}, /* 0x5e:6 */ \
    {0x63          , 0x63|PET_SHIFT}, /* 0x5f:7 */ \
\
    {0x64          , 0x64|PET_SHIFT}, /* 0x60:8 */ \
    {0x73          , 0x73|PET_SHIFT}, /* 0x61:9 */ \
    {0x69          , 0x69|PET_SHIFT}, /* 0x62:0 */ \
    {0x6a          , 0x6a|PET_SHIFT}, /* 0x63:. */ \
    {0             , 0             }, /* 0x64 */ \
    {0x5a          , 0x5a          }, /* 0x65:[Application] = PET [Repeat] key */ \
    {0             , 0             }, /* 0x66 */ \
    {0x7a          , 0x7a|PET_SHIFT}, /* 0x67:= */ \
    {0             , 0             }, /* 0x68 */ \
    {0             , 0             }, /* 0x69 */ \
    {0             , 0             }, /* 0x6a */ \
    {0             , 0             }, /* 0x6b */ \
    {0             , 0             }, /* 0x6c */ \
    {0             , 0             }, /* 0x6d */ \
    {0             , 0             }, /* 0x6e */ \
    {0             , 0             }, /* 0x6f */ \
 \
    {0             , 0             }, /* 0x70 */ \
    {0             , 0             }, /* 0x71 */ \
    {0             , 0             }, /* 0x72 */ \
    {0             , 0             }, /* 0x73 */ \
    {0             , 0             }, /* 0x74 */ \
    {0             , 0             }, /* 0x75 */ \
    {0             , 0             }, /* 0x76 */ \
    {0             , 0             }, /* 0x77 */ \
    {0             , 0             }, /* 0x78 */ \
    {0             , 0             }, /* 0x79 */ \
    {0             , 0             }, /* 0x7a */ \
    {0             , 0             }, /* 0x7b */ \
    {0             , 0             }, /* 0x7c */ \
    {0             , 0             }, /* 0x7d */ \
    {0             , 0             }, /* 0x7e */ \
    {0             , 0             }, /* 0x7f */ \
 \
    {0             , 0             }, /* 0x80 */ \
    {0             , 0             }, /* 0x81 */ \
    {0             , 0             }, /* 0x82 */ \
    {0             , 0             }, /* 0x83 */ \
    {0             , 0             }, /* 0x84 */ \
    {0             , 0             }, /* 0x85 */ \
    {0             , 0             }, /* 0x86 */ \
    {0x64|PET_SHIFT, 0x64|PET_SHIFT}, /* 0x87:[PET:8] ロ key */ \
    {0             , 0             }, /* 0x88:[Hiragana/Katakana] */ \
    {0x79          , 0x29|PET_SHIFT}, /* 0x89:[PET:\] －/[|] key */ \
};

// table for GAME mode (transparent shift mode)
static uint8_t const keycode2petSYX_game[256] =  {
    0   , /* 0x00   */ \
    0   , /* 0x01   */ \
    0   , /* 0x02   */ \
    0   , /* 0x03   */ \
    0x05, /* 0x04:a */ \
    0x27, /* 0x05:b */ \
    0x17, /* 0x06:c */ \
    0x15, /* 0x07:d */ \
    0x13, /* 0x08:e */ \
    0x16, /* 0x09:f */ \
    0x25, /* 0x0a:g */ \
    0x26, /* 0x0b:h */ \
    0x34, /* 0x0c:i */ \
    0x35, /* 0x0d:j */ \
    0x36, /* 0x0e:k */ \
    0x45, /* 0x0f:l */ \
\
    0x37, /* 0x10:m */ \
    0x28, /* 0x11:n */ \
    0x43, /* 0x12:o */ \
    0x44, /* 0x13:p */ \
    0x03, /* 0x14:q */ \
    0x14, /* 0x15:r */ \
    0x06, /* 0x16:s */ \
    0x23, /* 0x17:t */ \
    0x33, /* 0x18:u */ \
    0x18, /* 0x19:v */ \
    0x04, /* 0x1a:w */ \
    0x08, /* 0x1b:x */ \
    0x24, /* 0x1c:y */ \
    0x07, /* 0x1d:z */ \
    0x01, /* 0x1e:1[!] */ \
    0x02, /* 0x1f:2["] */ \
\
    0x11, /* 0x20:3[#] */ \
    0x12, /* 0x21:4[$] */ \
    0x21, /* 0x22:5[%] */ \
    0x31, /* 0x23:6[&] */ \
    0x22, /* 0x24:7['] */ \
    0x41, /* 0x25:8[(] */ \
    0x42, /* 0x26:9[)] */ \
    0   , /* 0x27:0:N/A */ \
    0x57, /* 0x28:[RETURN] */ \
    0x54, /* 0x29:[ESC] = Unassigned key Graphics Keyboard */ \
    0x72, /* 0x2a:[BS] = [INST/DEL] key */ \
    0x52, /* 0x2b:[TAB] = Unassigned key Graphics Keyboard */ \
    0x2a, /* 0x2c:[SPACE] */ \
    0x7a, /* 0x2d:-[=] */ \
    0x53, /* 0x2e:^/~ = [Upper arrow] / */ \
    0x19, /* 0x2f:@/` = @/' */ \
\
    0x1a, /* 0x30:[  */ \
    0   , /* 0x31:NA */ \
    0x29, /* 0x32:]  */ \
    0x47, /* 0x33:;/+ = [;] */ \
    0x46, /* 0x34:':'/'*' = [:] */ \
    0x0a, /* 0x35 ZEN/HAN = [RVS/OFF] key */ \
    0x38, /* 0x36:,/< = [,] */ \
    0x6a, /* 0x37:./> = [.] */ \
    0x48, /* 0x38:'/'/'?' =[?] */ \
    0   , /* 0x39: [CAPS] = SHIFT Lock ON/OFF */ \
    0   , /* 0x3a:[F1] */ \
    0   , /* 0x3b:[F2] */ \
    0   , /* 0x3c:[F3] */ \
    0   , /* 0x3d:[F4] */ \
    0   , /* 0x3e:[F5] */ \
    0   , /* 0x3f:[F6] */ \
\
    0   , /* 0x40:[F7] */ \
    0   , /* 0x41:[F8] */ \
    0x3a, /* 0x42:[F9]  = < for 'TRON' game */ \
    0x49, /* 0x43:[F10] = > for 'TRON' game */ \
    0   , /* 0x44 [F11] */ \
    0x51, /* 0x45:[F12] = [Back Arrow] key on PET */ \
    0   , /* 0x46 */ \
    0   , /* 0x47 */ \
    0   , /* 0x48 */ \
    0   , /* 0x49 Insert = N/A */ \
    0x61, /* 0x4a Home = [HOME/CLR] */ \
    0   , /* 0x4b */ \
    0x72, /* 0x4c Delete = [DEL/INST] key */ \
    0   , /* 0x4d */ \
    0   , /* 0x4e */ \
    0x71, /* 0x4f right arrow */ \
\
    0   , /* 0x50 left arrow = N/A */ \
    0x62, /* 0x51 down arrow */ \
    0   , /* 0x52 up arrow = N/A */ \
    0   , /* 0x53 */ \
    0x74, /* 0x54:/ */ \
    0x76, /* 0x55:* */ \
    0x79, /* 0x56:- */ \
    0x78, /* 0x57:+ */ \
    0x57, /* 0x58:[RETURN] */ \
    0x67, /* 0x59:1 */ \
    0x68, /* 0x5a:2 */ \
    0x77, /* 0x5b:3 */ \
    0x65, /* 0x5c:4 */ \
    0x66, /* 0x5d:5 */ \
    0x75, /* 0x5e:6 */ \
    0x63, /* 0x5f:7 */ \
\
    0x64, /* 0x60:8 */ \
    0x73, /* 0x61:9 */ \
    0x69, /* 0x62:0 */ \
    0x6a, /* 0x63:. */ \
    0   , /* 0x64 */ \
    0x5a, /* 0x65:[Application] = PET [Repeat] key */ \
    0   , /* 0x66 */ \
    0x7a, /* 0x67:= */ \
    0   , /* 0x68 */ \
    0   , /* 0x69 */ \
    0   , /* 0x6a */ \
    0   , /* 0x6b */ \
    0   , /* 0x6c */ \
    0   , /* 0x6d */ \
    0   , /* 0x6e */ \
    0   , /* 0x6f */ \
 \
    0   , /* 0x70 */ \
    0   , /* 0x71 */ \
    0   , /* 0x72 */ \
    0   , /* 0x73 */ \
    0   , /* 0x74 */ \
    0   , /* 0x75 */ \
    0   , /* 0x76 */ \
    0   , /* 0x77 */ \
    0   , /* 0x78 */ \
    0   , /* 0x79 */ \
    0   , /* 0x7a */ \
    0   , /* 0x7b */ \
    0   , /* 0x7c */ \
    0   , /* 0x7d */ \
    0   , /* 0x7e */ \
    0   , /* 0x7f */ \
 \
    0   , /* 0x80 */ \
    0   , /* 0x81 */ \
    0   , /* 0x82 */ \
    0   , /* 0x83 */ \
    0   , /* 0x84 */ \
    0   , /* 0x85 */ \
    0   , /* 0x86 */ \
    0x32, /* 0x87:[Backslash]/[_] key = [Backslash] */ \
    0   , /* 0x88:[Hiragana/Katakana] */ \
    0x32, /* 0x89:[Yen]/[|] key = [Backslash] */ \
};


// F1 - F8 default string
#define PET_NUM_FKEYS	8
#define PET_FKEY_MAXLEN	256
// the string length must be less than PET_FKEY_MAXLEN
#ifndef PET2001N
static char const *pet_func_key_string_default[PET_NUM_FKEYS] = {
  "poke 59468,12\r",						// 1: uppercase/graphics mode
  "poke 59468,14\r",						// 2: lower/uppercase mode
  "poke 59520,12:poke 59521,16\r",				// 3: Font set #0
  "poke 59520,12:poke 59521,48\r",				// 4: Font set #1
  "open1,8,15,\"cd:\":close1\x9d\x9d\x9d\x9d\x9d\x9d\x9d\x9d",	// 5: chdir
  "open1,8,15,\"cd_\":close1\r",				// 6: chdir ..
  "poke 59520,12:poke 59521,0\r",				// 7: Font set #0, Inverse
  "sys 60928\r",						// 8: Install ROM DOS Wedge
};
#else // PET-2001N with PCG
static char const *pet_func_key_string_default[PET_NUM_FKEYS] = {
  "poke 59468,12\r",						// 1: uppercase/graphics mode
  "poke 59468,14\r",						// 2: lower/uppercase mode
  "sys 40960\r",						// 3: Install BASIC extension at $a000
  "sys 45056\r",						// 4: Install BASIC extension at $b000
  "open1,8,15,\"cd:\":close1\x9d\x9d\x9d\x9d\x9d\x9d\x9d\x9d",	// 5: chdir
  "open1,8,15,\"cd_\":close1\r",				// 6: chdir ..
  "poke 59459,255:poke 59471,0\r",				// 7: PCG init: Port-A=All-out / All-Zero
  "sys 36864\r",						// 8: Install ROM DOS Wedge at $9000
};
#endif

// ASCII to HID keycode + modifier code table (fill later)
static uint8_t ascii2keycode[PET_FKEY_MAXLEN]= {0};
static uint8_t ascii2modifier[PET_FKEY_MAXLEN]= {0};

// SHIFT LOCK / kana+game mode
static bool shift_lock = false;
static enum {
  PET_KBMODE_NORMAL = 0,
  PET_KBMODE_KANA,
  PET_KBMODE_GAME,
} pet_kb_mode = PET_KBMODE_NORMAL;

// PET's last SHIFT Key state
static bool pet_last_shift_state = false;

// Function key definition mode
static bool    fkey_def_mode = false;
static uint16_t fkey_def_keynum  = 0;

// Function key buffer
typedef struct {
  size_t length;		// Number of keycodes in this entry
  bool initial_shift_lock;	// initial shift_lock value of the fkey assume
  bool initial_pet_kb_mode;	// initial pet_kb_mode value of the fkey assume
  uint8_t modifier[PET_FKEY_MAXLEN];	// HID modifier
  uint8_t keycode[PET_FKEY_MAXLEN];	// HID keycode
} pet_func_key_store_t;
static pet_func_key_store_t pet_func_key_store[PET_NUM_FKEYS] = {0};



// Wait time for debounce
#define PET_KBIF_RESET_MS		10
#define PET_KBIF_STROBE_MS		1
#define PET_KBIF_DEBOUNCE_MS		16	// 14 NG, 15:OK, 16: safer
#define PET_KBIF_RELEASE_DEBOUNCE_MS	1
#define PET_KBIF_WAIT_BETWEEN_THE_SAME_KEY_MS	PET_KBIF_DEBOUNCE_MS
#define PET_KBIF_CTRL_ALT_DEL_MS	500

// Pin assignments
#define PET_PIO_RESET_PIN	6
#define PET_PIO_DATA_PIN	7
#define PET_PIO_STROBE_PIN	8
#define PET_PIO_AX0_PIN		9
#define PET_PIO_AX1_PIN		10
#define PET_PIO_AX2_PIN		11
#define PET_PIO_AX3_PIN		12
#define PET_PIO_AY0_PIN		13
#define PET_PIO_AY1_PIN		14
#define PET_PIO_AY2_PIN		15
#define PET_PIO_PET_RESET_PIN	19

// fill ascii2*[] table
static void pet_fill_ascii2hid(void)
{
  for (uint16_t c = 1; c < 256; c++)
  {
    for (uint16_t k = 4; k < 256; k++)
    {
      for (uint16_t s = 0; s < 2; s++)
      {
        if (keycode2ascii[k][s] == (uint8_t)c)
        {
          ascii2keycode[c]  = (uint8_t)k;
          ascii2modifier[c] = s ? KEYBOARD_MODIFIER_LEFTSHIFT : 0;
          k = 256;	// found
          break;
        }
      }
    }
  }
}

// Store function key buffer default
// must be after pet_fill_ascii2hid()
static void pet_func_ket_init(void)
{
  for (int i = 0; i < PET_NUM_FKEYS; i++)
  {
    const char *s = pet_func_key_string_default[i];
    size_t l = strlen(s);
    pet_func_key_store[i].length = l;
    pet_func_key_store[i].initial_shift_lock = false;
    pet_func_key_store[i].initial_pet_kb_mode  = PET_KBMODE_NORMAL;

    for (size_t n = 0; n < l; n++)
    {
      pet_func_key_store[i].keycode[n]  = ascii2keycode[(uint8_t)s[n]];
      pet_func_key_store[i].modifier[n] = ascii2modifier[(uint8_t)s[n]];
    }
  }
}


// PET key sending task
static enum  {
  PET_TASK_STATE_RESET = 0,
  PET_TASK_STATE_RESET_ASSERTED,
  PET_TASK_STATE_GETKEY,
  PET_TASK_STATE_KEY_STROBE_ASSERTED,
  PET_TASK_STATE_KEY_STROBE_DEASSERTED,
  PET_TASK_STATE_KEY_WAIT_DEBOUNCE,
  PET_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE,
  PET_TASK_STATE_CTRL_ALT_DEL,
  PET_TASK_STATE_CTRL_ALT_DEL_ASSERTED,
  PET_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY,
} pet_key_sending_task_state = PET_TASK_STATE_RESET;
static uint32_t pet_task_start_ms = 0;
void pet_sendkey_task(void);


// Key queue for PET
#define PET_KEY_QUEUE_LEN	((uint16_t)256)
static uint16_t pet_key_queue[PET_KEY_QUEUE_LEN] =  { 0 };
static uint16_t pet_key_queue_read = 0;
static uint16_t pet_key_queue_write = 0;

// return number of data in queue
uint16_t pet_key_queue_num_data(void)
{
  return (uint16_t)((pet_key_queue_write + PET_KEY_QUEUE_LEN - pet_key_queue_read) % PET_KEY_QUEUE_LEN);
}

// put key into queue
void pet_key_queue_put(uint16_t syx)
{
  if ((uint16_t)((pet_key_queue_write + 1) % PET_KEY_QUEUE_LEN) != pet_key_queue_write)
  {
    pet_key_queue[pet_key_queue_write] = syx;
    pet_key_queue_write = (uint16_t)((pet_key_queue_write + 1) % PET_KEY_QUEUE_LEN);
  }
  else
  {
    // TODO when queue is full
    pet_key_sending_task_state = PET_TASK_STATE_RESET;
  }
}

// peek queue
uint16_t pet_key_queue_peek(void)
{
  if (pet_key_queue_read == pet_key_queue_write) return 0;	// No key in queue
  return pet_key_queue[pet_key_queue_read];			// Peek queue
}

// drop queue
void pet_key_queue_drop(void)
{
  if (pet_key_queue_read == pet_key_queue_write) return;	// No key in queue
  // advance queue read pointer
  pet_key_queue_read = (uint16_t)((pet_key_queue_read + 1) % PET_KEY_QUEUE_LEN);
}


// Reset
// Initialize
static void pet_switch_init(void)
{
  gpio_init(PET_PIO_RESET_PIN);
  gpio_init(PET_PIO_DATA_PIN);
  gpio_init(PET_PIO_STROBE_PIN);
  gpio_init(PET_PIO_AX0_PIN);
  gpio_init(PET_PIO_AX1_PIN);
  gpio_init(PET_PIO_AX2_PIN);
  gpio_init(PET_PIO_AX3_PIN);
  gpio_init(PET_PIO_AY0_PIN);
  gpio_init(PET_PIO_AY1_PIN);
  gpio_init(PET_PIO_AY2_PIN);
  gpio_init(PET_PIO_PET_RESET_PIN);

  gpio_set_dir(PET_PIO_RESET_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_DATA_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_STROBE_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AX0_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AX1_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AX2_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AX3_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AY0_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AY1_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_AY2_PIN, GPIO_OUT);
  gpio_set_dir(PET_PIO_PET_RESET_PIN, GPIO_OUT);

  gpio_put(PET_PIO_RESET_PIN, 0);
  gpio_put(PET_PIO_DATA_PIN, 0);
  gpio_put(PET_PIO_STROBE_PIN, 0);
  gpio_put(PET_PIO_AX0_PIN, 0);
  gpio_put(PET_PIO_AX1_PIN, 0);
  gpio_put(PET_PIO_AX2_PIN, 0);
  gpio_put(PET_PIO_AX3_PIN, 0);
  gpio_put(PET_PIO_AY0_PIN, 0);
  gpio_put(PET_PIO_AY1_PIN, 0);
  gpio_put(PET_PIO_AY2_PIN, 0);
  gpio_put(PET_PIO_PET_RESET_PIN, 0);

  // init queue
  pet_key_queue_read = 0;
  pet_key_queue_write = 0;
  
  // init SHIFT LOCK
  shift_lock = false;
  pet_kb_mode = PET_KBMODE_NORMAL;
  pet_last_shift_state = false;

  // init LED
  leds = 0;
  prev_leds = 0;
  blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;
  if (keybd_dev_addr != 0xFFu)
  {
    tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &leds, sizeof(leds));
  }

  // init fkey
  pet_func_ket_init();
  fkey_def_mode = false;

  // Assert Reset of switch array IC
  gpio_put(PET_PIO_RESET_PIN, 1);

  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_RESET_ASSERTED;
  pet_task_start_ms = board_millis();
}


void pet_switch_all_relase(void)
{
  // Release all keys
  // Assert Reset of switch array IC
  gpio_put(PET_PIO_RESET_PIN, 1);

  // init
  pet_key_queue_read = 0;
  pet_key_queue_write = 0;
  shift_lock = false;
  pet_last_shift_state = false;
  fkey_def_mode = false;

  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_RESET_ASSERTED;
  pet_task_start_ms = board_millis();
}


static void pet_switch_deassert_reset(void)
{
  // Deassert Reset of switch array IC
  gpio_put(PET_PIO_RESET_PIN, 0);
  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_GETKEY;
  pet_task_start_ms = board_millis();
}

// Switch ON/OFF
void pet_switch_set(uint8_t x, uint8_t y, bool onoff)
{
  if (x > 5) x += 2;	// No switch on X=6 and X=7

  gpio_put(PET_PIO_AX0_PIN, x & 1);
  gpio_put(PET_PIO_AX1_PIN, (x & 2) ? 1 : 0);
  gpio_put(PET_PIO_AX2_PIN, (x & 4) ? 1 : 0);
  gpio_put(PET_PIO_AX3_PIN, (x & 8) ? 1 : 0);
  gpio_put(PET_PIO_AY0_PIN, y & 1);
  gpio_put(PET_PIO_AY1_PIN, (y & 2) ? 1 : 0);
  gpio_put(PET_PIO_AY2_PIN, (y & 4) ? 1 : 0);
  gpio_put(PET_PIO_DATA_PIN, (onoff) ? 1 : 0);
  gpio_put(PET_PIO_STROBE_PIN, 1);

  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_KEY_STROBE_ASSERTED;
  pet_task_start_ms = board_millis();
}

void pet_switch_deassert_strobe(void)
{
  gpio_put(PET_PIO_STROBE_PIN, 0);
  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_KEY_STROBE_DEASSERTED;
  pet_task_start_ms = board_millis();
}

// debounce
void pet_switch_start_waiting_debounce(void)
{
  // Change task state
  pet_key_sending_task_state =  gpio_get(PET_PIO_DATA_PIN) ? PET_TASK_STATE_KEY_WAIT_DEBOUNCE : PET_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE;
  pet_task_start_ms = board_millis();
}

// get next key
void pet_switch_get_next_key(void)
{
  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_GETKEY;
  pet_task_start_ms = board_millis();
}

// wait between the same key pressed again
void pet_switch_start_waiting_between_the_same_key(void)
{
  // Change task state
  pet_key_sending_task_state =  PET_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY;
  pet_task_start_ms = board_millis();
}

static void pet_switch_ctrl_alt_del(void)
{
  // Assert CTRL-ALT-DEL
  gpio_put(PET_PIO_PET_RESET_PIN, 1);
  // Assert Reset of switch array IC
  gpio_put(PET_PIO_RESET_PIN, 1);
  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_CTRL_ALT_DEL_ASSERTED;
  pet_task_start_ms = board_millis();
}

static void pet_switch_deassert_ctrl_alt_del(void)
{
  // Dessert Reset of switch array IC
  gpio_put(PET_PIO_RESET_PIN, 0);
  // Dessert CTRL-ALT-DEL
  gpio_put(PET_PIO_PET_RESET_PIN, 0);
  // init queue
  pet_key_queue_read = 0;
  pet_key_queue_write = 0;

  // init SHIFT LOCK
  shift_lock = false;
  pet_kb_mode = PET_KBMODE_NORMAL;
  pet_last_shift_state = false;

  // init LED
  leds = 0;
  prev_leds = 0;
  blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;
  if (keybd_dev_addr != 0xFFu)
  {
    tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &leds, sizeof(leds));
  }


  // init fkey
  pet_func_ket_init();
  fkey_def_mode = false;

  // Change task state
  pet_key_sending_task_state = PET_TASK_STATE_GETKEY;
  pet_task_start_ms = board_millis();
}


/*------------- MAIN -------------*/
int main(void)
{
  board_init();
  pet_fill_ascii2hid();
  pet_func_ket_init();

  printf("PETKB + TinyUSB Host HID <-> Device CDC Example\r\n");

  // init device and host stack on configured roothub port
  tud_init(BOARD_TUD_RHPORT);
  tuh_init(BOARD_TUH_RHPORT);

  while (1)
  {
    tud_task(); // tinyusb device task
    tuh_task(); // tinyusb host task
    led_blinking_task();
    pet_sendkey_task();
    keyboard_led_blinking_task();
  }

  return 0;
}

//--------------------------------------------------------------------+
// Device CDC
//--------------------------------------------------------------------+

// Invoked when device is mounted
void tud_mount_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}

// Invoked when device is unmounted
void tud_umount_cb(void)
{
  blink_interval_ms = BLINK_NOT_MOUNTED;
}

// Invoked when usb bus is suspended
// remote_wakeup_en : if host allow us  to perform remote wakeup
// Within 7ms, device must draw an average of current less than 2.5 mA from bus
void tud_suspend_cb(bool remote_wakeup_en)
{
  (void) remote_wakeup_en;
  blink_interval_ms = BLINK_SUSPENDED;
}

// Invoked when usb bus is resumed
void tud_resume_cb(void)
{
  blink_interval_ms = BLINK_MOUNTED;
}

// Invoked when CDC interface received data from host
void tud_cdc_rx_cb(uint8_t itf)
{
  (void) itf;

  char buf[64];
  uint32_t count = tud_cdc_read(buf, sizeof(buf));

  // TODO control LED on keyboard of host stack
  (void) count;
}

//--------------------------------------------------------------------+
// Host HID
//--------------------------------------------------------------------+

// Invoked when device with hid interface is mounted
// Report descriptor is also available for use. tuh_hid_parse_report_descriptor()
// can be used to parse common/simple enough descriptor.
// Note: if report descriptor length > CFG_TUH_ENUMERATION_BUFSIZE, it will be skipped
// therefore report_desc = NULL, desc_len = 0
void tuh_hid_mount_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* desc_report, uint16_t desc_len)
{
  (void)desc_report;
  (void)desc_len;

  // Interface protocol (hid_interface_protocol_enum_t)
  const char* protocol_str[] = { "None", "Keyboard", "Mouse" };
  uint8_t const itf_protocol = tuh_hid_interface_protocol(dev_addr, instance);

  uint16_t vid, pid;
  tuh_vid_pid_get(dev_addr, &vid, &pid);

  char tempbuf[256];
  int count = sprintf(tempbuf, "[%04x:%04x][%u] HID Interface%u, Protocol = %s\r\n", vid, pid, dev_addr, instance, protocol_str[itf_protocol]);
  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();

  // Receive report from boot keyboard & mouse only
  // tuh_hid_report_received_cb() will be invoked when report is available
  if (itf_protocol == HID_ITF_PROTOCOL_KEYBOARD || itf_protocol == HID_ITF_PROTOCOL_MOUSE)
  {
    if ( !tuh_hid_receive_report(dev_addr, instance) )
    {
      tud_cdc_write_str("Error: cannot request report\r\n");
    }
  }

  // When HID Keyboard attached
  if (itf_protocol == HID_ITF_PROTOCOL_KEYBOARD)
  {
    // Init LED
    leds = 0;
    prev_leds = 0;
    keybd_dev_addr = dev_addr;
    keybd_instance = instance;
    tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &leds, sizeof(leds));
    // Reset PET I/F
    pet_key_sending_task_state = PET_TASK_STATE_RESET_ASSERTED;
  }
}

// Invoked when device with hid interface is un-mounted
void tuh_hid_umount_cb(uint8_t dev_addr, uint8_t instance)
{
  char tempbuf[256];
  int count = sprintf(tempbuf, "[%u] HID Interface%u is unmounted\r\n", dev_addr, instance);
  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();

  // Reset PET I/F
  pet_key_sending_task_state = PET_TASK_STATE_RESET_ASSERTED;

  keybd_dev_addr = 0xFFu;

  // Init KB LED
  leds = 0;
  prev_leds = 0;
  blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_NONE;

  // init SHIFT LOCK
  shift_lock = false;
  pet_kb_mode = PET_KBMODE_NORMAL;
  pet_last_shift_state = false;
}

// look up new key in previous keys
static inline bool find_key_in_report(hid_keyboard_report_t const *report, uint8_t keycode)
{
  for(uint8_t i=0; i<6; i++)
  {
    if (report->keycode[i] == keycode)  return true;
  }

  return false;
}


// convert hid keycode to ascii and print via usb device CDC (ignore non-printable)
static void process_kbd_report(uint8_t dev_addr, hid_keyboard_report_t const *report)
{
  (void) dev_addr;
  static hid_keyboard_report_t prev_report = { 0, 0, {0} }; // previous report to check key released
  bool flush = false;
  static uint8_t last_modifier = 0;


  // Check modifier change
  if (last_modifier != report->modifier)
  {
    char tempbuf[256];
    int count = sprintf(tempbuf, "Modifier: %02x -> %02x\r\n", last_modifier, report->modifier);
    tud_cdc_write(tempbuf, (uint32_t) count);
    flush = true;

    // GAME mode
    if (pet_kb_mode == PET_KBMODE_GAME)
    {
      if ((last_modifier ^ report->modifier) & KEYBOARD_MODIFIER_LEFTSHIFT)
      {
        // LS changed
        bool press = report->modifier & KEYBOARD_MODIFIER_LEFTSHIFT;
        press = (press || shift_lock);
        pet_key_queue_put(PET_KEYCODE_LS | (press ? PET_KEYPRESS : 0));
      }
      if ((last_modifier ^ report->modifier) & KEYBOARD_MODIFIER_RIGHTSHIFT)
      {
        // RS changed
        bool press = report->modifier & KEYBOARD_MODIFIER_RIGHTSHIFT;
        pet_key_queue_put(PET_KEYCODE_RS | (press ? PET_KEYPRESS : 0));
      }
    }
  }
  last_modifier = report->modifier;


  for(uint8_t i=0; i<6; i++)
  {
    uint8_t keycode = report->keycode[i];
    if ( keycode )
    {
      if ( find_key_in_report(&prev_report, keycode) )
      {
        // exist in previous report means the current key is holding
      }
      else
      {
        // not existed in previous report means the current key is pressed

        // remap the key code for Colemak layout
        #ifdef KEYBOARD_COLEMAK
        uint8_t colemak_key_code = colemak[keycode];
        if (colemak_key_code != 0) keycode = colemak_key_code;
        #endif

        bool       is_shift = report->modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
        bool const is_ctrl  = report->modifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
        bool const is_alt   = report->modifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);
        bool const is_del   = (keycode == DELETE_KEY_CODE);
        bool const is_c     = (keycode == C_KEY_CODE);
        bool const is_caps  = (keycode == CAPS_KEY_CODE);
        bool const is_kana  = (keycode == KANA_KEY_CODE);

        // Check fkey def mode: [CTRL]+[F1-8]
        // disabled in GAME mode
        if (pet_kb_mode != PET_KBMODE_GAME && is_ctrl && (keycode >= F1_KEY_CODE && keycode <= (F1_KEY_CODE + PET_NUM_FKEYS - 1)))
        {
          uint16_t keynum = keycode - F1_KEY_CODE;

          if (!fkey_def_mode)
          {
            // enter fkey definition mode
            char tempbuf[256];
            int count = sprintf(tempbuf, "Enter [F%d] definition mode\r\n", keynum + 1);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;

            fkey_def_mode = true;
            fkey_def_keynum  = keynum;
            pet_func_key_store[fkey_def_keynum].length = 0;
            pet_func_key_store[fkey_def_keynum].initial_shift_lock = shift_lock;
            pet_func_key_store[fkey_def_keynum].initial_pet_kb_mode  = pet_kb_mode;
          }
          else
          {
            // exit from fkey definition mode
            char tempbuf[256];
            int count = sprintf(tempbuf, "Exit [F%d] definition mode\r\n", fkey_def_keynum + 1);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;

            fkey_def_mode = false;
          }
          // once enter / exit the mode, this key is done and wait for the next key
          continue;
        }

        // if fkey_def_mode, record the keycode and modifier
        if (fkey_def_mode)
        {
            if (pet_func_key_store[fkey_def_keynum].length < PET_FKEY_MAXLEN)
            {
              pet_func_key_store[fkey_def_keynum].keycode[pet_func_key_store[fkey_def_keynum].length]  = keycode;
              pet_func_key_store[fkey_def_keynum].modifier[pet_func_key_store[fkey_def_keynum].length] = report->modifier;
              pet_func_key_store[fkey_def_keynum].length++;
            }
            if (pet_func_key_store[fkey_def_keynum].length >= PET_FKEY_MAXLEN)
            {
              // exit from fkey definition mode
              char tempbuf[256];
              int count = sprintf(tempbuf, "Exit [F%d] definition mode due to buffer full\r\n", fkey_def_keynum + 1);
              tud_cdc_write(tempbuf, (uint32_t) count);
              flush = true;

              fkey_def_mode = false;
            }
        }

        // Check KANA and GAME mode ON/OFF
        if (is_kana)
        {
          pet_last_shift_state = false;
          if (is_ctrl)
          {
            // CTRL + KANA = GAME mode on / off
            pet_switch_all_relase();
            pet_kb_mode = (pet_kb_mode == PET_KBMODE_GAME) ? PET_KBMODE_NORMAL : PET_KBMODE_GAME;
            // All key relase when entering/leaving GAME mode
          }
          else
          {
            // KANA mode on / off
            if (pet_kb_mode == PET_KBMODE_GAME) pet_switch_all_relase();
            pet_kb_mode = (pet_kb_mode == PET_KBMODE_KANA) ? PET_KBMODE_NORMAL : PET_KBMODE_KANA;
          }

          char tempbuf[256];
          int count = sprintf(tempbuf, "PET: KB MODE = %s\r\n", (pet_kb_mode == PET_KBMODE_KANA) ? "KANA" : (pet_kb_mode == PET_KBMODE_GAME) ? "GAME" : "NORM");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
        }

        // Check CAPS = SHIFT LOCK ON/OFF check
        else if (is_caps)
        {
          shift_lock = !shift_lock;
          if (pet_kb_mode == PET_KBMODE_GAME)
          {
            bool press = is_shift;
            press = (press || shift_lock);
            pet_key_queue_put(PET_KEYCODE_LS | (press ? PET_KEYPRESS : 0));
          }
          else if (!shift_lock)
          {
            pet_key_queue_put(PET_KEYCODE_LS);
          }

          char tempbuf[256];
          int count = sprintf(tempbuf, "PET: SHIFT LOCK = %s\r\n", shift_lock ? "ON" : "OFF");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
        }
        if (shift_lock)
        {
          is_shift = true;
        }

        uint8_t ch = keycode2ascii[keycode][is_shift ? 1 : 0];
        if (ch && !(ch & 0x80) && !is_ctrl)
        {
          tud_cdc_write("CHAR: ", 6);
          if (ch == '\r') tud_cdc_write("[RETURN]", 8);
          else if (ch == '\t') tud_cdc_write("[TAB]", 5);
          else if (ch == '\b') tud_cdc_write("[BS]", 4);
          else if (ch == ' ') tud_cdc_write("[SP]", 4);
          else if (ch < 0x20u || ch >= 0x80u)
          {
            char tempbuf[256];
            int count = sprintf(tempbuf, "[%02x]", ch);
            tud_cdc_write(tempbuf, (uint32_t) count);
            flush = true;
          }
          else tud_cdc_write(&ch, 1);
          tud_cdc_write("\r\n", 2);
          flush = true;
        }
        else
        {
          char tempbuf[256];
          int count = sprintf(tempbuf, "HID: keycode = %02x, modifier = %02x\r\n", keycode, report->modifier);
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;
        }

        // PET -----------------------------

        // Check CTRL-ALT-DEL
        if (is_ctrl && is_alt && is_del)
        {
          pet_key_sending_task_state = PET_TASK_STATE_CTRL_ALT_DEL;
        }

        // [F1] - [F8]
        // function key
        // [ =============================================================
        else if (pet_kb_mode != PET_KBMODE_GAME && keycode >= F1_KEY_CODE && keycode <= (F1_KEY_CODE + PET_NUM_FKEYS - 1))
        {
          // Function keys are disabled in GAME mode
          uint16_t keynum = keycode - F1_KEY_CODE;
          size_t l = pet_func_key_store[keynum].length;

          shift_lock = pet_func_key_store[keynum].initial_shift_lock;
          pet_kb_mode  =  pet_func_key_store[keynum].initial_pet_kb_mode;

          char tempbuf[256];
          int count = sprintf(tempbuf, "[F%d],sh:%s,kb:%s\r\n", keynum + 1, shift_lock ? "ON" : "OFF", (pet_kb_mode == PET_KBMODE_KANA) ? "KANA" : (pet_kb_mode == PET_KBMODE_GAME) ? "GAME" : "NORM");
          tud_cdc_write(tempbuf, (uint32_t) count);
          flush = true;

          for (size_t n = 0; n < l; n++)
          {
            // Emulate key press
            uint8_t fkeycode  = pet_func_key_store[keynum].keycode[n];
            uint8_t fmodifier = pet_func_key_store[keynum].modifier[n];
            bool       fis_shift = fmodifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
            bool const fis_ctrl  = fmodifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
            bool const fis_alt   = fmodifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);
            // bool const fis_del   = (fkeycode == DELETE_KEY_CODE);
            bool const fis_c     = (fkeycode == C_KEY_CODE);
            bool const fis_caps  = (fkeycode == CAPS_KEY_CODE);
            bool const fis_kana  = (fkeycode == KANA_KEY_CODE);
            uint16_t syx;
            switch (pet_kb_mode)
            {
              case PET_KBMODE_KANA:
                syx = keycode2petSYX_kana[fkeycode][fis_shift ? 1 : 0];
                break;
              case PET_KBMODE_GAME:
                syx = keycode2petSYX_game[fkeycode];
                break;
              case PET_KBMODE_NORMAL:
              default:
                syx = keycode2petSYX[fkeycode][fis_shift ? 1 : 0];
                break;
            }

            // Check KANA and GAME mode ON/OFF
            if (fis_kana)
            {
              if (fis_ctrl)
              {
                // CTRL + KANA = GAME mode on / off
                pet_kb_mode = (pet_kb_mode == PET_KBMODE_GAME) ? PET_KBMODE_NORMAL : PET_KBMODE_GAME;
              }
              else
              {
                // KANA mode on / off
                pet_kb_mode = (pet_kb_mode == PET_KBMODE_KANA) ? PET_KBMODE_NORMAL : PET_KBMODE_KANA;
              }

              count = sprintf(tempbuf, "PET: KB MODE = %s\r\n", (pet_kb_mode == PET_KBMODE_KANA) ? "KANA" : (pet_kb_mode == PET_KBMODE_GAME) ? "GAME" : "NORM");
              tud_cdc_write(tempbuf, (uint32_t) count);
              flush = true;
            }

            // Check CAPS = SHIFT LOCK ON/OFF check
            else if (fis_caps)
            {
              if (!(shift_lock = !shift_lock))
              {
                // Release SHIFT on PET
                pet_key_queue_put(PET_KEYCODE_LS);
              }
              count = sprintf(tempbuf, "PET: SHIFT LOCK = %s\r\n", shift_lock ? "ON" : "OFF");
              tud_cdc_write(tempbuf, (uint32_t) count);
              flush = true;
            }
            if (shift_lock)
            {
              fis_shift = true;
            }

            // Check CTRL-C / SHIFT-CTRL-C
            if (fis_ctrl && fis_c)
            {
              if (!fis_shift)
              {
                // Queue [RUN/STOP] key pressed
                syx = PET_KEYCODE_RUN_STOP;
              }
              else
              {
                // Queue [SHIFT] + [RUN/STOP] key pressed
                syx = PET_KEYCODE_RUN_STOP | PET_SHIFT;
              }
            }

            if (syx)
            {
              bool sft = (syx & PET_SHIFT) || (fis_alt && (pet_kb_mode == PET_KBMODE_NORMAL));	// ALT = Force SHIFT for Graphic char input
              syx = PET_BARE_YX(syx);						// bare code
              if (syx == PET_KEYCODE_REPEAT)
              {
                // [Repeat] key's SHIFT state must be the same as the last pressed key's SHIFT state
                sft = pet_last_shift_state;
              }
              else
              {
                pet_last_shift_state = sft;
              }
              // press-release emulation
              if (sft) pet_key_queue_put(PET_KEYCODE_LS | PET_KEYPRESS);
              pet_key_queue_put(syx | PET_KEYPRESS);
              pet_key_queue_put(syx);
              if (sft) pet_key_queue_put(PET_KEYCODE_LS);
            }
          }
        }
        // ] =============================================================

        else
        {
          uint16_t syx;
          switch (pet_kb_mode)
          {
            case PET_KBMODE_KANA:
              syx = keycode2petSYX_kana[keycode][is_shift ? 1 : 0];
              break;
            case PET_KBMODE_GAME:
              syx = keycode2petSYX_game[keycode];
              break;
            case PET_KBMODE_NORMAL:
            default:
              syx = keycode2petSYX[keycode][is_shift ? 1 : 0];
              break;
          }

          // Check CTRL-C / SHIFT-CTRL-C
          if (is_ctrl && is_c)
          {
            if (!is_shift)
            {
              // Queue [RUN/STOP] key pressed
              syx = PET_KEYCODE_RUN_STOP;
            }
            else
            {
              // Queue [SHIFT] + [RUN/STOP] key pressed
              syx = PET_KEYCODE_RUN_STOP | PET_SHIFT;
            }
          }


          if (syx == PET_KEYCODE_REPEAT)
          {
            // [Repeat] key's SHIFT state must be the same as the last pressed key's SHIFT state
            if (pet_last_shift_state) syx |= PET_SHIFT;
          }

          if (syx)
          {
            if (pet_kb_mode == PET_KBMODE_GAME)
            {
              // simply queue bare key press
              syx = PET_BARE_YX(syx);						// bare code
              if (syx) pet_key_queue_put(syx | PET_KEYPRESS);
            }
            else
            {
              if (syx & PET_SHIFT || (is_alt && (pet_kb_mode == PET_KBMODE_NORMAL)))	// ALT = Force SHIFT for Graphic char input
              {
                pet_last_shift_state = true;
                // First, queue only SHIFT
                pet_key_queue_put(PET_KEYCODE_LS | PET_KEYPRESS);
                // Clear SHIFT bit and queue the bare key press
                syx = PET_BARE_YX(syx);
              }
              else
              {
                pet_last_shift_state = false;
              }
              // queue bare key press
              pet_key_queue_put(syx | PET_KEYPRESS);
            }
          }
        }
      }
    }
  }
  // Handle released key
  for(uint8_t i=0; i<6; i++)
  {
    uint8_t keycode = prev_report.keycode[i];
    if ( keycode )
    {
      if (find_key_in_report(report, keycode) && (pet_kb_mode != PET_KBMODE_GAME && prev_report.modifier == report->modifier))
      {
        // exist in current report means the previous key is still holding
        // kaokun: however, modifier may changed, e.g. the following sequence:
        // [Press Shift] - [Press a] - [Release Shift] - [release a]
        // we have to release the modifier-changed key other than in GAME mode.
      }
      else
      {
        // not existed in current report means the previous key is released, or the modifier changed

        // remap the key code for Colemak layout
        #ifdef KEYBOARD_COLEMAK
        uint8_t colemak_key_code = colemak[keycode];
        if (colemak_key_code != 0) keycode = colemak_key_code;
        #endif

        bool       is_shift = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT);
        bool const is_ctrl  = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTCTRL | KEYBOARD_MODIFIER_RIGHTCTRL);
        bool const is_alt   = prev_report.modifier & (KEYBOARD_MODIFIER_LEFTALT  | KEYBOARD_MODIFIER_RIGHTALT);
        bool const is_c     = (keycode == C_KEY_CODE);

        if (shift_lock)
        {
          is_shift = true;
        }

        // PET
        uint16_t syx;
        switch (pet_kb_mode)
        {
          case PET_KBMODE_KANA:
            syx = keycode2petSYX_kana[keycode][is_shift ? 1 : 0];
            break;
          case PET_KBMODE_GAME:
            syx = keycode2petSYX_game[keycode];
            break;
          case PET_KBMODE_NORMAL:
          default:
            syx = keycode2petSYX[keycode][is_shift ? 1 : 0];
            break;
        }

        // Check CTRL-C / SHIFT-CTRL-C
        if (is_ctrl && is_c)
        {
          if (!is_shift)
          {
            // Queue [RUN/STOP] key released
            syx = PET_KEYCODE_RUN_STOP;
          }
          else
          {
            // Queue [SHIFT] + [RUN/STOP] key released
            syx = PET_KEYCODE_RUN_STOP | PET_SHIFT;
          }
        }

        if (syx)
        {
          if (pet_kb_mode == PET_KBMODE_GAME)
          {
            // simply queue bare key release
            syx = PET_BARE_YX(syx);						// bare code
            if (syx) pet_key_queue_put(syx);
          }
          else
          {
            if (syx == PET_KEYCODE_REPEAT)
            {
              // [Repeat] key's SHIFT state must be the same as the last pressed key's SHIFT state
              if (pet_last_shift_state) syx |= PET_SHIFT;
            }

            // First, queue only bare code
            pet_key_queue_put(syx & (uint16_t)~PET_SHIFT);
            if (syx & PET_SHIFT || (is_alt && (pet_kb_mode != PET_KBMODE_NORMAL)))		// ALT = Force SHIFT for Graphic char input
            {
              // Then release SHIFT
              pet_key_queue_put(PET_KEYCODE_LS);
              pet_last_shift_state = false;
            }
          }
        }
      }
    }
  }

  // Change LED
  leds = 0;
  if (shift_lock) leds = leds | KEYBOARD_LED_CAPSLOCK;
  if (pet_kb_mode == PET_KBMODE_KANA)
  {
    leds = leds | KEYBOARD_LED_KANA | KEYBOARD_LED_NUMLOCK;
    blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_KANA;
  }
  if (pet_kb_mode == PET_KBMODE_GAME)
  {
    leds = leds | KEYBOARD_LED_SCROLLLOCK | KEYBOARD_LED_NUMLOCK;
    blink_numlock_led_interval_ms = BLINK_NUMLOCK_LED_GAME;
  }

  if (flush) tud_cdc_write_flush();
  prev_report = *report;
}

// send mouse report to usb device CDC
static void process_mouse_report(uint8_t dev_addr, hid_mouse_report_t const * report)
{
  //------------- button state  -------------//
  //uint8_t button_changed_mask = report->buttons ^ prev_report.buttons;
  char l = report->buttons & MOUSE_BUTTON_LEFT   ? 'L' : '-';
  char m = report->buttons & MOUSE_BUTTON_MIDDLE ? 'M' : '-';
  char r = report->buttons & MOUSE_BUTTON_RIGHT  ? 'R' : '-';

  char tempbuf[32];
  int count = sprintf(tempbuf, "[%u] %c%c%c %d %d %d\r\n", dev_addr, l, m, r, report->x, report->y, report->wheel);

  tud_cdc_write(tempbuf, (uint32_t) count);
  tud_cdc_write_flush();
}

// Invoked when received report from device via interrupt endpoint
void tuh_hid_report_received_cb(uint8_t dev_addr, uint8_t instance, uint8_t const* report, uint16_t len)
{
  (void) len;
  uint8_t const itf_protocol = tuh_hid_interface_protocol(dev_addr, instance);

  switch(itf_protocol)
  {
    case HID_ITF_PROTOCOL_KEYBOARD:
      process_kbd_report(dev_addr, (hid_keyboard_report_t const*) report );
      keybd_dev_addr = dev_addr;
      keybd_instance = instance;
    break;

    case HID_ITF_PROTOCOL_MOUSE:
      process_mouse_report(dev_addr, (hid_mouse_report_t const*) report );
    break;

    default: break;
  }

  // continue to request to receive report
  if ( !tuh_hid_receive_report(dev_addr, instance) )
  {
    tud_cdc_write_str("Error: cannot request report\r\n");
  }
}

//--------------------------------------------------------------------+
// Blinking Task
//--------------------------------------------------------------------+
void led_blinking_task(void)
{
  static uint32_t start_ms = 0;
  static bool led_state = false;

  // Blink every interval ms
  if ( board_millis() - start_ms < blink_interval_ms) return; // not enough time
  start_ms += blink_interval_ms;

  board_led_write(led_state);
  led_state = 1 - led_state; // toggle
}

// HID Keyboard LED
void keyboard_led_blinking_task(void)
{
  static uint32_t start_ms = 0;
  const bool is_numlock = leds & KEYBOARD_LED_NUMLOCK;
  static bool led_state = false;
  static uint8_t my_leds;

  if (keybd_dev_addr == 0xFFu) return;

  my_leds = leds;
  if (is_numlock && (blink_numlock_led_interval_ms != BLINK_NUMLOCK_LED_NONE))
  {
    if (board_millis() - start_ms >= blink_numlock_led_interval_ms)
    {
      // Blink every interval ms
      start_ms = board_millis();
      led_state = 1 - led_state; // toggle
    }
    if (led_state)
    {
      my_leds = (uint8_t)(my_leds | KEYBOARD_LED_NUMLOCK);
    }
    else
    {
      my_leds = (uint8_t)(my_leds & ~KEYBOARD_LED_NUMLOCK);
    }
  }
  if (prev_leds != my_leds)
  {
    if (!tuh_hid_set_report(keybd_dev_addr, keybd_instance, 0, HID_REPORT_TYPE_OUTPUT, &my_leds, sizeof(my_leds)))
    {
      char tempbuf[256];
      int count = sprintf(tempbuf, "HID KB LED %02x fail\r\n", my_leds);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
 
      prev_leds = 0xFFu;	// for retry
    }
    else
    {
      char tempbuf[256];
      int count = sprintf(tempbuf, "HID KB LED %02x Success\r\n", my_leds);
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
 
      prev_leds = my_leds;
    }
  }
}

//--------------------------------------------------------------------+
// PET key sending task
//--------------------------------------------------------------------+
void pet_sendkey_task(void)
{
  switch(pet_key_sending_task_state)
  {
    char tempbuf[256];
    int count;
    static uint16_t last_on_syx = 0;

    case PET_TASK_STATE_RESET:
      count = sprintf(tempbuf, "PET: initializing switch array\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      pet_switch_init();
      break;

    case PET_TASK_STATE_RESET_ASSERTED:
      if (board_millis() - pet_task_start_ms < PET_KBIF_RESET_MS) break;
      pet_switch_deassert_reset();
      count = sprintf(tempbuf, "PET: switch array ready\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      last_on_syx = 0;
      break;

    case PET_TASK_STATE_GETKEY:
      if (!pet_key_queue_num_data()) break;			// queue empty
  
      uint16_t syx  = pet_key_queue_peek();			// Peek queue
      uint16_t bare_yx = PET_BARE_YX(syx);
      bool onoff    = PET_ISKEYPRESS(syx);
      uint8_t x     = PET_X(syx);
      uint8_t y     = PET_Y(syx);

      if (!syx) {
        // current syx is processed
        pet_key_queue_drop();
        break;
      }

      if (onoff && syx == last_on_syx)
      {
        // the same key is pressed. need extra delay
        pet_switch_start_waiting_between_the_same_key();
        break;
      }

      // current syx is being processed
      pet_key_queue_drop();

      // avoid SHIFT bounce, ON->OFF->ON
      if ((!onoff) && (bare_yx == PET_KEYCODE_LS || bare_yx == PET_KEYCODE_RS) && pet_key_queue_num_data())
      {
        // Current: Key off, the key is SHIFT and there is next data
        uint16_t next_syx = pet_key_queue_peek();	// Peek next data
        uint16_t next_bare_yx  = PET_BARE_YX(next_syx);
        bool next_onoff = PET_ISKEYPRESS(next_syx);
        if (next_onoff && (next_bare_yx == PET_KEYCODE_LS || next_bare_yx == PET_KEYCODE_RS))
        {
          // Next key: key on, the key is SHIFT
          pet_key_queue_drop();	// drop the next key
          // and no process for current SHIFT OFF
          break;
        }
      }

#ifdef PET_KEYCODE_DEBUG
      count = sprintf(tempbuf, "PET: Array (%d, %d) = %s\r\n", x, y, (onoff) ? "ON" : "OFF");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
#endif

      // Switch array control
      pet_switch_set(x, y, onoff);
      if (onoff && !(bare_yx == PET_KEYCODE_LS || bare_yx == PET_KEYCODE_RS))
      {
        // save the last pressed key other than [SHIFT]
        last_on_syx = syx;
      }

      // OFF->OFF->OFF->... does not need debounce time
      while ((!onoff) && pet_key_queue_num_data())
      {
        // Current: Key off and there is next data
        uint16_t next_syx = pet_key_queue_peek();	// Peek next data
        onoff = PET_ISKEYPRESS(next_syx);
        if (!onoff)
        {
          x = PET_X(next_syx);
          y = PET_Y(next_syx);
      
#ifdef PET_KEYCODE_DEBUG
          count = sprintf(tempbuf, "PET: Array (%d, %d) = %s\r\n", x, y, (onoff) ? "ON" : "OFF");
          tud_cdc_write(tempbuf, (uint32_t) count);
          tud_cdc_write_flush();
#endif
          // Release the next key also
          pet_switch_set(x, y, onoff);
          // current syx is being processed
          pet_key_queue_drop();
        }
      }
  
      break;

    case PET_TASK_STATE_KEY_STROBE_ASSERTED:
      if (board_millis() - pet_task_start_ms < PET_KBIF_STROBE_MS) break;
      pet_switch_deassert_strobe();
      break;

    case PET_TASK_STATE_KEY_STROBE_DEASSERTED:
      if (board_millis() - pet_task_start_ms < PET_KBIF_STROBE_MS) break;
      pet_switch_start_waiting_debounce();
      break;

    case PET_TASK_STATE_KEY_WAIT_DEBOUNCE:
      if (board_millis() - pet_task_start_ms < PET_KBIF_DEBOUNCE_MS) break;
      pet_switch_get_next_key();
      break;

    case PET_TASK_STATE_KEY_WAIT_RELEASE_DEBOUNCE:
      if (board_millis() - pet_task_start_ms < PET_KBIF_RELEASE_DEBOUNCE_MS) break;
      pet_switch_get_next_key();
      break;

    case PET_TASK_STATE_CTRL_ALT_DEL:
      last_on_syx = 0;
      count = sprintf(tempbuf, "PET: Asserting CTRL-ALT-DEL\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      pet_switch_ctrl_alt_del();
      break;

    case PET_TASK_STATE_CTRL_ALT_DEL_ASSERTED:
      if (board_millis() - pet_task_start_ms < PET_KBIF_CTRL_ALT_DEL_MS) break;
      pet_switch_deassert_ctrl_alt_del();
      count = sprintf(tempbuf, "PET: Deassert CTRL-ALT-DEL\r\n");
      tud_cdc_write(tempbuf, (uint32_t) count);
      tud_cdc_write_flush();
      last_on_syx = 0;
      break;

    case PET_TASK_STATE_WAITING_BETWEEN_THE_SAME_KEY:
      if (board_millis() - pet_task_start_ms < PET_KBIF_WAIT_BETWEEN_THE_SAME_KEY_MS) break;
      pet_switch_get_next_key();
      last_on_syx = 0;
      break;

    default:
      pet_key_sending_task_state = PET_TASK_STATE_RESET;
      break;
  }
}
